(() => {
  try {
    document.documentElement.setAttribute("data-ldd-content-script-loaded", "1");
    document.documentElement.setAttribute("data-ldd-content-script-build", "20260328-vision-pm");
  } catch (_error) {
    // Ignore DOM marker failures.
  }
  const THEME_STYLE_ID = "ldd-global-theme-style";
  const THEME_OVERLAY_ID = "ldd-global-theme-overlay";
  const extensionRuntime =
    typeof chrome !== "undefined" && chrome?.runtime && typeof chrome.runtime.getURL === "function"
      ? chrome.runtime
      : null;
  const extensionStorage =
    typeof chrome !== "undefined" && chrome?.storage?.local && typeof chrome.storage.local.get === "function"
      ? chrome.storage.local
      : null;
  const DEFAULT_SETTINGS = {
    enhancerEnabled: true,
    qaBarEnabled: true,
    dropperEnabled: true,
    visionAIPresetsEnabled: true,
    globalThemeEnabled: false,
    globalThemeMode: "gradient",
    globalThemeSolidColor: "#1f4ed8",
    globalThemeGradientColor: "#7c3aed",
    globalThemeBrightness: 100,
    globalThemePreset: "bluePurple",
    globalThemeCustomPresets: []
  };

  function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
  }

  function normalizeHexColor(value, fallback) {
    if (typeof value !== "string") return fallback;
    const trimmed = value.trim();
    if (/^#[0-9a-fA-F]{6}$/.test(trimmed)) return trimmed;
    if (/^#[0-9a-fA-F]{3}$/.test(trimmed)) {
      return `#${trimmed[1]}${trimmed[1]}${trimmed[2]}${trimmed[2]}${trimmed[3]}${trimmed[3]}`;
    }
    return fallback;
  }

  function rgbaFromHex(hexColor, alpha) {
    const safe = normalizeHexColor(hexColor, "#1f4ed8");
    const int = Number.parseInt(safe.slice(1), 16);
    const r = (int >> 16) & 255;
    const g = (int >> 8) & 255;
    const b = int & 255;
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
  }

  function adjustHexBrightness(hexColor, brightnessPercent) {
    const safe = normalizeHexColor(hexColor, "#1f4ed8");
    const int = Number.parseInt(safe.slice(1), 16);
    const factor = clamp(Number.parseFloat(brightnessPercent) || 100, 70, 130) / 100;
    const toHex = (channel) => clamp(Math.round(channel * factor), 0, 255).toString(16).padStart(2, "0");
    const r = toHex((int >> 16) & 255);
    const g = toHex((int >> 8) & 255);
    const b = toHex(int & 255);
    return `#${r}${g}${b}`;
  }

  function applyGlobalTheme(settings) {
    const enabled = Boolean(settings.globalThemeEnabled);
    const existing = document.getElementById(THEME_STYLE_ID);
    const existingOverlay = document.getElementById(THEME_OVERLAY_ID);

    if (!enabled) {
      existing?.remove();
      existingOverlay?.remove();
      return;
    }

    const mode = settings.globalThemeMode === "solid" ? "solid" : "gradient";
    const brightness = clamp(Number.parseFloat(settings.globalThemeBrightness) || 100, 70, 130);
    const solid = adjustHexBrightness(settings.globalThemeSolidColor, brightness);
    const gradient = adjustHexBrightness(settings.globalThemeGradientColor, brightness);
    const accentGradient =
      mode === "solid"
        ? `linear-gradient(135deg, ${solid} 0%, ${solid} 100%)`
        : `linear-gradient(135deg, ${solid} 0%, ${gradient} 100%)`;
    const pageBackground =
      mode === "solid"
        ? `linear-gradient(180deg, #ffffff 0%, ${rgbaFromHex(solid, 0.14)} 100%)`
        : `linear-gradient(165deg, #ffffff 0%, ${rgbaFromHex(solid, 0.13)} 42%, ${rgbaFromHex(gradient, 0.15)} 100%)`;
    const surfaceBackground =
      mode === "solid"
        ? `linear-gradient(180deg, rgba(255,255,255,0.98) 0%, ${rgbaFromHex(solid, 0.08)} 100%)`
        : `linear-gradient(180deg, rgba(255,255,255,0.98) 0%, ${rgbaFromHex(solid, 0.07)} 45%, ${rgbaFromHex(gradient, 0.09)} 100%)`;
    const borderTint = rgbaFromHex(solid, 0.26);
    const softBorderTint = rgbaFromHex(solid, 0.18);
    const focusTint = rgbaFromHex(gradient, 0.3);
    const buttonBorder = rgbaFromHex(gradient, 0.52);
    const shadowSoft = rgbaFromHex(solid, 0.18);
    const shadowStrong = rgbaFromHex(gradient, 0.28);

    const style = existing || document.createElement("style");
    style.id = THEME_STYLE_ID;
    style.textContent = `
      :root {
        --ldd-theme-solid: ${solid};
        --ldd-theme-gradient: ${gradient};
        --ldd-theme-accent: ${accentGradient};
        --ldd-theme-page: ${pageBackground};
        --ldd-theme-surface: ${surfaceBackground};
        --ldd-theme-border: ${borderTint};
        --ldd-theme-border-soft: ${softBorderTint};
        --ldd-theme-focus: ${focusTint};
        --ldd-theme-shadow-soft: 0 10px 28px ${shadowSoft};
        --ldd-theme-shadow-strong: 0 16px 40px ${shadowStrong};
      }

      html {
        background: var(--ldd-theme-page) fixed !important;
      }

      body {
        background: var(--ldd-theme-page) !important;
        color: #2b3854 !important;
      }

      body :where(
        .bg-white,
        [class*="bg-white"],
        [class*="bg-slate-"],
        [class*="bg-gray-"],
        [class*="bg-zinc-"],
        [class*="bg-neutral-"],
        [class*="card"],
        [class*="panel"],
        [role="dialog"]
      ):not(#ldd-enhancer-root):not(#ldd-enhancer-root *):not([id^="ldd-"]):not([class*="ldd-"]) {
        background: var(--ldd-theme-surface) !important;
        border-color: var(--ldd-theme-border-soft) !important;
        box-shadow: var(--ldd-theme-shadow-soft) !important;
      }

      body :where(
        header,
        [class*="topbar"],
        [class*="navbar"],
        [class*="border-b"]
      ):not(#ldd-enhancer-root):not(#ldd-enhancer-root *):not([id^="ldd-"]):not([class*="ldd-"]) {
        background-image: var(--ldd-theme-accent) !important;
        border-color: transparent !important;
        color: rgba(255, 255, 255, 0.95) !important;
      }

      body :where(
        header *,
        [class*="topbar"] *,
        [class*="navbar"] *
      ):not(#ldd-enhancer-root):not(#ldd-enhancer-root *):not([id^="ldd-"]):not([class*="ldd-"]) {
        color: inherit !important;
      }

      body :where(
        [class*="border-"],
        .border
      ):not(#ldd-enhancer-root):not(#ldd-enhancer-root *):not([id^="ldd-"]):not([class*="ldd-"]) {
        border-color: var(--ldd-theme-border-soft) !important;
      }

      body :where(
        button,
        [role="button"],
        .btn,
        a[class*="btn"]
      ):not(#ldd-enhancer-root):not(#ldd-enhancer-root *):not([id^="ldd-"]):not([class*="ldd-"]) {
        border-radius: 12px !important;
      }

      body :where(
        button[class*="bg-"],
        a[class*="bg-"],
        button[class*="primary"],
        .btn.primary,
        [data-variant="primary"]
      ):not(#ldd-enhancer-root):not(#ldd-enhancer-root *):not([id^="ldd-"]):not([class*="ldd-"]) {
        background-image: var(--ldd-theme-accent) !important;
        border-color: ${buttonBorder} !important;
        color: #ffffff !important;
      }

      body :where(
        input,
        textarea,
        select
      ):not(#ldd-enhancer-root):not(#ldd-enhancer-root *):not([id^="ldd-"]):not([class*="ldd-"]) {
        background: rgba(255, 255, 255, 0.98) !important;
        border: 1px solid var(--ldd-theme-border) !important;
        border-radius: 12px !important;
        color: #2b3854 !important;
      }

      body :where(input, textarea):not(#ldd-enhancer-root):not(#ldd-enhancer-root *):not([id^="ldd-"]):not([class*="ldd-"])::placeholder {
        color: #8a95ad !important;
      }

      body :where(
        input:focus,
        textarea:focus,
        select:focus
      ):not(#ldd-enhancer-root):not(#ldd-enhancer-root *):not([id^="ldd-"]):not([class*="ldd-"]) {
        border-color: ${gradient} !important;
        box-shadow: 0 0 0 3px var(--ldd-theme-focus) !important;
        outline: none !important;
      }

      body :where(
        [class*="shadow"],
        .shadow
      ):not(#ldd-enhancer-root):not(#ldd-enhancer-root *):not([id^="ldd-"]):not([class*="ldd-"]) {
        box-shadow: var(--ldd-theme-shadow-strong) !important;
      }

      body *:not(#ldd-enhancer-root):not(#ldd-enhancer-root *)::-webkit-scrollbar {
        width: 10px;
        height: 10px;
      }

      body *:not(#ldd-enhancer-root):not(#ldd-enhancer-root *)::-webkit-scrollbar-thumb {
        background: var(--ldd-theme-accent);
        border-radius: 999px;
      }
    `;

    if (!existing) {
      document.documentElement.appendChild(style);
    }
    existingOverlay?.remove();
  }

  function isListingsPage() {
    const host = (window.location.hostname || "").toLowerCase();
    const path = (window.location.pathname || "").replace(/\/+$/, "");
    const validHost = host.includes("mydesigns.io");
    return validHost && path.includes("/app/list");
  }

  function applyFeatureSettings(settings) {
    const listingsPage = isListingsPage();
    applyGlobalTheme(settings);

    if (settings.enhancerEnabled && listingsPage) {
      window.LDDEnhancer?.enable?.();
    } else {
      window.LDDEnhancer?.disable?.();
    }

    if (settings.qaBarEnabled && listingsPage) {
      window.LDDQaBar?.enable?.();
    } else {
      window.LDDQaBar?.disable?.();
    }

    if (settings.dropperEnabled && listingsPage) {
      window.LDDDropper?.enable?.();
    } else {
      window.LDDDropper?.disable?.();
    }

    visionPresetsEnabled = Boolean(settings.visionAIPresetsEnabled ?? true);
    if (!visionPresetsEnabled) {
      document.getElementById(VISION_PRESET_BLOCK_ID)?.remove();
      visionMountedRoot = null;
    }
  }

  async function loadAndApplySettings() {
    try {
      if (!extensionStorage) {
        applyFeatureSettings(DEFAULT_SETTINGS);
        return;
      }
      const settings = await extensionStorage.get(DEFAULT_SETTINGS);
      applyFeatureSettings(settings);
    } catch (_error) {
      applyFeatureSettings(DEFAULT_SETTINGS);
    }
  }

  function findPasteTarget() {
    const selectors = [
      'textarea[placeholder*="emojis"]',
      'textarea[placeholder*="keyword"]',
      'textarea[placeholder*="title"]',
      'textarea',
      'input[type="text"]'
    ];

    for (const selector of selectors) {
      const element = document.querySelector(selector);
      if (element && typeof element.focus === "function") return element;
    }

    return null;
  }

  function pasteIntoPage(text) {
    const target = findPasteTarget();
    if (!target) return false;

    target.focus();
    target.value = text;
    target.dispatchEvent(new Event("input", { bubbles: true }));
    target.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }

  const VISION_PRESET_STYLE_ID = "ldd-vision-preset-style";
  const VISION_PRESET_BLOCK_ID = "ldd-vision-preset-block";
  const VISION_PRESET_TYPES = ["PNG", "SVG", "TUMBLER WRAP", "MUG WRAP"];
  const VISION_PRESET_LOGO_URL =
    extensionRuntime?.getURL?.("assets/logo.png") ||
    "https://raw.githubusercontent.com/lavenderdragondesign/lddupscalermodels/main/download%20(21).png";
  const VISION_RUN_INTERVAL_MS = 1100;
  const VISION_RUN_DEBOUNCE_MS = 200;

  const VISION_PM_STYLE_ID = "ldd-vision-pm-style";
  const VISION_PM_BUTTON_ID = "ldd-vision-pm-button";
  const VISION_PM_MODAL_ID = "ldd-vision-pm-modal";
  const VISION_AUTO_ENABLE_KEY = "visionAIAutoEnableCI";

  let visionRunScheduled = false;
  let visionMountedRoot = null;
  let visionWriteInProgress = false;
  let visionPresetsEnabled = true;
  let visionCIAutoCheckedForRoot = null;

  function norm(value) {
    return String(value || "").replace(/\s+/g, " ").trim().toLowerCase();
  }

  function isElementVisible(el) {
    if (!el) return false;
    const s = window.getComputedStyle(el);
    return s.display !== "none" && s.visibility !== "hidden" &&
      (el.offsetParent !== null || el.getClientRects().length > 0);
  }

  function setInputValue(input, value) {
    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")?.set;
    if (setter) setter.call(input, value); else input.value = value;
    input.dispatchEvent(new Event("input",  { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function findVisionModalRoot() {
    const all = Array.from(document.querySelectorAll("div,form")).filter((n) => {
      const t = norm(n.textContent || "");
      return t.includes("vision ai") &&
        t.includes("generate listing data based on your design") &&
        t.includes("select product type");
    });
    if (!all.length) return null;
    let best = all[0], bestDepth = Infinity;
    for (const c of all) {
      let d = 0, n = c; while (n) { d++; n = n.parentElement; }
      if (d < bestDepth) { bestDepth = d; best = c; }
    }
    return best;
  }

  function findVisionCustomTypeInput(root) {
    const scope = root || document;
    const inp = scope.querySelector('input[maxlength="150"]');
    return (inp && isElementVisible(inp)) ? inp : null;
  }

  function ensureVisionPresetStyle() {
    if (document.getElementById(VISION_PRESET_STYLE_ID)) return;
    const s = document.createElement("style");
    s.id = VISION_PRESET_STYLE_ID;
    s.textContent =
      "#" + VISION_PRESET_BLOCK_ID + "{display:flex;align-items:center;gap:5px;margin-bottom:6px;}" +
      "#" + VISION_PRESET_BLOCK_ID + " .ldd-logo{width:14px;height:14px;border-radius:3px;object-fit:cover;flex-shrink:0;}" +
      "#" + VISION_PRESET_BLOCK_ID + " .ldd-chips{display:flex;gap:4px;flex-wrap:wrap;}" +
      "#" + VISION_PRESET_BLOCK_ID + " .ldd-chip{display:inline-flex;align-items:center;gap:4px;padding:3px 6px 3px 10px;" +
        "border:1px solid #cbd5e1;border-radius:999px;background:#fff;color:#475569;font-size:11px;" +
        "font-weight:600;cursor:pointer;user-select:none;white-space:nowrap;line-height:1.4;font-family:inherit;}" +
      "#" + VISION_PRESET_BLOCK_ID + " .ldd-chip:hover{border-color:#6366f1;color:#4338ca;background:#eef2ff;}" +
      "#" + VISION_PRESET_BLOCK_ID + " .ldd-chip.checked{background:#6366f1;border-color:#6366f1;color:#fff;}" +
      "#" + VISION_PRESET_BLOCK_ID + " .ldd-chip-del{display:inline-flex;align-items:center;justify-content:center;" +
        "width:13px;height:13px;border-radius:50%;border:none;background:transparent;color:inherit;" +
        "font-size:10px;line-height:1;cursor:pointer;padding:0;opacity:0.55;flex-shrink:0;}" +
      "#" + VISION_PRESET_BLOCK_ID + " .ldd-chip-del:hover{opacity:1;background:rgba(0,0,0,0.12);}" +
      "#" + VISION_PRESET_BLOCK_ID + " .ldd-chip.checked .ldd-chip-del:hover{background:rgba(255,255,255,0.25);}" +
      "#" + VISION_PRESET_BLOCK_ID + " .ldd-add-row{display:inline-flex;align-items:center;gap:3px;flex-shrink:0;}" +
      "#" + VISION_PRESET_BLOCK_ID + " .ldd-add-input{height:24px;padding:0 7px;border:1px solid #cbd5e1;border-radius:999px;" +
        "font-size:11px;font-family:inherit;color:#334155;background:#fff;width:90px;outline:none;}" +
      "#" + VISION_PRESET_BLOCK_ID + " .ldd-add-input:focus{border-color:#6366f1;}" +
      "#" + VISION_PRESET_BLOCK_ID + " .ldd-add-btn{display:inline-flex;align-items:center;justify-content:center;" +
        "height:24px;width:24px;border:1px solid #cbd5e1;border-radius:50%;background:#fff;color:#6366f1;" +
        "font-size:15px;line-height:1;cursor:pointer;flex-shrink:0;font-weight:700;}" +
      "#" + VISION_PRESET_BLOCK_ID + " .ldd-add-btn:hover{border-color:#6366f1;background:#eef2ff;}" +
      "#" + VISION_PRESET_BLOCK_ID + " .ldd-chip-toggle{display:inline-flex;align-items:center;padding:2px 5px;" +
        "border:1px solid #e2e8f0;border-radius:6px;background:transparent;color:#94a3b8;font-size:11px;" +
        "cursor:pointer;user-select:none;line-height:1;margin-left:2px;flex-shrink:0;}" +
      "#" + VISION_PRESET_BLOCK_ID + " .ldd-chip-toggle:hover{border-color:#6366f1;color:#6366f1;background:#eef2ff;}";
    document.head.appendChild(s);
  }

  function buildVisionPresetBlock(root) {
    const block = document.createElement("div");
    block.id = VISION_PRESET_BLOCK_ID;

    const logo = document.createElement("img");
    logo.className = "ldd-logo";
    logo.src = VISION_PRESET_LOGO_URL;
    logo.alt = ""; logo.setAttribute("aria-hidden", "true");
    block.appendChild(logo);

    const chips = document.createElement("div");
    chips.className = "ldd-chips";
    block.appendChild(chips);

    // Inline add row
    const addRow = document.createElement("div");
    addRow.className = "ldd-add-row";
    const addInput = document.createElement("input");
    addInput.type = "text"; addInput.className = "ldd-add-input";
    addInput.placeholder = "Add type…"; addInput.maxLength = 40;
    const addBtn = document.createElement("button");
    addBtn.type = "button"; addBtn.className = "ldd-add-btn"; addBtn.title = "Add type"; addBtn.textContent = "+";
    addRow.appendChild(addInput); addRow.appendChild(addBtn);
    block.appendChild(addRow);

    // Collapse toggle
    const collapseBtn = document.createElement("button");
    collapseBtn.type = "button"; collapseBtn.className = "ldd-chip-toggle";
    collapseBtn.title = "Hide quick types"; collapseBtn.textContent = "▾";
    block.appendChild(collapseBtn);

    function syncInputField() {
      if (visionWriteInProgress) return;
      visionWriteInProgress = true;
      try {
        const sel = Array.from(chips.querySelectorAll(".ldd-chip[data-checked='1']"))
          .map((b) => b.dataset.type).filter(Boolean);
        const inp = findVisionCustomTypeInput(root);
        if (inp) setInputValue(inp, sel.join(", "));
      } finally { visionWriteInProgress = false; }
    }

    function makeChip(typeValue) {
      const chip = document.createElement("div");
      chip.className = "ldd-chip";
      chip.dataset.type = typeValue; chip.dataset.checked = "0";
      chip.setAttribute("role", "button"); chip.setAttribute("tabindex", "0");

      const label = document.createElement("span");
      label.textContent = typeValue;
      chip.appendChild(label);

      const del = document.createElement("button");
      del.type = "button"; del.className = "ldd-chip-del"; del.title = "Remove"; del.textContent = "×";
      chip.appendChild(del);

      function toggleChip() {
        const on = chip.dataset.checked === "1";
        chip.dataset.checked = on ? "0" : "1";
        chip.classList.toggle("checked", !on);
        syncInputField();
      }

      chip.addEventListener("click", (e) => {
        e.preventDefault(); e.stopPropagation();
        if (e.target === del) return; // del handles itself
        toggleChip();
      });
      chip.addEventListener("keydown", (e) => { if (e.key === " " || e.key === "Enter") { e.preventDefault(); toggleChip(); } });

      del.addEventListener("click", (e) => {
        e.preventDefault(); e.stopPropagation();
        chip.remove();
        const remaining = Array.from(chips.querySelectorAll(".ldd-chip"))
          .map((b) => b.dataset.type).filter(Boolean);
        chrome.storage.local.set({ visionAIPresetCustomTypes: remaining });
        syncInputField();
      });

      return chip;
    }

    function renderChips(types) {
      chips.innerHTML = "";
      types.forEach((t) => chips.appendChild(makeChip(t)));
    }

    function addType() {
      const val = addInput.value.trim().toUpperCase();
      if (!val) return;
      // don't add duplicates
      const existing = Array.from(chips.querySelectorAll(".ldd-chip")).map((b) => b.dataset.type);
      if (existing.includes(val)) { addInput.value = ""; return; }
      chips.appendChild(makeChip(val));
      addInput.value = "";
      const updated = [...existing, val];
      chrome.storage.local.set({ visionAIPresetCustomTypes: updated });
    }

    addBtn.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); addType(); });
    addInput.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); e.stopPropagation(); addType(); } });
    addInput.addEventListener("click", (e) => e.stopPropagation());
    addRow.addEventListener("click", (e) => e.stopPropagation());
    addRow.addEventListener("mousedown", (e) => e.stopPropagation());

    // Collapse logic
    function applyCollapsed(collapsed) {
      chips.style.display = collapsed ? "none" : "";
      addRow.style.display = collapsed ? "none" : "";
      collapseBtn.textContent = collapsed ? "▸" : "▾";
      collapseBtn.title = collapsed ? "Show quick types" : "Hide quick types";
    }
    collapseBtn.addEventListener("click", (e) => {
      e.preventDefault(); e.stopPropagation();
      const collapsed = chips.style.display === "none";
      applyCollapsed(!collapsed);
      chrome.storage.local.set({ visionAIPresetsCollapsed: !collapsed });
    });

    // Load types + collapsed state from storage
    chrome.storage.local.get({ visionAIPresetCustomTypes: null, visionAIPresetsCollapsed: false }, (r) => {
      const types = Array.isArray(r.visionAIPresetCustomTypes) ? r.visionAIPresetCustomTypes : [...VISION_PRESET_TYPES];
      renderChips(types);
      applyCollapsed(Boolean(r.visionAIPresetsCollapsed));
    });

    return block;
  }

  function mountVisionPresetBlock(root) {
    if (!root || !isElementVisible(root)) return;
    if (document.getElementById(VISION_PRESET_BLOCK_ID)?.isConnected) return;
    const inp = findVisionCustomTypeInput(root);
    if (!inp) return;
    ensureVisionPresetStyle();
    inp.parentElement.insertAdjacentElement("beforebegin", buildVisionPresetBlock(root));
  }

  function findVisionCIRow(root) {
    const scope = root || document;
    const nodes = Array.from(scope.querySelectorAll('label, div, span, p'));
    for (const node of nodes) {
      if (!isElementVisible(node)) continue;
      const text = norm(node.textContent || '');
      if (text === 'custom instructions' || text.startsWith('custom instructions ')) {
        return node.closest('label, div, section, form') || node.parentElement || node;
      }
    }
    return null;
  }

  function findVisionCICheckbox(root) {
    const row = findVisionCIRow(root);
    if (!row) return null;
    return row.querySelector('div[tabindex="0"], button[role="checkbox"], [aria-checked]') || row.previousElementSibling?.querySelector?.('div[tabindex="0"]') || null;
  }

  function isVisionCIChecked(root) {
    const box = findVisionCICheckbox(root);
    if (!box) return false;
    const aria = box.getAttribute('aria-checked');
    if (aria === 'true') return true;
    if (aria === 'false') return false;
    const svg = box.querySelector('svg');
    return !!svg && !svg.classList.contains('invisible');
  }

  function clickVisionCICheckbox(root) {
    const box = findVisionCICheckbox(root);
    if (!box) return false;
    ["pointerdown", "mousedown", "pointerup", "mouseup", "click"].forEach((type) => {
      box.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
    });
    if (typeof box.click === 'function') box.click();
    return true;
  }

  function ensureVisionCustomInstructionsEnabled(root) {
    if (!root || visionCIAutoCheckedForRoot === root) return;
    visionCIAutoCheckedForRoot = root;
    chrome.storage.local.get({ [VISION_AUTO_ENABLE_KEY]: true }, (settings) => {
      if (settings?.[VISION_AUTO_ENABLE_KEY] === false) return;
      window.setTimeout(() => {
        if (!root.isConnected) return;
        if (!isVisionCIChecked(root)) clickVisionCICheckbox(root);
      }, 180);
    });
  }

  function setTextareaValue(el, value) {
    if (!el) return false;
    const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value")?.set
      || Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")?.set;
    if (setter) setter.call(el, value); else el.value = value;
    el.focus();
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }

  function uid() {
    return `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
  }

  function escapeHTML(value) {
    return String(value || '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char] || char));
  }

  function copyPromptText(value) {
    const text = String(value || '');
    if (navigator.clipboard?.writeText) return navigator.clipboard.writeText(text);
    const area = document.createElement('textarea');
    area.value = text;
    area.setAttribute('readonly', 'readonly');
    area.style.position = 'fixed';
    area.style.opacity = '0';
    area.style.pointerEvents = 'none';
    document.body.appendChild(area);
    area.select();
    try { document.execCommand('copy'); } catch (_error) {}
    area.remove();
    return Promise.resolve();
  }

  function getClipboardItems() {
    return new Promise((resolve) => {
      chrome.storage.local.get({ clipboardItems: [] }, (data) => {
        const items = Array.isArray(data.clipboardItems) ? data.clipboardItems.slice() : [];
        resolve(items.sort((a, b) => Number(b.pinned || false) - Number(a.pinned || false) || Number(b.createdAt || 0) - Number(a.createdAt || 0)));
      });
    });
  }

  function setClipboardItems(items) {
    return new Promise((resolve) => chrome.storage.local.set({ clipboardItems: items }, resolve));
  }

  function makePromptPreview(value, maxLen = 160) {
    const text = String(value || '').trim();
    if (!text) return 'No content';
    return text.length > maxLen ? `${text.slice(0, maxLen)}...` : text;
  }

  function findVisionCITextarea(root) {
    const scope = root || document;
    const areas = Array.from(scope.querySelectorAll('textarea, input[type="text"]')).filter((el) => isElementVisible(el));
    const byPlaceholder = areas.find((el) => norm(el.getAttribute('placeholder') || '').includes('custom instruction'));
    if (byPlaceholder) return byPlaceholder;
    return areas.sort((a, b) => (b.clientHeight * b.clientWidth) - (a.clientHeight * a.clientWidth))[0] || null;
  }

  function ensureVisionPMStyle() {
    if (document.getElementById(VISION_PM_STYLE_ID)) return;
    const style = document.createElement('style');
    style.id = VISION_PM_STYLE_ID;
    style.textContent = `
      #${VISION_PM_BUTTON_ID}{display:inline-flex;align-items:center;gap:6px;margin-left:10px;padding:6px 10px;border-radius:999px;border:1px solid rgba(99,102,241,.22);background:#fff;color:#4f46e5;font-size:12px;font-weight:800;cursor:pointer;box-shadow:0 8px 22px rgba(79,70,229,.10);white-space:nowrap;}
      #${VISION_PM_BUTTON_ID}:hover{background:#eef2ff;border-color:rgba(99,102,241,.36);}
      #${VISION_PM_BUTTON_ID} img{width:18px;height:18px;border-radius:999px;object-fit:cover;flex-shrink:0;}
      #${VISION_PM_MODAL_ID}{position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;padding:18px;}
      #${VISION_PM_MODAL_ID} .ldd-pm-backdrop{position:absolute;inset:0;background:rgba(15,23,42,.38);backdrop-filter:blur(6px);}
      #${VISION_PM_MODAL_ID} .ldd-pm-card{position:relative;z-index:1;width:min(94vw,760px);max-height:min(88vh,820px);display:flex;flex-direction:column;gap:12px;background:#fff;border:1px solid rgba(148,163,184,.26);border-radius:28px;box-shadow:0 30px 70px rgba(15,23,42,.28);padding:18px;}
      #${VISION_PM_MODAL_ID} .ldd-pm-top{display:flex;align-items:center;justify-content:space-between;gap:12px;}
      #${VISION_PM_MODAL_ID} .ldd-pm-title-wrap{display:flex;flex-direction:column;gap:2px;}
      #${VISION_PM_MODAL_ID} .ldd-pm-title{display:flex;align-items:center;gap:10px;font-size:18px;font-weight:900;color:#1e2a3a;}
      #${VISION_PM_MODAL_ID} .ldd-pm-title img{width:28px;height:28px;border-radius:8px;object-fit:cover;}
      #${VISION_PM_MODAL_ID} .ldd-pm-sub{font-size:12px;color:#64748b;font-weight:600;}
      #${VISION_PM_MODAL_ID} .ldd-pm-close{width:36px;height:36px;border:none;border-radius:999px;background:#eef2f7;color:#475569;font-size:18px;font-weight:800;cursor:pointer;}
      #${VISION_PM_MODAL_ID} .ldd-pm-toolbar{display:grid;grid-template-columns:minmax(0,1fr) auto auto;gap:10px;align-items:center;}
      #${VISION_PM_MODAL_ID} .ldd-pm-search{height:42px;border-radius:14px;border:1px solid rgba(148,163,184,.28);padding:0 14px;font-size:13px;font-weight:600;color:#334155;background:#fff;outline:none;min-width:0;}
      #${VISION_PM_MODAL_ID} .ldd-pm-search:focus,#${VISION_PM_MODAL_ID} .ldd-pm-edit-name:focus,#${VISION_PM_MODAL_ID} .ldd-pm-edit-content:focus{border-color:#6366f1;box-shadow:0 0 0 3px rgba(99,102,241,.12);}
      #${VISION_PM_MODAL_ID} .ldd-pm-toolbar-btn,#${VISION_PM_MODAL_ID} .ldd-pm-action{height:38px;padding:0 14px;border-radius:12px;border:1px solid rgba(148,163,184,.24);background:#fff;color:#334155;font-size:12px;font-weight:800;cursor:pointer;}
      #${VISION_PM_MODAL_ID} .ldd-pm-toolbar-btn.primary,#${VISION_PM_MODAL_ID} .ldd-pm-action.primary{border:none;background:linear-gradient(180deg,#7c6bff,#5b4ef5);color:#fff;box-shadow:0 10px 22px rgba(91,78,245,.22);}
      #${VISION_PM_MODAL_ID} .ldd-pm-list{display:grid;gap:10px;overflow:auto;padding-right:4px;}
      #${VISION_PM_MODAL_ID} .ldd-pm-item{display:grid;gap:10px;padding:14px;border-radius:18px;border:1px solid rgba(148,163,184,.22);background:linear-gradient(180deg,#fff,#f8fafc);box-shadow:0 12px 24px rgba(15,23,42,.06);}
      #${VISION_PM_MODAL_ID} .ldd-pm-item.pinned{border-color:rgba(99,102,241,.28);box-shadow:0 18px 32px rgba(99,102,241,.12);}
      #${VISION_PM_MODAL_ID} .ldd-pm-head{display:flex;align-items:center;justify-content:space-between;gap:10px;}
      #${VISION_PM_MODAL_ID} .ldd-pm-name{font-size:14px;font-weight:900;color:#1e2a3a;display:flex;align-items:center;gap:8px;}
      #${VISION_PM_MODAL_ID} .ldd-pm-pin{font-size:12px;}
      #${VISION_PM_MODAL_ID} .ldd-pm-preview{font-size:12px;line-height:1.55;color:#64748b;white-space:pre-wrap;word-break:break-word;}
      #${VISION_PM_MODAL_ID} .ldd-pm-actions{display:flex;flex-wrap:wrap;gap:8px;}
      #${VISION_PM_MODAL_ID} .ldd-pm-action.danger{color:#b91c1c;border-color:rgba(239,68,68,.18);background:#fff5f5;}
      #${VISION_PM_MODAL_ID} .ldd-pm-edit{display:grid;gap:10px;}
      #${VISION_PM_MODAL_ID} .ldd-pm-edit-name,#${VISION_PM_MODAL_ID} .ldd-pm-edit-content{width:100%;border-radius:14px;border:1px solid rgba(148,163,184,.28);padding:12px 14px;font-size:13px;font-weight:600;color:#334155;background:#fff;outline:none;}
      #${VISION_PM_MODAL_ID} .ldd-pm-edit-content{min-height:140px;resize:vertical;font-family:inherit;line-height:1.5;}
      #${VISION_PM_MODAL_ID} .ldd-pm-empty{padding:20px;border-radius:18px;border:1px dashed rgba(148,163,184,.35);text-align:center;color:#64748b;font-size:13px;font-weight:700;background:#f8fafc;}
      @media (max-width: 640px){
        #${VISION_PM_MODAL_ID} .ldd-pm-card{width:min(96vw,96vw);padding:14px;border-radius:22px;}
        #${VISION_PM_MODAL_ID} .ldd-pm-toolbar{grid-template-columns:1fr 1fr;}
        #${VISION_PM_MODAL_ID} .ldd-pm-search{grid-column:1 / -1;}
      }
    `;
    document.head.appendChild(style);
  }

  function closeVisionPromptManager() {
    document.getElementById(VISION_PM_MODAL_ID)?.remove();
  }

  function openVisionPromptManager(root) {
    ensureVisionPMStyle();
    closeVisionPromptManager();
    const modal = document.createElement('div');
    modal.id = VISION_PM_MODAL_ID;
    modal.innerHTML = `
      <div class="ldd-pm-backdrop"></div>
      <div class="ldd-pm-card">
        <div class="ldd-pm-top">
          <div class="ldd-pm-title-wrap">
            <div class="ldd-pm-title"><img src="${VISION_PRESET_LOGO_URL}" alt="" /><span>Prompt Manager</span></div>
            <div class="ldd-pm-sub">Same prompt library, just quick-launched inside Vision AI.</div>
          </div>
          <button type="button" class="ldd-pm-close">×</button>
        </div>
        <div class="ldd-pm-toolbar">
          <input type="text" class="ldd-pm-search" placeholder="Search prompts..." />
          <button type="button" class="ldd-pm-toolbar-btn" data-role="use-last">Use Last</button>
          <button type="button" class="ldd-pm-toolbar-btn primary" data-role="new">New Prompt</button>
        </div>
        <div class="ldd-pm-list"></div>
      </div>
    `;
    document.body.appendChild(modal);
    const search = modal.querySelector('.ldd-pm-search');
    const list = modal.querySelector('.ldd-pm-list');
    const close = () => closeVisionPromptManager();
    const state = { items: [], search: '', editingId: null };

    const saveItems = async () => {
      await setClipboardItems(state.items);
    };

    const pastePromptToCI = (content) => {
      if (!isVisionCIChecked(root)) clickVisionCICheckbox(root);
      window.setTimeout(() => {
        const target = findVisionCITextarea(root) || findPasteTarget();
        const ok = setTextareaValue(target, String(content || ''));
        if (ok) closeVisionPromptManager();
      }, 90);
    };

    const sortedFilteredItems = () => {
      const q = norm(state.search || '');
      return state.items
        .filter((item) => !q || norm(item.name || '').includes(q) || norm(item.content || '').includes(q))
        .sort((a, b) => Number(b.pinned || false) - Number(a.pinned || false) || Number(b.createdAt || 0) - Number(a.createdAt || 0));
    };

    const render = () => {
      const filtered = sortedFilteredItems();
      list.innerHTML = '';
      if (!filtered.length) {
        list.innerHTML = '<div class="ldd-pm-empty">No saved prompts yet.</div>';
        return;
      }
      filtered.forEach((item) => {
        const card = document.createElement('div');
        card.className = `ldd-pm-item ${item.pinned ? 'pinned' : ''}`.trim();

        if (item.id === state.editingId) {
          card.innerHTML = `
            <div class="ldd-pm-edit">
              <input type="text" class="ldd-pm-edit-name" maxlength="80" value="${escapeHTML(item.name || '')}" placeholder="Prompt name..." />
              <textarea class="ldd-pm-edit-content" placeholder="Prompt content...">${escapeHTML(item.content || '')}</textarea>
              <div class="ldd-pm-actions">
                <button type="button" class="ldd-pm-action primary" data-action="save">Save</button>
                <button type="button" class="ldd-pm-action" data-action="cancel">Cancel</button>
              </div>
            </div>
          `;
          card.querySelector('[data-action="save"]')?.addEventListener('click', async () => {
            const name = (card.querySelector('.ldd-pm-edit-name')?.value || '').trim() || 'Untitled';
            const content = (card.querySelector('.ldd-pm-edit-content')?.value || '').trim();
            const target = state.items.find((entry) => entry.id === item.id);
            if (target) {
              target.name = name;
              target.content = content;
              target.createdAt = target.createdAt || Date.now();
              await saveItems();
            }
            state.editingId = null;
            render();
          });
          card.querySelector('[data-action="cancel"]')?.addEventListener('click', async () => {
            const target = state.items.find((entry) => entry.id === item.id);
            if (target && !target.content && (target.name === 'New Prompt' || target.name === 'Untitled')) {
              state.items = state.items.filter((entry) => entry.id !== item.id);
              await saveItems();
            }
            state.editingId = null;
            render();
          });
          list.appendChild(card);
          window.setTimeout(() => card.querySelector('.ldd-pm-edit-name')?.focus(), 20);
          return;
        }

        card.innerHTML = `
          <div class="ldd-pm-head">
            <div class="ldd-pm-name">${item.pinned ? '<span class="ldd-pm-pin">📌</span>' : ''}<span>${escapeHTML(item.name || 'Untitled')}</span></div>
          </div>
          <div class="ldd-pm-preview">${escapeHTML(makePromptPreview(item.content))}</div>
          <div class="ldd-pm-actions">
            <button type="button" class="ldd-pm-action primary" data-action="paste">Paste to CI</button>
            <button type="button" class="ldd-pm-action" data-action="copy">Copy</button>
            <button type="button" class="ldd-pm-action" data-action="edit">Edit</button>
            <button type="button" class="ldd-pm-action" data-action="pin">${item.pinned ? 'Unpin' : 'Pin'}</button>
            <button type="button" class="ldd-pm-action danger" data-action="delete">Delete</button>
          </div>
        `;
        card.querySelector('[data-action="paste"]')?.addEventListener('click', () => pastePromptToCI(item.content));
        card.querySelector('[data-action="copy"]')?.addEventListener('click', async (event) => {
          await copyPromptText(item.content || '');
          const btn = event.currentTarget;
          const prev = btn.textContent;
          btn.textContent = 'Copied!';
          window.setTimeout(() => { btn.textContent = prev; }, 700);
        });
        card.querySelector('[data-action="edit"]')?.addEventListener('click', () => {
          state.editingId = item.id;
          render();
        });
        card.querySelector('[data-action="pin"]')?.addEventListener('click', async () => {
          const target = state.items.find((entry) => entry.id === item.id);
          if (!target) return;
          target.pinned = !target.pinned;
          await saveItems();
          render();
        });
        card.querySelector('[data-action="delete"]')?.addEventListener('click', async () => {
          state.items = state.items.filter((entry) => entry.id !== item.id);
          await saveItems();
          render();
        });
        list.appendChild(card);
      });
    };

    modal.querySelector('.ldd-pm-backdrop')?.addEventListener('click', close);
    modal.querySelector('.ldd-pm-close')?.addEventListener('click', close);
    search?.addEventListener('input', () => {
      state.search = search.value || '';
      render();
    });
    modal.querySelector('[data-role="new"]')?.addEventListener('click', async () => {
      const newItem = { id: uid(), name: 'New Prompt', content: '', pinned: false, createdAt: Date.now() };
      state.items.unshift(newItem);
      await saveItems();
      state.editingId = newItem.id;
      render();
    });
    modal.querySelector('[data-role="use-last"]')?.addEventListener('click', () => {
      const latest = state.items.slice().sort((a, b) => Number(b.createdAt || 0) - Number(a.createdAt || 0))[0];
      if (latest) pastePromptToCI(latest.content || '');
    });

    getClipboardItems().then((items) => {
      state.items = items;
      render();
      window.setTimeout(() => search?.focus(), 20);
    });
  }

  function injectVisionPromptManagerButton(root) {
    if (!root || !root.isConnected) return;
    ensureVisionPMStyle();
    const existing = root.querySelector('#' + VISION_PM_BUTTON_ID);
    if (existing) return;
    const row = findVisionCIRow(root);
    if (!row) return;
    const anchor = row.querySelector('span, p, div') || row;
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.id = VISION_PM_BUTTON_ID;
    btn.innerHTML = `<img src="${VISION_PRESET_LOGO_URL}" alt="" /><span>Prompt Manager</span>`;
    btn.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      openVisionPromptManager(root);
    });
    if (anchor && anchor.parentElement === row) {
      anchor.insertAdjacentElement('afterend', btn);
    } else {
      row.appendChild(btn);
    }
  }

  function runVisionPreset() {
    if (!visionPresetsEnabled) return;
    const root = findVisionModalRoot();
    if (!root) {
      if (visionMountedRoot) {
        document.getElementById(VISION_PRESET_BLOCK_ID)?.remove();
        closeVisionPromptManager();
        visionMountedRoot = null;
        visionCIAutoCheckedForRoot = null;
        visionWriteInProgress = false;
      }
      return;
    }
    if (root !== visionMountedRoot) {
      document.getElementById(VISION_PRESET_BLOCK_ID)?.remove();
      closeVisionPromptManager();
      visionMountedRoot = root;
      visionCIAutoCheckedForRoot = null;
    }
    mountVisionPresetBlock(root);
    ensureVisionCustomInstructionsEnabled(root);
    injectVisionPromptManagerButton(root);
  }

  function queueVisionPresetRun(delay) {
    if (visionRunScheduled) return;
    visionRunScheduled = true;
    window.setTimeout(() => { visionRunScheduled = false; runVisionPreset(); },
      delay != null ? delay : VISION_RUN_DEBOUNCE_MS);
  }

    window.setInterval(() => queueVisionPresetRun(0), VISION_RUN_INTERVAL_MS);
  const visionPresetObserver = new MutationObserver(() => queueVisionPresetRun());
  visionPresetObserver.observe(document.body || document.documentElement, { childList: true, subtree: true });
  queueVisionPresetRun(0);
  loadAndApplySettings();

  // The SPA may not have fully rendered on first load. Poll every 1200ms for
  // up to 24s and re-apply settings until the enhancer is actually mounted.
  // Using 1200ms (longer than bindEvents takes) prevents concurrent enable()
  // calls that would race and tear out each other's DOM roots.
  let _startupTicks = 0;
  const _startupPoll = window.setInterval(() => {
    _startupTicks++;
    if (window.LDDEnhancer?.isOpen !== undefined && document.getElementById("ldd-enhancer-root")) {
      window.clearInterval(_startupPoll);
      return;
    }
    loadAndApplySettings();
    if (_startupTicks >= 20) window.clearInterval(_startupPoll);
  }, 1200);

  let lastKnownLocation = window.location.href || "";
  window.setInterval(() => {
    const currentLocation = window.location.href || "";
    if (currentLocation === lastKnownLocation) return;
    lastKnownLocation = currentLocation;
    loadAndApplySettings();
  }, 250);

  if (typeof chrome !== "undefined" && chrome?.storage?.onChanged?.addListener) {
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName !== "local") return;
      if (!changes.enhancerEnabled && !changes.qaBarEnabled && !changes.dropperEnabled &&
          !changes.visionAIPresetsEnabled && !changes.visionAIAutoEnableCI &&
          !changes.globalThemeEnabled && !changes.globalThemeMode &&
          !changes.globalThemeSolidColor && !changes.globalThemeGradientColor &&
          !changes.globalThemeBrightness) return;
      extensionStorage?.get(DEFAULT_SETTINGS).then((settings) => applyFeatureSettings(settings));
    });
  }

  if (typeof chrome !== "undefined" && chrome?.runtime?.onMessage?.addListener) {
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (message?.type === "ldd/paste" && typeof message.text === "string") {
        const ok = pasteIntoPage(message.text);
        sendResponse({ ok });
        return true;
      }
      if (message?.type === "ldd/ping") {
        sendResponse({ ok: true, url: window.location.href });
        return true;
      }
      return false;
    });
  }


  // ── Video Mockup Smart Selection Buttons ─────────────────────────────────
  const LDD_VM_BAR_ID = "ldd-vm-select-bar";
  const LDD_VM_LOGO_URL = chrome.runtime.getURL("assets/logo.png");

  function vmSleep(ms) {
    return new Promise((resolve) => window.setTimeout(resolve, ms));
  }

  function hardClick(element) {
    if (!element) return false;
    ["pointerdown", "mousedown", "pointerup", "mouseup", "click"].forEach((type) => {
      element.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
    });
    if (typeof element.click === "function") element.click();
    return true;
  }

  function isSlotFilled(slotEl) {
    const img = slotEl.querySelector("img");
    if (!img) return false;
    if ((img.className || "").includes("opacity-10")) return false;
    if ((img.alt || "").trim() === "MyDesigns Logo") return false;
    const src = (img.getAttribute("src") || "").trim();
    if (!src) return false;
    return true;
  }

  function getVideoMockupModal() {
    return Array.from(document.querySelectorAll("div[role='dialog'], div")).find((el) => {
      if (!el.querySelector) return false;
      const text = norm(el.textContent || "");
      return text.includes("create video mockups") && text.includes("clear all") && !!el.querySelector('[class*="aspect-square"], .aspect-square');
    }) || null;
  }

  function getSlotItems(modal) {
    if (!modal) return [];
    const grid = modal.querySelector('[data-v-0ef3f0b1][class*="grid"], [class*="grid"]');
    const scope = grid || modal;
    const cards = Array.from(scope.querySelectorAll('.aspect-square, [class*="aspect-square"]'));
    const seen = new Set();
    return cards.map((card) => card.closest('[data-v-0ef3f0b1].flex.flex-col.items-center, .flex.flex-col.items-center, label, button, div') || card).filter((item) => {
      if (!item || seen.has(item)) return false;
      seen.add(item);
      return true;
    });
  }

  function clickSlot(slotItem) {
    const target =
      slotItem?.querySelector?.('input[type="checkbox"], input[type="radio"]') ||
      slotItem?.querySelector?.('button[role="checkbox"], [aria-checked], [role="button"]') ||
      slotItem?.querySelector?.('.aspect-square, [class*="aspect-square"]') ||
      slotItem;
    return hardClick(target);
  }

  function clearAllSlots(modal) {
    const clearBtn = Array.from(modal.querySelectorAll("button, div, span")).find((el) =>
      norm(el.textContent) === "clear all" && isElementVisible(el)
    );
    return hardClick(clearBtn);
  }

  async function applyVideoMockupSelection(modal, picker) {
    if (!modal) return;
    clearAllSlots(modal);
    await vmSleep(140);
    let items = getSlotItems(modal);
    if (!items.length) {
      await vmSleep(220);
      items = getSlotItems(modal);
    }
    const picked = picker(items).filter(Boolean);
    for (const item of picked) {
      clickSlot(item);
      await vmSleep(24);
    }
  }

  function injectVideoMockupBar(modal) {
    if (modal.querySelector("#" + LDD_VM_BAR_ID)) return;

    const grid = modal.querySelector('[data-v-0ef3f0b1][class*="grid"]');
    if (!grid) return;

    const bar = document.createElement("div");
    bar.id = LDD_VM_BAR_ID;
    bar.style.cssText = [
      "display:flex",
      "align-items:center",
      "gap:12px",
      "margin:0 0 12px 0",
      "padding:10px 12px",
      "flex-wrap:wrap",
      "border-radius:16px",
      "border:1px solid rgba(30,41,59,.10)",
      "background:linear-gradient(180deg, rgba(255,255,255,.98), rgba(248,250,252,.96))",
      "box-shadow:0 12px 32px rgba(15,23,42,.08)"
    ].join(";") + ";";

    const label = document.createElement("div");
    label.style.cssText = [
      "display:flex",
      "align-items:center",
      "gap:8px",
      "font-size:11px",
      "font-weight:900",
      "letter-spacing:.08em",
      "text-transform:uppercase",
      "color:#475569",
      "white-space:nowrap",
      "padding:0 2px"
    ].join(";") + ";";
    const labelLogo = document.createElement("img");
    labelLogo.src = LDD_VM_LOGO_URL;
    labelLogo.alt = "LDD";
    labelLogo.style.cssText = "width:18px;height:18px;object-fit:contain;border-radius:5px;flex:0 0 18px;";
    const labelText = document.createElement("span");
    labelText.textContent = "Quick Select";
    label.append(labelLogo, labelText);

    const dock = document.createElement("div");
    dock.style.cssText = [
      "display:flex",
      "align-items:center",
      "gap:8px",
      "flex-wrap:wrap",
      "padding:6px",
      "border-radius:14px",
      "border:1px solid rgba(30,41,59,.08)",
      "background:rgba(255,255,255,.72)",
      "box-shadow:inset 0 1px 0 rgba(255,255,255,.75)"
    ].join(";") + ";";

    function makeBtn(text, onClick, accent = false) {
      const b = document.createElement("button");
      b.type = "button";
      b.textContent = text;
      const baseBg = accent ? "linear-gradient(180deg, #2f3d58, #1e2a3a)" : "linear-gradient(180deg, #ffffff, #f8fafc)";
      const hoverBg = accent ? "linear-gradient(180deg, #394b6a, #243246)" : "linear-gradient(180deg, #ffffff, #eef2f7)";
      const baseColor = accent ? "#ffffff" : "#334155";
      b.style.cssText = [
        "height:34px",
        "padding:0 14px",
        "border-radius:10px",
        `border:1px solid ${accent ? "rgba(30,42,58,.42)" : "rgba(148,163,184,.28)"}`,
        `background:${baseBg}`,
        `color:${baseColor}`,
        "font-size:12px",
        "font-weight:800",
        "cursor:pointer",
        "white-space:nowrap",
        "box-shadow:0 6px 16px rgba(15,23,42,.08)",
        "transition:transform .12s ease, box-shadow .12s ease, background .12s ease, color .12s ease"
      ].join(";") + ";";
      b.addEventListener("mouseenter", () => {
        b.style.background = hoverBg;
        b.style.transform = "translateY(-1px)";
        b.style.boxShadow = "0 10px 20px rgba(15,23,42,.12)";
      });
      b.addEventListener("mouseleave", () => {
        b.style.background = baseBg;
        b.style.transform = "translateY(0)";
        b.style.boxShadow = "0 6px 16px rgba(15,23,42,.08)";
      });
      b.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        onClick();
      });
      return b;
    }

    const buttonSpecs = [
      { label: "First 1", picker: (items) => items.slice(0, 1) },
      { label: "First 3", picker: (items) => items.slice(0, 3) },
      { label: "First 5", picker: (items) => items.slice(0, 5) },
      { label: "First 8", picker: (items) => items.slice(0, 8) },
      { label: "First 10", picker: (items) => items.slice(0, 10) },
      { label: "First 12", picker: (items) => items.slice(0, 12) },
      { label: "First 15", picker: (items) => items.slice(0, 15) },
      { label: "First 20", picker: (items) => items.slice(0, 20) },
      { label: "All Filled", picker: (items) => items.filter(isSlotFilled), accent: true },
      { label: "Skip 1", picker: (items) => items.filter(isSlotFilled).slice(1) },
      { label: "Skip 2", picker: (items) => items.filter(isSlotFilled).slice(2) },
      { label: "Skip 3", picker: (items) => items.filter(isSlotFilled).slice(3) }
    ];

    const modalWrap = document.createElement("div");
    modalWrap.style.cssText = [
      "position:fixed",
      "inset:0",
      "z-index:2147483647",
      "display:none",
      "align-items:center",
      "justify-content:center"
    ].join(";") + ";";

    const backdrop = document.createElement("div");
    backdrop.style.cssText = [
      "position:absolute",
      "inset:0",
      "background:rgba(15,23,42,.42)",
      "backdrop-filter:blur(6px)"
    ].join(";") + ";";

    const card = document.createElement("div");
    card.style.cssText = [
      "position:relative",
      "z-index:1",
      "width:min(92vw, 360px)",
      "border-radius:22px",
      "border:1px solid rgba(148,163,184,.26)",
      "background:#ffffff",
      "box-shadow:0 26px 70px rgba(15,23,42,.24)",
      "padding:18px"
    ].join(";") + ";";
    card.innerHTML = `
      <button type="button" data-vm-close="1" style="position:absolute;top:12px;right:12px;width:34px;height:34px;border:none;border-radius:999px;background:#f1f5f9;color:#475569;font-size:18px;font-weight:700;cursor:pointer;">×</button>
      <div style="font-size:18px;font-weight:900;color:#1e2a3a;margin-bottom:4px;">Select Filled (Custom)</div>
      <div style="font-size:12px;line-height:1.5;color:#64748b;margin-bottom:14px;">Pick the slot range to scan, then it will select only the filled ones inside that range.</div>
      <div style="display:grid;gap:12px;">
        <label style="display:grid;gap:6px;font-size:12px;font-weight:800;color:#334155;">
          Start Slot
          <input data-vm-start type="number" min="1" value="2" style="height:40px;border-radius:12px;border:1px solid rgba(148,163,184,.34);padding:0 12px;font-size:14px;font-weight:700;color:#1e293b;background:#fff;" />
        </label>
        <label style="display:grid;gap:6px;font-size:12px;font-weight:800;color:#334155;">
          End Slot
          <input data-vm-end type="number" min="1" value="10" style="height:40px;border-radius:12px;border:1px solid rgba(148,163,184,.34);padding:0 12px;font-size:14px;font-weight:700;color:#1e293b;background:#fff;" />
        </label>
        <label style="display:flex;align-items:center;gap:10px;font-size:12px;font-weight:700;color:#475569;">
          <input data-vm-skip type="checkbox" checked style="width:16px;height:16px;accent-color:#1e2a3a;" />
          Skip first filled slot
        </label>
      </div>
      <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:16px;">
        <button type="button" data-vm-close="1" style="height:38px;padding:0 14px;border-radius:12px;border:1px solid rgba(148,163,184,.28);background:#fff;color:#475569;font-size:12px;font-weight:800;cursor:pointer;">Cancel</button>
        <button type="button" data-vm-apply="1" style="height:38px;padding:0 16px;border:none;border-radius:12px;background:linear-gradient(180deg, #2f3d58, #1e2a3a);color:#fff;font-size:12px;font-weight:900;cursor:pointer;box-shadow:0 10px 20px rgba(30,42,58,.22);">Apply</button>
      </div>
    `;

    function closeCustomModal() {
      modalWrap.style.display = "none";
    }

    function openCustomModal() {
      const items = getSlotItems(modal);
      const startInput = card.querySelector('[data-vm-start]');
      const endInput = card.querySelector('[data-vm-end]');
      if (startInput) startInput.value = "2";
      if (endInput) endInput.value = String(Math.max(items.length, 10));
      modalWrap.style.display = "flex";
      setTimeout(() => startInput?.focus(), 20);
    }

    modalWrap.addEventListener("click", (event) => {
      if (event.target === modalWrap || event.target === backdrop || event.target?.dataset?.vmClose) closeCustomModal();
    });
    card.querySelector('[data-vm-apply]')?.addEventListener("click", async () => {
      const start = Number(card.querySelector('[data-vm-start]')?.value || 1);
      const end = Number(card.querySelector('[data-vm-end]')?.value || 1);
      const skipFirst = !!card.querySelector('[data-vm-skip]')?.checked;
      const rangeStart = Math.max(1, Math.min(start, end));
      const rangeEnd = Math.max(rangeStart, Math.max(start, end));
      await applyVideoMockupSelection(modal, (items) => {
        const ranged = items.slice(rangeStart - 1, rangeEnd).filter(isSlotFilled);
        return skipFirst ? ranged.slice(1) : ranged;
      });
      closeCustomModal();
    });

    bar.appendChild(label);
    buttonSpecs.forEach(({ label, picker, accent }) => {
      dock.appendChild(makeBtn(label, () => applyVideoMockupSelection(modal, picker), Boolean(accent)));
    });
    bar.appendChild(dock);
    grid.parentElement.insertBefore(bar, grid);
  }

  // Observe for the Video Mockups modal opening
  const vmModalObserver = new MutationObserver(() => {
    const modal = getVideoMockupModal();
    if (modal) injectVideoMockupBar(modal);
  });
  vmModalObserver.observe(document.body || document.documentElement, { childList: true, subtree: true });

  // ── Keyboard shortcuts + cheatsheet card ─────────────────────────────────


})();