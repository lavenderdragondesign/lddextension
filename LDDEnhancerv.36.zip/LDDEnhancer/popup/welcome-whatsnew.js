(function(){
  const VERSION = "v36";
  const VERSION_KEY = "lddWhatsNewSeenVersion";
  const HIDE_KEY = "lddWhatsNewNeverShow";
  const PENDING_KEY = "lddWhatsNewPendingOpen";

  const backdrop = document.getElementById("ldd-whats-new-backdrop");
  const closeBtn = document.getElementById("ldd-whats-new-close");
  const dontShow = document.getElementById("ldd-whats-new-dont-show");

  function shouldShow() {
    try {
      const neverShow = localStorage.getItem(HIDE_KEY) === "true";
      const seenVersion = localStorage.getItem(VERSION_KEY) || "";
      const pendingOpen = localStorage.getItem(PENDING_KEY) === "true";
      return !neverShow && pendingOpen && seenVersion !== VERSION;
    } catch (e) {
      return false;
    }
  }

  function saveAndClose() {
    try {
      localStorage.setItem(VERSION_KEY, VERSION);
      localStorage.removeItem(PENDING_KEY);
      localStorage.setItem(HIDE_KEY, "true");
    } catch (e) {}
    if (backdrop) backdrop.style.display = "none";
  }

  function bindOpenMdButton() {
    const openBtn = document.getElementById("ldd-open-md");
    if (!openBtn) return;
    openBtn.addEventListener("click", function(){
      try {
        chrome.storage.local.set({ lddWhatsNewPendingOpen: true });
      } catch (e) {}
    });
  }

  if (shouldShow() && backdrop) {
    window.addEventListener("load", function(){
      setTimeout(function () {
        backdrop.style.display = "flex";
      }, 240);
    });
  }

  bindOpenMdButton();

  if (closeBtn) closeBtn.addEventListener("click", saveAndClose);
  if (backdrop) {
    backdrop.addEventListener("click", function(e){
      if (e.target === backdrop) saveAndClose();
    });
  }
})();
