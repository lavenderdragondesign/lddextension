﻿(() => {
  try {
    document.documentElement.setAttribute("data-ldd-content-script-loaded", "1");
    document.documentElement.setAttribute("data-ldd-content-script-build", "20260328-vision-pm");
  } catch (_error) {
    // Ignore DOM marker failures.
  }
  const THEME_STYLE_ID = "ldd-global-theme-style";
  const THEME_OVERLAY_ID = "ldd-global-theme-overlay";
  const extensionRuntime =
    typeof chrome !== "undefined" && chrome?.runtime && typeof chrome.runtime.getURL === "function"
      ? chrome.runtime
      : null;
  const extensionStorage =
    typeof chrome !== "undefined" && chrome?.storage?.local && typeof chrome.storage.local.get === "function"
      ? chrome.storage.local
      : null;
  const DEFAULT_SETTINGS = {
    enhancerEnabled: true,
    qaBarEnabled: true,
    dropperEnabled: true,
    visionAIPresetsEnabled: true,
    globalThemeEnabled: false,
    globalThemeMode: "gradient",
    globalThemeSolidColor: "#1f4ed8",
    globalThemeGradientColor: "#7c3aed",
    globalThemeBrightness: 100,
    globalThemePreset: "bluePurple",
    globalThemeCustomPresets: []
  };
  const LDD_WHATS_NEW_VERSION = "v36";
  const LDD_WHATS_NEW_SEEN_KEY = "lddWhatsNewSeenVersion";
  const LDD_WHATS_NEW_HIDE_KEY = "lddWhatsNewNeverShow";
  const LDD_WHATS_NEW_PENDING_KEY = "lddWhatsNewPendingOpen";

  function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
  }

  function normalizeHexColor(value, fallback) {
    if (typeof value !== "string") return fallback;
    const trimmed = value.trim();
    if (/^#[0-9a-fA-F]{6}$/.test(trimmed)) return trimmed;
    if (/^#[0-9a-fA-F]{3}$/.test(trimmed)) {
      return `#${trimmed[1]}${trimmed[1]}${trimmed[2]}${trimmed[2]}${trimmed[3]}${trimmed[3]}`;
    }
    return fallback;
  }

  function rgbaFromHex(hexColor, alpha) {
    const safe = normalizeHexColor(hexColor, "#1f4ed8");
    const int = Number.parseInt(safe.slice(1), 16);
    const r = (int >> 16) & 255;
    const g = (int >> 8) & 255;
    const b = int & 255;
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
  }

  function adjustHexBrightness(hexColor, brightnessPercent) {
    const safe = normalizeHexColor(hexColor, "#1f4ed8");
    const int = Number.parseInt(safe.slice(1), 16);
    const factor = clamp(Number.parseFloat(brightnessPercent) || 100, 70, 130) / 100;
    const toHex = (channel) => clamp(Math.round(channel * factor), 0, 255).toString(16).padStart(2, "0");
    const r = toHex((int >> 16) & 255);
    const g = toHex((int >> 8) & 255);
    const b = toHex(int & 255);
    return `#${r}${g}${b}`;
  }

  function maybeOpenWhatsNew() {
    if (!extensionStorage) return;
    try {
      extensionStorage.get({
        [LDD_WHATS_NEW_HIDE_KEY]: false,
        [LDD_WHATS_NEW_PENDING_KEY]: false,
        [LDD_WHATS_NEW_SEEN_KEY]: ""
      }, (result) => {
        const neverShow = result?.[LDD_WHATS_NEW_HIDE_KEY] === true;
        const pendingOpen = result?.[LDD_WHATS_NEW_PENDING_KEY] === true;
        const seenVersion = result?.[LDD_WHATS_NEW_SEEN_KEY] || "";
        if (neverShow || !pendingOpen || seenVersion === LDD_WHATS_NEW_VERSION) return;
        extensionStorage.set({ [LDD_WHATS_NEW_PENDING_KEY]: false }, () => {
          window.setTimeout(() => {
            try {
              showWhatsNewModal();
            } catch (_error) {}
          }, 900);
        });
      });
    } catch (_error) {}
  }

  function closeWhatsNewModal(markSeen = true) {
    document.getElementById("ldd-whats-new-inline")?.remove();
    document.getElementById("ldd-whats-new-inline-style")?.remove();
    if (!markSeen || !extensionStorage) return;
    try {
      extensionStorage.set({
        [LDD_WHATS_NEW_SEEN_KEY]: LDD_WHATS_NEW_VERSION,
        [LDD_WHATS_NEW_HIDE_KEY]: true
      });
    } catch (_error) {}
  }

  function showWhatsNewModal() {
    if (document.getElementById("ldd-whats-new-inline")) return;

    const wrap = document.createElement("div");
    wrap.id = "ldd-whats-new-inline";
    wrap.innerHTML = `
      <div class="ldd-whats-new-inline-backdrop"></div>
      <div class="ldd-whats-new-inline-card" role="dialog" aria-modal="true" aria-label="What's New in v36">
        <div class="ldd-whats-new-inline-head">
          <img src="${chrome.runtime.getURL("assets/logo.png")}" alt="LDD" class="ldd-whats-new-inline-logo" />
          <div>
            <div class="ldd-whats-new-inline-title">LavenderDragonDesign's LDD MD Enhancer</div>
            <div class="ldd-whats-new-inline-kicker">What’s New in v36</div>
          </div>
        </div>
        <div class="ldd-whats-new-inline-intro">Big upgrade. This popup shows once after <strong>Open MD</strong> so people see the changes in the right place — inside the actual workflow.</div>
        <div class="ldd-whats-new-inline-grid">
          <div class="ldd-whats-new-inline-panel">
            <strong>🧩 Modular controls</strong>
            <ul class="ldd-whats-new-inline-bullets">
              <li>Toggle MD Enhancer separately</li>
              <li>Toggle Dock separately</li>
              <li>Toggle Drag &amp; Drop separately</li>
              <li>Toggle Auto Rename separately</li>
            </ul>
          </div>
          <div class="ldd-whats-new-inline-panel ldd-whats-new-inline-panel-main">
            <strong>🔥 Main focus in v36</strong>
            <ul class="ldd-whats-new-inline-bullets">
              <li><strong style="color:#111827;">Vision AI Profiles</strong> save and load your Vision AI setup faster so repeat workflows are easier to reuse.</li>
              <li><strong style="color:#111827;">Paste / Pull Dream</strong> makes Dream prompts easier to move, reuse, and drop into the right workflow.</li>
              <li><strong style="color:#111827;">Paste Saved Custom Instructions</strong> gives you faster paste-to-Custom-Instructions flow without rebuilding prompts every time.</li>
              <li><strong style="color:#111827;">Prompt Manager</strong> is the main hub for saved prompts, saved custom instructions, and Dream prompt workflows.</li>
            </ul>
          </div>
          <div class="ldd-whats-new-inline-panel">
            <strong>🎯 Dock wake hotspots</strong>
            <ul class="ldd-whats-new-inline-bullets">
              <li>Bottom-left wake hotspot</li>
              <li>Bottom-right wake hotspot</li>
              <li>MD Enhancer bubble wake point</li>
              <li>Three wake points, same dock</li>
            </ul>
          </div>
          <div class="ldd-whats-new-inline-panel">
            <strong>🧠 Vision AI Profiles + Dock focus</strong>
            <ul class="ldd-whats-new-inline-bullets">
              <li>Vision AI Profiles are a major focus in this version</li>
              <li>Better support for saving and loading profile workflows</li>
              <li>The dock is now the main UI direction</li>
              <li>Faster access to the tools you use most</li>
            </ul>
          </div>
          <div class="ldd-whats-new-inline-panel ldd-whats-new-inline-panel-fix">
            <strong>🐛 Fixed + improved</strong>
            <ul class="ldd-whats-new-inline-bullets">
              <li>Drag overlay no longer gets stuck</li>
              <li>Rename close now gives a real choice</li>
              <li>Settings bubble no longer vanishes when clicked</li>
              <li>Cleaner dock-first workflow overall</li>
            </ul>
          </div>
        </div>
        <div class="ldd-whats-new-inline-actions">
          <button type="button" data-ldd-whats-new-close="1">Got it</button>
        </div>
      </div>
    `;

    const style = document.createElement("style");
    style.id = "ldd-whats-new-inline-style";
    style.textContent = `
      #ldd-whats-new-inline{position:fixed;inset:0;z-index:2147483646;font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,sans-serif;}
      #ldd-whats-new-inline .ldd-whats-new-inline-backdrop{position:absolute;inset:0;background:rgba(15,23,42,.46);backdrop-filter:blur(4px);}
      #ldd-whats-new-inline .ldd-whats-new-inline-card{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:min(720px,94vw);min-height:min(860px,95vw);background:#fff;border:1px solid rgba(15,23,42,.08);border-radius:22px;box-shadow:0 18px 46px rgba(15,23,42,.12);padding:20px;display:flex;flex-direction:column;color:#172033;}
      #ldd-whats-new-inline .ldd-whats-new-inline-head{display:flex;align-items:center;gap:12px;margin-bottom:12px;}
      #ldd-whats-new-inline .ldd-whats-new-inline-logo{width:52px;height:52px;border-radius:14px;box-shadow:0 8px 18px rgba(63,94,251,.12);}
      #ldd-whats-new-inline .ldd-whats-new-inline-kicker{font-size:10px;font-weight:900;letter-spacing:.09em;text-transform:uppercase;color:#6b7280;}
      #ldd-whats-new-inline .ldd-whats-new-inline-title{margin-top:4px;font-size:23px;line-height:1.06;font-weight:900;color:#172033;}
      #ldd-whats-new-inline .ldd-whats-new-inline-intro{background:#eef4ff;border:1px solid #dbe6ff;border-radius:12px;padding:11px 12px;margin-bottom:10px;font-size:12px;color:#1e293b;line-height:1.55;font-weight:800;}
      #ldd-whats-new-inline .ldd-whats-new-inline-grid{display:grid;grid-template-columns:1fr 1.06fr 1fr;gap:8px;margin:10px 0 16px;flex:1;align-content:start;}
      #ldd-whats-new-inline .ldd-whats-new-inline-panel{border-radius:16px;padding:12px;min-height:132px;background:#f8fbff;border:1px solid #e5ecff;display:flex;flex-direction:column;gap:8px;}
      #ldd-whats-new-inline .ldd-whats-new-inline-panel-main{grid-column:2;grid-row:1 / span 2;min-height:272px;background:linear-gradient(180deg,#eef4ff 0%,#f8fbff 100%);border:1px solid #dbe6ff;}
      #ldd-whats-new-inline .ldd-whats-new-inline-panel-fix{background:#fff8f8;border-color:#fecaca;}
      #ldd-whats-new-inline .ldd-whats-new-inline-panel strong{font-size:16px;font-weight:900;color:#1f3bb3;}
      #ldd-whats-new-inline .ldd-whats-new-inline-panel-fix strong{color:#b91c1c;}
      #ldd-whats-new-inline .ldd-whats-new-inline-panel span,#ldd-whats-new-inline .ldd-whats-new-inline-panel li{font-size:11px;color:#4b5563;line-height:1.45;font-weight:700;}
      #ldd-whats-new-inline .ldd-whats-new-inline-bullets{list-style:disc;padding-left:16px;margin:0;display:grid;gap:5px;}
      #ldd-whats-new-inline .ldd-whats-new-inline-actions{display:flex;justify-content:center;gap:10px;margin-top:12px;}
      #ldd-whats-new-inline .ldd-whats-new-inline-actions button{padding:10px 14px;border-radius:11px;border:1px solid #d9e2f2;background:#fff;color:#334155;font-weight:900;font-size:12px;cursor:pointer;}
      @media (max-width:760px){#ldd-whats-new-inline .ldd-whats-new-inline-card{width:min(94vw,620px);border-radius:22px;padding:16px;}#ldd-whats-new-inline .ldd-whats-new-inline-grid{grid-template-columns:1fr;}#ldd-whats-new-inline .ldd-whats-new-inline-panel-main{grid-column:auto;grid-row:auto;min-height:unset;}#ldd-whats-new-inline .ldd-whats-new-inline-title{font-size:22px;}#ldd-whats-new-inline .ldd-whats-new-inline-logo{width:58px;height:58px;}}
    `;

    document.documentElement.appendChild(style);
    document.body.appendChild(wrap);

    wrap.addEventListener("click", (event) => {
      const target = event.target;
      if (!(target instanceof HTMLElement)) return;
      if (target.dataset.lddWhatsNewClose === "1" || target.classList.contains("ldd-whats-new-inline-backdrop")) {
        closeWhatsNewModal(true);
      }
    });
  }

  function applyGlobalTheme(settings) {
    const enabled = Boolean(settings.globalThemeEnabled);
    const existing = document.getElementById(THEME_STYLE_ID);
    const existingOverlay = document.getElementById(THEME_OVERLAY_ID);

    if (!enabled) {
      existing?.remove();
      existingOverlay?.remove();
      return;
    }

    const mode = settings.globalThemeMode === "solid" ? "solid" : "gradient";
    const brightness = clamp(Number.parseFloat(settings.globalThemeBrightness) || 100, 70, 130);
    const solid = adjustHexBrightness(settings.globalThemeSolidColor, brightness);
    const gradient = adjustHexBrightness(settings.globalThemeGradientColor, brightness);
    const accentGradient =
      mode === "solid"
        ? `linear-gradient(135deg, ${solid} 0%, ${solid} 100%)`
        : `linear-gradient(135deg, ${solid} 0%, ${gradient} 100%)`;
    const pageBackground =
      mode === "solid"
        ? `linear-gradient(180deg, #ffffff 0%, ${rgbaFromHex(solid, 0.14)} 100%)`
        : `linear-gradient(165deg, #ffffff 0%, ${rgbaFromHex(solid, 0.13)} 42%, ${rgbaFromHex(gradient, 0.15)} 100%)`;
    const surfaceBackground =
      mode === "solid"
        ? `linear-gradient(180deg, rgba(255,255,255,0.98) 0%, ${rgbaFromHex(solid, 0.08)} 100%)`
        : `linear-gradient(180deg, rgba(255,255,255,0.98) 0%, ${rgbaFromHex(solid, 0.07)} 45%, ${rgbaFromHex(gradient, 0.09)} 100%)`;
    const borderTint = rgbaFromHex(solid, 0.26);
    const softBorderTint = rgbaFromHex(solid, 0.18);
    const focusTint = rgbaFromHex(gradient, 0.3);
    const buttonBorder = rgbaFromHex(gradient, 0.52);
    const shadowSoft = rgbaFromHex(solid, 0.18);
    const shadowStrong = rgbaFromHex(gradient, 0.28);

    const style = existing || document.createElement("style");
    style.id = THEME_STYLE_ID;
    style.textContent = `
      :root {
        --ldd-theme-solid: ${solid};
        --ldd-theme-gradient: ${gradient};
        --ldd-theme-accent: ${accentGradient};
        --ldd-theme-page: ${pageBackground};
        --ldd-theme-surface: ${surfaceBackground};
        --ldd-theme-border: ${borderTint};
        --ldd-theme-border-soft: ${softBorderTint};
        --ldd-theme-focus: ${focusTint};
        --ldd-theme-shadow-soft: 0 10px 28px ${shadowSoft};
        --ldd-theme-shadow-strong: 0 16px 40px ${shadowStrong};
      }

      html {
        background: var(--ldd-theme-page) fixed !important;
      }

      body {
        background: var(--ldd-theme-page) !important;
        color: #2b3854 !important;
      }

      body :where(
        .bg-white,
        [class*="bg-white"],
        [class*="bg-slate-"],
        [class*="bg-gray-"],
        [class*="bg-zinc-"],
        [class*="bg-neutral-"],
        [class*="card"],
        [class*="panel"],
        [role="dialog"]
      ):not(#ldd-enhancer-root):not(#ldd-enhancer-root *):not([id^="ldd-"]):not([class*="ldd-"]) {
        background: var(--ldd-theme-surface) !important;
        border-color: var(--ldd-theme-border-soft) !important;
        box-shadow: var(--ldd-theme-shadow-soft) !important;
      }

      body :where(
        header,
        [class*="topbar"],
        [class*="navbar"],
        [class*="border-b"]
      ):not(#ldd-enhancer-root):not(#ldd-enhancer-root *):not([id^="ldd-"]):not([class*="ldd-"]) {
        background-image: var(--ldd-theme-accent) !important;
        border-color: transparent !important;
        color: rgba(255, 255, 255, 0.95) !important;
      }

      body :where(
        header *,
        [class*="topbar"] *,
        [class*="navbar"] *
      ):not(#ldd-enhancer-root):not(#ldd-enhancer-root *):not([id^="ldd-"]):not([class*="ldd-"]) {
        color: inherit !important;
      }

      body :where(
        [class*="border-"],
        .border
      ):not(#ldd-enhancer-root):not(#ldd-enhancer-root *):not([id^="ldd-"]):not([class*="ldd-"]) {
        border-color: var(--ldd-theme-border-soft) !important;
      }

      body :where(
        button,
        [role="button"],
        .btn,
        a[class*="btn"]
      ):not(#ldd-enhancer-root):not(#ldd-enhancer-root *):not([id^="ldd-"]):not([class*="ldd-"]) {
        border-radius: 12px !important;
      }

      body :where(
        button[class*="bg-"],
        a[class*="bg-"],
        button[class*="primary"],
        .btn.primary,
        [data-variant="primary"]
      ):not(#ldd-enhancer-root):not(#ldd-enhancer-root *):not([id^="ldd-"]):not([class*="ldd-"]) {
        background-image: var(--ldd-theme-accent) !important;
        border-color: ${buttonBorder} !important;
        color: #ffffff !important;
      }

      body :where(
        input,
        textarea,
        select
      ):not(#ldd-enhancer-root):not(#ldd-enhancer-root *):not([id^="ldd-"]):not([class*="ldd-"]) {
        background: rgba(255, 255, 255, 0.98) !important;
        border: 1px solid var(--ldd-theme-border) !important;
        border-radius: 12px !important;
        color: #2b3854 !important;
      }

      body :where(input, textarea):not(#ldd-enhancer-root):not(#ldd-enhancer-root *):not([id^="ldd-"]):not([class*="ldd-"])::placeholder {
        color: #8a95ad !important;
      }

      body :where(
        input:focus,
        textarea:focus,
        select:focus
      ):not(#ldd-enhancer-root):not(#ldd-enhancer-root *):not([id^="ldd-"]):not([class*="ldd-"]) {
        border-color: ${gradient} !important;
        box-shadow: 0 0 0 3px var(--ldd-theme-focus) !important;
        outline: none !important;
      }

      body :where(
        [class*="shadow"],
        .shadow
      ):not(#ldd-enhancer-root):not(#ldd-enhancer-root *):not([id^="ldd-"]):not([class*="ldd-"]) {
        box-shadow: var(--ldd-theme-shadow-strong) !important;
      }

      body *:not(#ldd-enhancer-root):not(#ldd-enhancer-root *)::-webkit-scrollbar {
        width: 10px;
        height: 10px;
      }

      body *:not(#ldd-enhancer-root):not(#ldd-enhancer-root *)::-webkit-scrollbar-thumb {
        background: var(--ldd-theme-accent);
        border-radius: 999px;
      }
    `;

    if (!existing) {
      document.documentElement.appendChild(style);
    }
    existingOverlay?.remove();
  }

  function isListingsPage() {
    const host = (window.location.hostname || "").toLowerCase();
    const path = (window.location.pathname || "").replace(/\/+$/, "");
    const validHost = host.includes("mydesigns.io");
    return validHost && path.includes("/app/list");
  }

  function applyFeatureSettings(settings) {
    const listingsPage = isListingsPage();
    applyGlobalTheme(settings);

    if (settings.enhancerEnabled && listingsPage) {
      window.LDDEnhancer?.enable?.();
    } else {
      window.LDDEnhancer?.disable?.();
    }

    if (settings.qaBarEnabled && listingsPage) {
      window.LDDQaBar?.enable?.();
    } else {
      window.LDDQaBar?.disable?.();
    }

    if (settings.dropperEnabled && listingsPage) {
      window.LDDDropper?.enable?.();
    } else {
      window.LDDDropper?.disable?.();
    }

    visionPresetsEnabled = Boolean(settings.visionAIPresetsEnabled ?? true);
    if (!visionPresetsEnabled) {
      document.getElementById(VISION_PRESET_BLOCK_ID)?.remove();
      visionMountedRoot = null;
    }
  }

  async function loadAndApplySettings() {
    try {
      if (!extensionStorage) {
        applyFeatureSettings(DEFAULT_SETTINGS);
        return;
      }
      const settings = await extensionStorage.get(DEFAULT_SETTINGS);
      applyFeatureSettings(settings);
    } catch (_error) {
      applyFeatureSettings(DEFAULT_SETTINGS);
    }
  }

  function findPasteTarget() {
    const selectors = [
      'textarea[placeholder*="emojis"]',
      'textarea[placeholder*="keyword"]',
      'textarea[placeholder*="title"]',
      'textarea',
      'input[type="text"]'
    ];

    for (const selector of selectors) {
      const element = document.querySelector(selector);
      if (element && typeof element.focus === "function") return element;
    }

    return null;
  }

  function pasteIntoPage(text) {
    const target = findPasteTarget();
    if (!target) return false;

    target.focus();
    target.value = text;
    target.dispatchEvent(new Event("input", { bubbles: true }));
    target.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }

  const VISION_PRESET_STYLE_ID = "ldd-vision-preset-style";
  const VISION_PRESET_BLOCK_ID = "ldd-vision-preset-block";
  const VISION_PRESET_TYPES = ["PNG", "SVG", "TUMBLER WRAP", "MUG WRAP"];
  const VISION_PRESET_LOGO_URL = chrome.runtime.getURL("assets/logo.png");
  const VISION_RUN_INTERVAL_MS = 1100;
  const VISION_RUN_DEBOUNCE_MS = 200;

  const VISION_PM_STYLE_ID = "ldd-vision-pm-style";
  const VISION_PM_BUTTON_ID = "ldd-vision-pm-button";
  const VISION_PM_MODAL_ID = "ldd-vision-pm-modal";
  const VISION_PROFILE_BUTTON_ID = "ldd-vision-profile-button";
  const VISION_PROFILE_MODAL_ID = "ldd-vision-profile-modal";
  const VISION_PROFILE_STORAGE_KEY = "visionAIProfiles";
  let visionProfileSaveHandlerInstalled = false;
  let latestVisionProfileSave = null;
  const VISION_AUTO_ENABLE_KEY = "visionAIAutoEnableCI";

  let visionRunScheduled = false;
  let visionMountedRoot = null;
  let visionWriteInProgress = false;
  let visionPresetsEnabled = true;
  let visionCIAutoCheckedForRoot = null;

  function norm(value) {
    return String(value || "").replace(/\s+/g, " ").trim().toLowerCase();
  }

  function isElementVisible(el) {
    if (!el) return false;
    const s = window.getComputedStyle(el);
    return s.display !== "none" && s.visibility !== "hidden" &&
      (el.offsetParent !== null || el.getClientRects().length > 0);
  }

  function setInputValue(input, value) {
    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")?.set;
    if (setter) setter.call(input, value); else input.value = value;
    input.dispatchEvent(new Event("input",  { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function findVisionModalRoot() {
    const all = Array.from(document.querySelectorAll("div,form")).filter((n) => {
      const t = norm(n.textContent || "");
      return t.includes("vision ai") &&
        t.includes("generate listing data based on your design") &&
        t.includes("select product type");
    });
    if (!all.length) return null;
    let best = all[0], bestDepth = Infinity;
    for (const c of all) {
      let d = 0, n = c; while (n) { d++; n = n.parentElement; }
      if (d < bestDepth) { bestDepth = d; best = c; }
    }
    return best;
  }

  function findVisionCustomTypeInput(root) {
    const scope = root || document;

    // Pass 1: the outer wrapper is div[maxlength="150"] and contains the label text.
    // This is the most reliable signal — it excludes the custom instructions box.
    const labelledContainer = Array.from(scope.querySelectorAll('div[maxlength="150"]')).find((container) => {
      if (!isElementVisible(container)) return false;
      if (Number.parseInt(container.getAttribute('maxlength') || '0', 10) !== 150) return false;
      return norm(container.textContent || '').includes('please specify other type');
    });
    if (labelledContainer) {
      const inp = labelledContainer.querySelector('input[maxlength="150"]');
      if (inp && isElementVisible(inp)) return inp;
    }

    // Pass 2: any visible div whose text includes the label and contains an input.
    const byLabel = Array.from(scope.querySelectorAll('div')).find((container) => {
      if (!isElementVisible(container)) return false;
      if (!norm(container.textContent || '').includes('please specify other type')) return false;
      return Boolean(container.querySelector('input'));
    });
    if (byLabel) {
      const inp = byLabel.querySelector('input[maxlength="150"], input[type="text"], input:not([type])');
      if (inp && isElementVisible(inp)) return inp;
    }

    // Pass 3: find the exact label node and walk up to a sibling input.
    const labelNode = Array.from(scope.querySelectorAll('label, div, span, p')).find(
      (node) => norm(node.textContent || '') === 'please specify other type'
    );
    if (labelNode) {
      const box = labelNode.closest('div');
      if (box) {
        const inp = box.parentElement?.querySelector('input[type="text"], input:not([type])');
        if (inp && isElementVisible(inp)) return inp;
      }
    }

    return null;
  }

  function ensureVisionPresetStyle() {
    if (document.getElementById(VISION_PRESET_STYLE_ID)) return;
    const s = document.createElement("style");
    s.id = VISION_PRESET_STYLE_ID;
    s.textContent =
      "#" + VISION_PRESET_BLOCK_ID + "{display:flex;align-items:center;gap:5px;margin-bottom:6px;}" +
      "#" + VISION_PRESET_BLOCK_ID + " .ldd-logo{width:14px;height:14px;border-radius:3px;object-fit:cover;flex-shrink:0;}" +
      "#" + VISION_PRESET_BLOCK_ID + " .ldd-chips{display:flex;gap:4px;flex-wrap:wrap;}" +
      "#" + VISION_PRESET_BLOCK_ID + " .ldd-chip{display:inline-flex;align-items:center;gap:4px;padding:3px 6px 3px 10px;" +
        "border:1px solid #cbd5e1;border-radius:999px;background:#fff;color:#475569;font-size:11px;" +
        "font-weight:600;cursor:pointer;user-select:none;white-space:nowrap;line-height:1.4;font-family:inherit;}" +
      "#" + VISION_PRESET_BLOCK_ID + " .ldd-chip:hover{border-color:#6366f1;color:#4338ca;background:#eef2ff;}" +
      "#" + VISION_PRESET_BLOCK_ID + " .ldd-chip.checked{background:#6366f1;border-color:#6366f1;color:#fff;}" +
      "#" + VISION_PRESET_BLOCK_ID + " .ldd-chip-del{display:inline-flex;align-items:center;justify-content:center;" +
        "width:13px;height:13px;border-radius:50%;border:none;background:transparent;color:inherit;" +
        "font-size:10px;line-height:1;cursor:pointer;padding:0;opacity:0.55;flex-shrink:0;}" +
      "#" + VISION_PRESET_BLOCK_ID + " .ldd-chip-del:hover{opacity:1;background:rgba(0,0,0,0.12);}" +
      "#" + VISION_PRESET_BLOCK_ID + " .ldd-chip.checked .ldd-chip-del:hover{background:rgba(255,255,255,0.25);}" +
      "#" + VISION_PRESET_BLOCK_ID + " .ldd-add-row{display:inline-flex;align-items:center;gap:3px;flex-shrink:0;}" +
      "#" + VISION_PRESET_BLOCK_ID + " .ldd-add-input{height:24px;padding:0 7px;border:1px solid #cbd5e1;border-radius:999px;" +
        "font-size:11px;font-family:inherit;color:#334155;background:#fff;width:90px;outline:none;}" +
      "#" + VISION_PRESET_BLOCK_ID + " .ldd-add-input:focus{border-color:#6366f1;}" +
      "#" + VISION_PRESET_BLOCK_ID + " .ldd-add-btn{display:inline-flex;align-items:center;justify-content:center;" +
        "height:24px;width:24px;border:1px solid #cbd5e1;border-radius:50%;background:#fff;color:#6366f1;" +
        "font-size:15px;line-height:1;cursor:pointer;flex-shrink:0;font-weight:700;}" +
      "#" + VISION_PRESET_BLOCK_ID + " .ldd-add-btn:hover{border-color:#6366f1;background:#eef2ff;}" +
      "#" + VISION_PRESET_BLOCK_ID + " .ldd-chip-toggle{display:inline-flex;align-items:center;padding:2px 5px;" +
        "border:1px solid #e2e8f0;border-radius:6px;background:transparent;color:#94a3b8;font-size:11px;" +
        "cursor:pointer;user-select:none;line-height:1;margin-left:2px;flex-shrink:0;}" +
      "#" + VISION_PRESET_BLOCK_ID + " .ldd-chip-toggle:hover{border-color:#6366f1;color:#6366f1;background:#eef2ff;}";
    document.head.appendChild(s);
  }

  function buildVisionPresetBlock(root) {
    const block = document.createElement("div");
    block.id = VISION_PRESET_BLOCK_ID;

    const logo = document.createElement("img");
    logo.className = "ldd-logo";
    logo.src = VISION_PRESET_LOGO_URL;
    logo.alt = ""; logo.setAttribute("aria-hidden", "true");
    block.appendChild(logo);

    const chips = document.createElement("div");
    chips.className = "ldd-chips";
    block.appendChild(chips);

    // Inline add row
    const addRow = document.createElement("div");
    addRow.className = "ldd-add-row";
    const addInput = document.createElement("input");
    addInput.type = "text"; addInput.className = "ldd-add-input";
    addInput.placeholder = "Add type…"; addInput.maxLength = 40;
    const addBtn = document.createElement("button");
    addBtn.type = "button"; addBtn.className = "ldd-add-btn"; addBtn.title = "Add type"; addBtn.textContent = "+";
    addRow.appendChild(addInput); addRow.appendChild(addBtn);
    block.appendChild(addRow);

    // Collapse toggle
    const collapseBtn = document.createElement("button");
    collapseBtn.type = "button"; collapseBtn.className = "ldd-chip-toggle";
    collapseBtn.title = "Hide quick types"; collapseBtn.textContent = "▾";
    block.appendChild(collapseBtn);

    function syncInputField() {
      if (visionWriteInProgress) return;
      visionWriteInProgress = true;
      try {
        const sel = Array.from(chips.querySelectorAll(".ldd-chip[data-checked='1']"))
          .map((b) => b.dataset.type).filter(Boolean);
        const inp = findVisionCustomTypeInput(root);
        if (inp) setInputValue(inp, sel.join(", "));
      } finally { visionWriteInProgress = false; }
    }

    function makeChip(typeValue) {
      const chip = document.createElement("div");
      chip.className = "ldd-chip";
      chip.dataset.type = typeValue; chip.dataset.checked = "0";
      chip.setAttribute("role", "button"); chip.setAttribute("tabindex", "0");

      const label = document.createElement("span");
      label.textContent = typeValue;
      chip.appendChild(label);

      const del = document.createElement("button");
      del.type = "button"; del.className = "ldd-chip-del"; del.title = "Remove"; del.textContent = "×";
      chip.appendChild(del);

      function toggleChip() {
        const on = chip.dataset.checked === "1";
        chip.dataset.checked = on ? "0" : "1";
        chip.classList.toggle("checked", !on);
        syncInputField();
      }

      chip.addEventListener("click", (e) => {
        e.preventDefault(); e.stopPropagation();
        if (e.target === del) return; // del handles itself
        toggleChip();
      });
      chip.addEventListener("keydown", (e) => { if (e.key === " " || e.key === "Enter") { e.preventDefault(); toggleChip(); } });

      del.addEventListener("click", (e) => {
        e.preventDefault(); e.stopPropagation();
        chip.remove();
        const remaining = Array.from(chips.querySelectorAll(".ldd-chip"))
          .map((b) => b.dataset.type).filter(Boolean);
        syncInputField();
      });

      return chip;
    }

    function renderChips(types) {
      chips.innerHTML = "";
      types.forEach((t) => chips.appendChild(makeChip(t)));
    }

    function addType() {
      const val = addInput.value.trim().toUpperCase();
      if (!val) return;
      // don't add duplicates
      const existing = Array.from(chips.querySelectorAll(".ldd-chip")).map((b) => b.dataset.type);
      if (existing.includes(val)) { addInput.value = ""; return; }
      chips.appendChild(makeChip(val));
      addInput.value = "";
      const updated = [...existing, val];
    }

    addBtn.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); addType(); });
    addInput.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); e.stopPropagation(); addType(); } });
    addInput.addEventListener("click", (e) => e.stopPropagation());
    addRow.addEventListener("click", (e) => e.stopPropagation());
    addRow.addEventListener("mousedown", (e) => e.stopPropagation());

    // Collapse logic
    function applyCollapsed(collapsed) {
      chips.style.display = collapsed ? "none" : "";
      addRow.style.display = collapsed ? "none" : "";
      collapseBtn.textContent = collapsed ? "▸" : "▾";
      collapseBtn.title = collapsed ? "Show quick types" : "Hide quick types";
    }
    collapseBtn.addEventListener("click", (e) => {
      e.preventDefault(); e.stopPropagation();
      const collapsed = chips.style.display === "none";
      applyCollapsed(!collapsed);
    });

    // Load types + collapsed state from defaults only to avoid extension-context crashes here.
    renderChips([...VISION_PRESET_TYPES]);
    applyCollapsed(false);

    return block;
  }

  function mountVisionPresetBlock(root) {
    if (!root || !isElementVisible(root)) return;
    if (document.getElementById(VISION_PRESET_BLOCK_ID)?.isConnected) return;
    const inp = findVisionCustomTypeInput(root);
    if (!inp) return;
    try {
      ensureVisionPresetStyle();
      const block = buildVisionPresetBlock(root);
      if (block && inp.parentElement) inp.parentElement.insertAdjacentElement("beforebegin", block);
    } catch (_error) {
      document.getElementById(VISION_PRESET_BLOCK_ID)?.remove();
    }
  }

  function findVisionCIRow(root) {
    const scope = root || document;
    const nodes = Array.from(scope.querySelectorAll('label, div, span, p'));
    for (const node of nodes) {
      if (!isElementVisible(node)) continue;
      const text = norm(node.textContent || '');
      if (text === 'custom instructions' || text.startsWith('custom instructions ')) {
        return node.closest('label, div, section, form') || node.parentElement || node;
      }
    }
    return null;
  }

  function findVisionCICheckbox(root) {
    const row = findVisionCIRow(root);
    if (!row) return null;
    return row.querySelector('div[tabindex="0"], button[role="checkbox"], [aria-checked]') || row.previousElementSibling?.querySelector?.('div[tabindex="0"]') || null;
  }

  function isVisionCIChecked(root) {
    const box = findVisionCICheckbox(root);
    if (!box) return false;
    const aria = box.getAttribute('aria-checked');
    if (aria === 'true') return true;
    if (aria === 'false') return false;
    const svg = box.querySelector('svg');
    return !!svg && !svg.classList.contains('invisible');
  }

  function clickVisionCICheckbox(root) {
    const box = findVisionCICheckbox(root);
    if (!box) return false;
    ["pointerdown", "mousedown", "pointerup", "mouseup", "click"].forEach((type) => {
      box.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
    });
    if (typeof box.click === 'function') box.click();
    return true;
  }

  function ensureVisionCustomInstructionsEnabled(root) {
    if (!root || visionCIAutoCheckedForRoot === root) return;
    visionCIAutoCheckedForRoot = root;
    try {
      if (!extensionStorage || !extensionRuntime?.id) {
        visionCIAutoCheckedForRoot = null;
        return;
      }
      extensionStorage.get({ [VISION_AUTO_ENABLE_KEY]: true }, (settings) => {
        if (chrome.runtime?.lastError) {
          visionCIAutoCheckedForRoot = null;
          return;
        }
        if (settings?.[VISION_AUTO_ENABLE_KEY] === false) return;
        window.setTimeout(() => {
          if (!root.isConnected) {
            visionCIAutoCheckedForRoot = null;
            return;
          }
          if (!isVisionCIChecked(root)) clickVisionCICheckbox(root);
        }, 180);
      });
    } catch (_error) {
      visionCIAutoCheckedForRoot = null;
    }
  }

  function setTextareaValue(el, value) {
    if (!el) return false;
    const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value")?.set
      || Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")?.set;
    if (setter) setter.call(el, value); else el.value = value;
    el.focus();
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }

  function uid() {
    return `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
  }

  function escapeHTML(value) {
    return String(value || '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char] || char));
  }

  function copyPromptText(value) {
    const text = String(value || '');
    if (navigator.clipboard?.writeText) return navigator.clipboard.writeText(text);
    const area = document.createElement('textarea');
    area.value = text;
    area.setAttribute('readonly', 'readonly');
    area.style.position = 'fixed';
    area.style.opacity = '0';
    area.style.pointerEvents = 'none';
    document.body.appendChild(area);
    area.select();
    try { document.execCommand('copy'); } catch (_error) {}
    area.remove();
    return Promise.resolve();
  }

  function getClipboardItems() {
    return new Promise((resolve) => {
      if (!extensionStorage || !extensionRuntime?.id) {
        resolve([]);
        return;
      }
      extensionStorage.get({ clipboardItems: [] }, (data) => {
        if (chrome.runtime?.lastError) {
          resolve([]);
          return;
        }
        const items = Array.isArray(data.clipboardItems) ? data.clipboardItems.slice() : [];
        resolve(items.sort((a, b) => Number(b.pinned || false) - Number(a.pinned || false) || Number(b.createdAt || 0) - Number(a.createdAt || 0)));
      });
    });
  }

  function setClipboardItems(items) {
    return new Promise((resolve) => {
      if (!extensionStorage || !extensionRuntime?.id) {
        resolve();
        return;
      }
      try {
        extensionStorage.set({ clipboardItems: items }, () => resolve());
      } catch (_error) {
        resolve();
      }
    });
  }

  function makePromptPreview(value, maxLen = 160) {
    const text = String(value || '').trim();
    if (!text) return 'No content';
    return text.length > maxLen ? `${text.slice(0, maxLen)}...` : text;
  }

  function findVisionCITextarea(root) {
    const scope = root || document;
    // Only look at actual textareas — never inputs (avoids grabbing the Other type input)
    const areas = Array.from(scope.querySelectorAll('textarea')).filter((el) => isElementVisible(el));
    const byPlaceholder = areas.find((el) => norm(el.getAttribute('placeholder') || '').includes('custom instruction'));
    if (byPlaceholder) return byPlaceholder;
    // Find by nearby "Custom instructions" label
    const byLabel = areas.find((el) => {
      const nearText = norm(el.closest('div,section,form')?.textContent || '');
      return nearText.includes('custom instruction');
    });
    if (byLabel) return byLabel;
    // Last resort: biggest visible textarea
    return areas.sort((a, b) => (b.clientHeight * b.clientWidth) - (a.clientHeight * a.clientWidth))[0] || null;
  }

  function ensureVisionPMStyle() {
    if (document.getElementById(VISION_PM_STYLE_ID)) return;
    const style = document.createElement('style');
    style.id = VISION_PM_STYLE_ID;
    style.textContent = `
      #${VISION_PM_BUTTON_ID},#${VISION_PROFILE_BUTTON_ID}{display:inline-flex;align-items:center;gap:8px;margin-left:10px;padding:8px 12px;border-radius:999px;border:1px solid rgba(99,102,241,.22);background:linear-gradient(180deg,#ffffff,#f8fafc);color:#4f46e5;font-size:10px;font-weight:900;cursor:pointer;box-shadow:0 12px 26px rgba(79,70,229,.12);white-space:nowrap;}
      #${VISION_PM_BUTTON_ID}:hover,#${VISION_PROFILE_BUTTON_ID}:hover{background:linear-gradient(180deg,#ffffff,#eef2ff);border-color:rgba(99,102,241,.36);}
      #${VISION_PM_BUTTON_ID} img,#${VISION_PROFILE_BUTTON_ID} img{width:18px;height:18px;border-radius:999px;object-fit:cover;flex-shrink:0;box-shadow:0 4px 10px rgba(15,23,42,.12);}
      #${VISION_PM_BUTTON_ID},#${VISION_PROFILE_BUTTON_ID}{position:relative;overflow:visible;}
      #${VISION_PM_BUTTON_ID} .ldd-vision-btn-tip,#${VISION_PROFILE_BUTTON_ID} .ldd-vision-btn-tip{position:absolute;left:50%;bottom:calc(100% + 8px);transform:translateX(-50%);background:#fff;color:#1e2a3a;font-size:11px;font-weight:800;line-height:1.35;white-space:nowrap;padding:7px 10px;border-radius:10px;border:1px solid rgba(148,163,184,.22);box-shadow:0 10px 24px rgba(15,23,42,.14);pointer-events:none;opacity:0;transition:opacity .15s;z-index:2147483646;}
      #${VISION_PM_BUTTON_ID} .ldd-vision-btn-tip::after,#${VISION_PROFILE_BUTTON_ID} .ldd-vision-btn-tip::after{content:'';position:absolute;top:100%;left:50%;transform:translateX(-50%);border:5px solid transparent;border-top-color:#fff;}
      #${VISION_PM_BUTTON_ID}:hover .ldd-vision-btn-tip,#${VISION_PROFILE_BUTTON_ID}:hover .ldd-vision-btn-tip{opacity:1;}
      #${VISION_PM_MODAL_ID}{position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;padding:18px;}
      #${VISION_PROFILE_MODAL_ID}{position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;padding:18px;}
      #${VISION_PM_MODAL_ID} .ldd-pm-backdrop{position:absolute;inset:0;background:rgba(15,23,42,.38);backdrop-filter:blur(6px);}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-backdrop{position:absolute;inset:0;background:rgba(15,23,42,.38);backdrop-filter:blur(6px);}
      #${VISION_PM_MODAL_ID} .ldd-pm-card{position:relative;z-index:1;width:min(94vw,760px);max-height:min(88vh,820px);display:flex;flex-direction:column;gap:12px;background:#fff;border:1px solid rgba(148,163,184,.26);border-radius:22px;box-shadow:0 30px 70px rgba(15,23,42,.28);padding:18px;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-card{position:relative;z-index:1;width:min(94vw,720px);max-height:min(88vh,820px);display:flex;flex-direction:column;gap:12px;background:#fff;border:1px solid rgba(148,163,184,.26);border-radius:22px;box-shadow:0 30px 70px rgba(15,23,42,.28);padding:18px;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-top{display:flex;align-items:center;justify-content:space-between;gap:12px;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-title-wrap{display:flex;flex-direction:column;gap:2px;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-title{display:flex;align-items:center;gap:10px;font-size:18px;font-weight:900;color:#1e2a3a;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-title img{width:28px;height:28px;border-radius:999px;object-fit:cover;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-sub{font-size:12px;color:#64748b;font-weight:600;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-close{width:36px;height:36px;border:none;border-radius:999px;background:#eef2f7;color:#475569;font-size:18px;font-weight:800;cursor:pointer;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-actions{display:flex;flex-wrap:wrap;gap:8px;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-action{height:38px;padding:0 14px;border-radius:12px;border:1px solid rgba(148,163,184,.24);background:#fff;color:#334155;font-size:12px;font-weight:800;cursor:pointer;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-action.primary{border:none;background:linear-gradient(180deg,#7c6bff,#5b4ef5);color:#fff;box-shadow:0 10px 22px rgba(91,78,245,.22);}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-action.danger{color:#b91c1c;border-color:rgba(239,68,68,.18);background:#fff5f5;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-list{display:grid;gap:10px;overflow-x:visible;overflow-y:auto;padding-right:4px;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-item{display:grid;gap:10px;padding:14px;border-radius:18px;border:1px solid rgba(148,163,184,.22);background:linear-gradient(180deg,#fff,#f8fafc);box-shadow:0 12px 24px rgba(15,23,42,.06);}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-head{display:flex;align-items:center;justify-content:space-between;gap:10px;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-name{font-size:14px;font-weight:900;color:#1e2a3a;display:flex;align-items:center;gap:8px;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-preview{font-size:12px;line-height:1.55;color:#64748b;white-space:pre-wrap;word-break:break-word;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-empty{padding:20px;border-radius:18px;border:1px dashed rgba(148,163,184,.35);text-align:center;color:#64748b;font-size:13px;font-weight:700;background:#f8fafc;}
      #${VISION_PM_MODAL_ID} .ldd-pm-top{display:flex;align-items:center;justify-content:space-between;gap:12px;}
      #${VISION_PM_MODAL_ID} .ldd-pm-title-wrap{display:flex;flex-direction:column;gap:2px;}
      #${VISION_PM_MODAL_ID} .ldd-pm-title{display:flex;align-items:center;gap:10px;font-size:18px;font-weight:900;color:#1e2a3a;}
      #${VISION_PM_MODAL_ID} .ldd-pm-title img{width:28px;height:28px;border-radius:999px;object-fit:cover;}
      #${VISION_PM_MODAL_ID} .ldd-pm-sub{font-size:12px;color:#64748b;font-weight:700;}
      #${VISION_PM_MODAL_ID} .ldd-pm-sub{font-size:12px;color:#64748b;font-weight:600;}
      #${VISION_PM_MODAL_ID} .ldd-pm-close{width:36px;height:36px;border:none;border-radius:999px;background:#eef2f7;color:#475569;font-size:18px;font-weight:800;cursor:pointer;}
      #${VISION_PM_MODAL_ID} .ldd-pm-toolbar{display:grid;grid-template-columns:minmax(0,1fr) auto auto;gap:10px;align-items:center;}
      #${VISION_PM_MODAL_ID} .ldd-pm-search{height:42px;border-radius:14px;border:1px solid rgba(148,163,184,.28);padding:0 14px;font-size:13px;font-weight:600;color:#334155;background:#fff;outline:none;min-width:0;}
      #${VISION_PM_MODAL_ID} .ldd-pm-search:focus,#${VISION_PM_MODAL_ID} .ldd-pm-edit-name:focus,#${VISION_PM_MODAL_ID} .ldd-pm-edit-content:focus{border-color:#6366f1;box-shadow:0 0 0 3px rgba(99,102,241,.12);}
      #${VISION_PM_MODAL_ID} .ldd-pm-toolbar-btn,#${VISION_PM_MODAL_ID} .ldd-pm-action{height:38px;padding:0 14px;border-radius:12px;border:1px solid rgba(148,163,184,.24);background:#fff;color:#334155;font-size:12px;font-weight:800;cursor:pointer;}
      #${VISION_PM_MODAL_ID} .ldd-pm-toolbar-btn.primary,#${VISION_PM_MODAL_ID} .ldd-pm-action.primary{border:none;background:linear-gradient(180deg,#7c6bff,#5b4ef5);color:#fff;box-shadow:0 10px 22px rgba(91,78,245,.22);}
      #${VISION_PM_MODAL_ID} .ldd-pm-list{display:grid;gap:10px;overflow:auto;padding-right:4px;}
      #${VISION_PM_MODAL_ID} .ldd-pm-item{display:grid;gap:10px;padding:14px;border-radius:18px;border:1px solid rgba(148,163,184,.22);background:linear-gradient(180deg,#fff,#f8fafc);box-shadow:0 12px 24px rgba(15,23,42,.06);}
      #${VISION_PM_MODAL_ID} .ldd-pm-item.pinned{border-color:rgba(99,102,241,.28);box-shadow:0 18px 32px rgba(99,102,241,.12);}
      #${VISION_PM_MODAL_ID} .ldd-pm-head{display:flex;align-items:center;justify-content:space-between;gap:10px;}
      #${VISION_PM_MODAL_ID} .ldd-pm-name{font-size:14px;font-weight:900;color:#1e2a3a;display:flex;align-items:center;gap:8px;}
      #${VISION_PM_MODAL_ID} .ldd-pm-pin{font-size:12px;}
      #${VISION_PM_MODAL_ID} .ldd-pm-preview{font-size:12px;line-height:1.55;color:#64748b;white-space:pre-wrap;word-break:break-word;}
      #${VISION_PM_MODAL_ID} .ldd-pm-actions{display:flex;flex-wrap:wrap;gap:8px;}
      #${VISION_PM_MODAL_ID} .ldd-pm-action.danger{color:#b91c1c;border-color:rgba(239,68,68,.18);background:#fff5f5;}
      #${VISION_PM_MODAL_ID} .ldd-pm-edit{display:grid;gap:10px;}
      #${VISION_PM_MODAL_ID} .ldd-pm-edit-name,#${VISION_PM_MODAL_ID} .ldd-pm-edit-content{width:100%;border-radius:14px;border:1px solid rgba(148,163,184,.28);padding:12px 14px;font-size:13px;font-weight:600;color:#334155;background:#fff;outline:none;}
      #${VISION_PM_MODAL_ID} .ldd-pm-edit-content{min-height:140px;resize:vertical;font-family:inherit;line-height:1.5;}
      #${VISION_PM_MODAL_ID} .ldd-pm-empty{padding:20px;border-radius:18px;border:1px dashed rgba(148,163,184,.35);text-align:center;color:#64748b;font-size:13px;font-weight:700;background:#f8fafc;}
      @media (max-width: 640px){
        #${VISION_PM_MODAL_ID} .ldd-pm-card{width:min(96vw,96vw);padding:14px;border-radius:22px;}
        #${VISION_PM_MODAL_ID} .ldd-pm-toolbar{grid-template-columns:1fr 1fr;}
        #${VISION_PM_MODAL_ID} .ldd-pm-search{grid-column:1 / -1;}
      }

      /* ── Profile manager extras ── */
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-list{display:grid;grid-template-columns:1fr 1fr;gap:14px;align-items:start;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-section-note{padding:10px 12px;border-radius:12px;border:1px solid rgba(217,119,6,.22);background:rgba(255,247,237,.92);color:#9a3412;font-size:12px;font-weight:800;line-height:1.45;grid-column:1 / -1;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-column{display:flex;flex-direction:column;gap:10px;min-width:0;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-column-head{font-size:15px;font-weight:900;letter-spacing:.03em;text-transform:uppercase;border-radius:16px;padding:16px 18px;display:flex;flex-direction:column;gap:8px;box-shadow:0 10px 24px rgba(15,23,42,.08);}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-column-head.pod{background:rgba(37,99,235,.10);color:#1d4ed8;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-column-head.digital{background:rgba(217,119,6,.12);color:#b45309;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-column-sub{font-size:13px;font-weight:900;letter-spacing:0;text-transform:none;line-height:1.35;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-confirm{margin-top:8px;padding:12px 12px;border-radius:14px;border:1px solid rgba(148,163,184,.24);background:#fff;box-shadow:0 10px 24px rgba(15,23,42,.10);display:grid;gap:8px;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-confirm-text{font-size:12px;font-weight:800;color:#1e2a3a;line-height:1.45;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-confirm-actions{display:flex;gap:8px;justify-content:center;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-item{position:relative;overflow:visible;border-radius:14px;padding:14px;min-height:150px;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-item.pinned{border-color:rgba(99,102,241,.35);background:linear-gradient(180deg,#fafaff,#f3f4ff);box-shadow:0 18px 32px rgba(99,102,241,.10);}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-pin-badge{font-size:10px;font-weight:800;color:#6366f1;background:rgba(99,102,241,.1);border-radius:999px;padding:2px 7px;margin-left:6px;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-type-badge{display:inline-flex;align-items:center;gap:6px;width:fit-content;margin-top:6px;padding:4px 10px;border-radius:999px;font-size:10px;font-weight:800;letter-spacing:.02em;text-transform:uppercase;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-type-badge.pod{background:rgba(37,99,235,.10);color:#1d4ed8;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-type-badge.digital{background:rgba(217,119,6,.12);color:#b45309;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-type-note{margin-top:6px;font-size:11px;font-weight:700;color:#b45309;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-icon-row{display:flex;gap:4px;margin-left:auto;flex-shrink:0;overflow:visible;position:relative;z-index:2;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-icon-btn{position:relative;width:32px;height:32px;border:1px solid rgba(148,163,184,.22);border-radius:10px;background:#fff;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;color:#64748b;transition:background .12s,border-color .12s,color .12s;overflow:visible;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-icon-btn svg{width:15px;height:15px;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;pointer-events:none;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-icon-btn:hover{background:#eef2ff;border-color:rgba(99,102,241,.28);color:#4f46e5;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-icon-btn.danger:hover{background:#fff5f5;border-color:rgba(239,68,68,.25);color:#b91c1c;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-icon-btn.active{background:#eef2ff;border-color:rgba(99,102,241,.4);color:#4f46e5;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-icon-btn .ldd-tip{position:absolute;bottom:calc(100% + 7px);left:50%;transform:translateX(-50%);background:#fff;color:#1e2a3a !important;font-size:11px;font-weight:700;white-space:nowrap;padding:5px 10px;border-radius:9px;border:1px solid rgba(148,163,184,.22);box-shadow:0 8px 20px rgba(15,23,42,.12);pointer-events:none;opacity:0;transition:opacity .15s;z-index:2147483646;display:block;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-icon-btn .ldd-tip::after{content:'';position:absolute;top:100%;left:50%;transform:translateX(-50%);border:5px solid transparent;border-top-color:#fff;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-icon-btn:hover .ldd-tip{opacity:1;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-rename-row{display:flex;gap:6px;align-items:center;margin-top:4px;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-rename-input{flex:1;height:34px;border-radius:10px;border:1px solid rgba(99,102,241,.35);padding:0 10px;font-size:13px;font-weight:700;color:#1e2a3a;outline:none;background:#fff;}
      @media (max-width: 900px){
        #${VISION_PROFILE_MODAL_ID} .ldd-pm-list{grid-template-columns:1fr;}
      }
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-rename-input:focus{border-color:#6366f1;box-shadow:0 0 0 3px rgba(99,102,241,.12);}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-rename-ok{height:34px;padding:0 12px;border-radius:10px;border:none;background:linear-gradient(180deg,#7c6bff,#5b4ef5);color:#fff;font-size:12px;font-weight:800;cursor:pointer;}
      #${VISION_PROFILE_MODAL_ID} .ldd-pm-rename-cancel{height:34px;padding:0 10px;border-radius:10px;border:1px solid rgba(148,163,184,.28);background:#fff;color:#64748b;font-size:12px;font-weight:800;cursor:pointer;}
      /* CI save prompt */
      #ldd-ci-save-prompt{position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;padding:18px;}
      #ldd-ci-save-prompt .ldd-csp-backdrop{position:absolute;inset:0;background:rgba(15,23,42,.35);backdrop-filter:blur(5px);}
      #ldd-ci-save-prompt .ldd-csp-card{position:relative;z-index:1;width:min(94vw,420px);background:#fff;border-radius:24px;border:1px solid rgba(148,163,184,.22);box-shadow:0 30px 60px rgba(15,23,42,.22);padding:22px 20px 18px;}
      #ldd-ci-save-prompt .ldd-csp-title{display:flex;align-items:center;gap:10px;font-size:16px;font-weight:900;color:#1e2a3a;margin-bottom:6px;}
      #ldd-ci-save-prompt .ldd-csp-title img{width:24px;height:24px;border-radius:999px;object-fit:cover;}
      #ldd-ci-save-prompt .ldd-csp-sub{font-size:12px;color:#64748b;font-weight:600;margin-bottom:16px;}
      #ldd-ci-save-prompt .ldd-csp-preview{font-size:12px;color:#475569;background:#f8fafc;border-radius:10px;padding:10px 12px;margin-bottom:16px;max-height:80px;overflow:hidden;line-height:1.5;border:1px solid rgba(148,163,184,.18);}
      #ldd-ci-save-prompt .ldd-csp-btns{display:grid;grid-template-columns:1fr 1fr;gap:8px;}
      #ldd-ci-save-prompt .ldd-csp-btn{height:40px;border-radius:12px;border:1px solid rgba(148,163,184,.24);background:#fff;color:#334155;font-size:12px;font-weight:800;cursor:pointer;}
      #ldd-ci-save-prompt .ldd-csp-btn.primary{border:none;background:linear-gradient(180deg,#7c6bff,#5b4ef5);color:#fff;box-shadow:0 8px 18px rgba(91,78,245,.2);}
      #ldd-ci-save-prompt .ldd-csp-btn.neither{grid-column:1/-1;background:#f8fafc;color:#94a3b8;}
      }
    `;
    document.head.appendChild(style);
  }

  function closeVisionPromptManager() {
    document.getElementById(VISION_PM_MODAL_ID)?.remove();
  }

  function closeVisionProfileManager() {
    document.getElementById(VISION_PROFILE_MODAL_ID)?.remove();
  }

  function findVisionDropdownValue(root, labelText) {
    const scope = root || document;
    const labels = Array.from(scope.querySelectorAll('div, span, p')).filter((el) => isElementVisible(el));
    const label = labels.find((el) => norm(el.textContent || '') === norm(labelText));
    const wrap = findFieldWrap(label);
    const button = wrap?.querySelector?.('button[type="button"]');
    return (button?.innerText || button?.textContent || '').trim();
  }

  function parseOptionValue(value) {
    if (value == null) return null;
    const raw = String(value);
    if (raw === 'null') return null;
    if ((raw.startsWith('"') && raw.endsWith('"')) || (raw.startsWith("'") && raw.endsWith("'"))) {
      return raw.slice(1, -1);
    }
    return raw;
  }

  function findVisionFieldButton(root, labelText) {
    const scope = root || document;
    const labels = Array.from(scope.querySelectorAll('div, span, p')).filter((el) => isElementVisible(el));
    const label = labels.find((el) => norm(el.textContent || '') === norm(labelText));
    const wrap = findFieldWrap(label);
    return wrap?.querySelector?.('button[type="button"]') || null;
  }

  function findFieldWrap(label) {
    let node = label instanceof Element ? label : null;
    while (node && node !== document.body) {
      if (node.querySelector?.('button[type="button"]')) return node;
      node = node.parentElement;
    }
    return label?.parentElement || null;
  }

  function getVisibleVisionDropdownMenu() {
    const menus = Array.from(document.querySelectorAll('div.border-base-300.bg-base-surface.max-h-72.overflow-auto.rounded-md.border.p-1'));
    return menus.find((el) => isElementVisible(el)) || null;
  }

  function delay(ms) {
    return new Promise((resolve) => window.setTimeout(resolve, ms));
  }

  async function waitForVisionMenu(timeoutMs = 1200) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const menu = getVisibleVisionDropdownMenu();
      if (menu) return menu;
      await delay(60);
    }
    return null;
  }

  function getVisionDropdownOptionNodes(menu) {
    if (!menu) return [];
    const byData = Array.from(menu.querySelectorAll('li[data-value]'));
    if (byData.length) return byData;
    return Array.from(menu.querySelectorAll('li,[role="option"],button')).filter((el) => isElementVisible(el));
  }

  function isVisionOptionChecked(optionEl) {
    if (!optionEl) return false;
    const aria = optionEl.getAttribute('aria-selected') || optionEl.getAttribute('aria-checked');
    if (aria === 'true') return true;
    if (aria === 'false') return false;

    const checkboxTile = optionEl.querySelector('div[tabindex="0"]');
    const checkboxAria = checkboxTile?.getAttribute('aria-checked');
    if (checkboxAria === 'true') return true;
    if (checkboxAria === 'false') return false;

    const svg = checkboxTile?.querySelector('svg') || optionEl.querySelector('svg');
    if (svg) return !svg.classList.contains('invisible');

    const tileClass = checkboxTile?.className || '';
    if (String(tileClass).includes('bg-brand-primary')) return true;
    if (String(tileClass).includes('border-base-300')) return false;

    return false;
  }

  function findVisionOptionMatch(options, optionValue, optionLabel) {
    const normalizedTarget = norm(optionLabel || '');
    return options.find((li) => parseOptionValue(li.getAttribute('data-value')) === optionValue)
      || options.find((li) => norm(li.textContent || '') === normalizedTarget)
      || options.find((li) => normalizedTarget && norm(li.textContent || '').includes(normalizedTarget))
      || null;
  }

  function getVisionOptionValue(optionEl) {
    return String(parseOptionValue(optionEl?.getAttribute?.('data-value')) ?? '').trim();
  }

  function getVisionOptionLabel(optionEl) {
    return String(optionEl?.querySelector?.('span')?.textContent || optionEl?.textContent || '').trim();
  }

  function getVisionCheckedOptionValues(options) {
    return uniqueNormalizedList((options || [])
      .filter((option) => isVisionOptionChecked(option))
      .map((option) => getVisionOptionValue(option))
      .filter(Boolean));
  }

  function getVisionOptionToggleTarget(optionEl) {
    return optionEl?.querySelector?.('div[tabindex="0"]') || optionEl;
  }

  async function clickVisionOptionToggle(optionEl) {
    const target = getVisionOptionToggleTarget(optionEl);
    if (!target) return false;
    try {
      target.dispatchEvent(new MouseEvent('pointerdown', { bubbles: true, cancelable: true, view: window }));
      target.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
      target.dispatchEvent(new MouseEvent('pointerup', { bubbles: true, cancelable: true, view: window }));
      target.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
      target.click?.();
      await delay(120);
      return true;
    } catch (_error) {
      return false;
    }
  }

  async function openVisionProductTypeMenu(root, timeoutMs = 1500) {
    const button = findVisionFieldButton(root, 'Select product type');
    if (!button) return null;
    button.click();
    const menu = await waitForVisionMenu(timeoutMs);
    if (!menu) return null;
    await delay(140);
    return { button, menu, options: getVisionDropdownOptionNodes(menu) };
  }

  function findVisionModalHeaderStrip(root = document) {
    const scope = root || document;
    return Array.from(scope.querySelectorAll('div')).find((node) => {
      if (!(node instanceof HTMLElement)) return false;
      const text = norm(node.textContent || '');
      if (!text.includes('vision ai')) return false;
      if (!node.className || typeof node.className !== 'string') return false;
      return node.className.includes('rounded-t-xl')
        && node.className.includes('border-b')
        && node.className.includes('px-4')
        && node.className.includes('py-2');
    }) || null;
  }

  async function scrollVisionProductTypeMenuToBottom(root) {
    const menu = getVisibleVisionDropdownMenu();
    if (!menu) return false;
    const scrollTargets = [
      menu,
      ...Array.from(menu.querySelectorAll('ul, [role="listbox"], [data-radix-scroll-area-viewport], .overflow-y-auto, .overflow-auto, [style*="overflow"]'))
    ].filter(Boolean);
    let moved = false;
    for (const target of scrollTargets) {
      try {
        const before = target.scrollTop;
        target.scrollTop = target.scrollHeight;
        target.dispatchEvent(new Event('scroll', { bubbles: true }));
        if (target.scrollTop !== before) moved = true;
      } catch (_error) {}
    }

    const otherOption = Array.from(getVisionDropdownOptionNodes(menu)).find((option) => {
      const label = norm(getVisionOptionLabel(option));
      const value = norm(getVisionOptionValue(option));
      return label === 'other (please specify)' || label === 'other' || value === 'other';
    });
    if (otherOption) {
      try {
        otherOption.scrollIntoView({ block: 'center', behavior: 'instant' });
        moved = true;
      } catch (_error) {
        try {
          otherOption.scrollIntoView({ block: 'center' });
          moved = true;
        } catch (_error2) {}
      }
    }

    await delay(180);
    return moved;
  }

  const VISION_OTHER_MAXIMIZED_POINT = { x: 623, y: 549 };
  const VISION_CLICKOUT_MAXIMIZED_POINT = { x: 814, y: 55 };

  function clickViewportPoint(x, y) {
    const target = document.elementFromPoint(x, y);
    if (!(target instanceof Element)) return false;
    const eventInit = {
      bubbles: true,
      cancelable: true,
      clientX: x,
      clientY: y,
      view: window
    };
    try { target.dispatchEvent(new PointerEvent('pointerdown', { ...eventInit, pointerType: 'mouse', isPrimary: true })); } catch (_error) {}
    try { target.dispatchEvent(new MouseEvent('mousedown', eventInit)); } catch (_error) {}
    try { target.dispatchEvent(new PointerEvent('pointerup', { ...eventInit, pointerType: 'mouse', isPrimary: true })); } catch (_error) {}
    try { target.dispatchEvent(new MouseEvent('mouseup', eventInit)); } catch (_error) {}
    try { target.dispatchEvent(new MouseEvent('click', eventInit)); } catch (_error) {}
    return true;
  }

  async function clickVisionOtherByCoordinateFallback() {
    const { x, y } = VISION_OTHER_MAXIMIZED_POINT;
    const clicked = clickViewportPoint(x, y);
    await delay(180);
    return clicked;
  }

  async function clickVisionHeaderClickoutFallback() {
    const { x, y } = VISION_CLICKOUT_MAXIMIZED_POINT;
    const clicked = clickViewportPoint(x, y);
    await delay(180);
    return clicked;
  }

  async function runVisionOtherMaximizedSequence(root) {
    await scrollVisionProductTypeMenuToBottom(root);
    await delay(140);
    await clickVisionOtherByCoordinateFallback();
    await delay(140);
    await clickVisionHeaderClickoutFallback();
    await delay(180);
  }

  function findVisionProductTypeSearchInput(root = document) {
    const scope = root || document;
    return Array.from(scope.querySelectorAll('input')).find((input) => {
      if (!(input instanceof HTMLInputElement)) return false;
      if (!isElementVisible(input)) return false;
      const placeholder = norm(input.getAttribute('placeholder') || '');
      const ariaLabel = norm(input.getAttribute('aria-label') || '');
      return placeholder.includes('search') || ariaLabel.includes('search');
    }) || null;
  }

  async function clearAndBlurVisionProductTypeSearch(root) {
    const input = findVisionProductTypeSearchInput(root);
    if (!input) return false;
    try { input.focus(); } catch (_error) {}
    await delay(40);
    setInputValue(input, '');
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
    await delay(50);
    try {
      input.dispatchEvent(new FocusEvent('blur', { bubbles: true }));
    } catch (_error) {
      input.blur?.();
    }
    await delay(60);
    return true;
  }

  async function selectOtherViaSearchFlow(root) {
    const search = findVisionProductTypeSearchInput(root);
    if (!search) return false;
    try { search.focus(); } catch (_error) {}
    await delay(50);
    setInputValue(search, 'other');
    search.dispatchEvent(new Event('input', { bubbles: true }));
    search.dispatchEvent(new Event('change', { bubbles: true }));
    await delay(220);

    let menu = getVisibleVisionDropdownMenu();
    let options = getVisionDropdownOptionNodes(menu);
    let otherOption = options.find((option) => {
      const value = norm(getVisionOptionValue(option));
      const label = norm(getVisionOptionLabel(option));
      return value === 'other' || label === 'other' || label === 'other (please specify)';
    }) || null;

    if (!otherOption) {
      await clickVisionOtherByCoordinateFallback();
      await delay(180);
      menu = getVisibleVisionDropdownMenu();
      options = getVisionDropdownOptionNodes(menu);
      otherOption = options.find((option) => {
        const value = norm(getVisionOptionValue(option));
        const label = norm(getVisionOptionLabel(option));
        return value === 'other' || label === 'other' || label === 'other (please specify)';
      }) || null;
    }

    if (otherOption && !isVisionOptionChecked(otherOption)) {
      await clickVisionOptionToggle(otherOption);
      await delay(160);
    }

    setInputValue(search, '');
    search.dispatchEvent(new Event('input', { bubbles: true }));
    search.dispatchEvent(new Event('change', { bubbles: true }));
    await delay(80);
    await clickVisionHeaderClickoutFallback();
    await delay(140);
    return Boolean(otherOption);
  }

  async function closeVisionMenuButton(button) {
    if (!button) return;
    const activeEl = document.activeElement;
    if (activeEl instanceof HTMLElement) {
      try { activeEl.blur(); } catch (_error) {}
      await delay(60);
    }
    try { button.click(); } catch (_error) {}
    await delay(180);
    if (getVisibleVisionDropdownMenu()) {
      try { button.dispatchEvent(new MouseEvent('mousedown', { bubbles: true })); } catch (_error) {}
      try { button.dispatchEvent(new MouseEvent('mouseup', { bubbles: true })); } catch (_error) {}
      try { button.dispatchEvent(new MouseEvent('click', { bubbles: true })); } catch (_error) {}
      await delay(180);
    }
    if (getVisibleVisionDropdownMenu()) {
      const headerStrip = findVisionModalHeaderStrip(document);
      if (headerStrip) {
        try { headerStrip.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, pointerType: 'mouse', isPrimary: true })); } catch (_error) {}
        try { headerStrip.dispatchEvent(new MouseEvent('mousedown', { bubbles: true })); } catch (_error) {}
        try { headerStrip.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, pointerType: 'mouse', isPrimary: true })); } catch (_error) {}
        try { headerStrip.dispatchEvent(new MouseEvent('mouseup', { bubbles: true })); } catch (_error) {}
        try { headerStrip.dispatchEvent(new MouseEvent('click', { bubbles: true })); } catch (_error) {}
        await delay(180);
      }
    }
    if (getVisibleVisionDropdownMenu()) {
      await clickVisionHeaderClickoutFallback();
    }
    if (getVisibleVisionDropdownMenu()) {
      try { document.body.click(); } catch (_error) {}
      await delay(120);
    }
    if (getVisibleVisionDropdownMenu()) {
      try {
        document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', bubbles: true }));
        document.dispatchEvent(new KeyboardEvent('keyup', { key: 'Escape', code: 'Escape', bubbles: true }));
      } catch (_error) {}
      await delay(120);
    }
  }

  async function readVisionProductTypeSelection(root) {
    const opened = await openVisionProductTypeMenu(root, 1800);
    if (!opened) return null;
    const { button, options } = opened;
    const selectedOptions = options.filter((option) => isVisionOptionChecked(option));
    const values = uniqueNormalizedList(selectedOptions
      .map((option) => getVisionOptionValue(option))
      .filter(Boolean));
    const labels = uniqueNormalizedList(selectedOptions
      .map((option) => getVisionOptionLabel(option))
      .filter(Boolean));
    const hasOther = values.includes('Other') || labels.some((label) => norm(label) === 'other (please specify)' || norm(label) === 'other');
    let customText = '';
    // Close menu first — the Other text input is outside the menu, visible when Other is checked
    await closeVisionMenuButton(button);
    if (hasOther) {
      // Give MD a moment to render the Other input after menu closes
      await delay(200);
      const otherInput = findVisionCustomTypeInput(root);
      customText = String(otherInput?.value || '').trim();
    }
    return {
      value: values[0] ?? labels[0] ?? null,
      label: labels.join(', '),
      values,
      labels,
      customText
    };
  }

  async function restoreVisionProductType(root, optionValues, optionLabels, customText) {
    const wantedValues = uniqueNormalizedList((Array.isArray(optionValues) ? optionValues : [optionValues])
      .map((value) => String(value ?? '').trim())
      .filter(Boolean));
    const wantedLabels = uniqueNormalizedList((Array.isArray(optionLabels) ? optionLabels : [optionLabels])
      .map((label) => String(label || '').trim())
      .filter(Boolean));
    // Empty = user intentionally cleared all types; uncheck everything
    const wantBlank = !wantedValues.length && !wantedLabels.length;

    const targetValues = new Set(wantedValues);
    const targetLabels = new Set(wantedLabels.map((label) => norm(label)));

    const setsMatch = (selectedValues) =>
      wantBlank
        ? selectedValues.length === 0
        : selectedValues.length === wantedValues.length && wantedValues.every((v) => selectedValues.includes(v));

    const findMatchingOption = (options, rawValue, rawLabel) => {
      const wantedValue = norm(rawValue);
      const wantedLabel = norm(rawLabel);
      return options.find((option) => {
        const value = norm(getVisionOptionValue(option));
        const label = norm(getVisionOptionLabel(option));
        if (wantedValue && value === wantedValue) return true;
        if (wantedLabel && label === wantedLabel) return true;
        if (wantedLabel && label.includes(wantedLabel)) return true;
        return false;
      }) || null;
    };

    const openAndGetOptions = async () => {
      const opened = await openVisionProductTypeMenu(root, 2200);
      if (!opened) return null;
      let menu = getVisibleVisionDropdownMenu();
      let options = getVisionDropdownOptionNodes(menu);
      return { ...opened, menu, options };
    };

    const ensureOptionChecked = async (_button, rawValue, rawLabel, { scrollBottom = false } = {}) => {
      let menu = getVisibleVisionDropdownMenu();
      if (!menu) return false;
      if (scrollBottom) {
        await scrollVisionProductTypeMenuToBottom(root);
        menu = getVisibleVisionDropdownMenu();
      }
      let options = getVisionDropdownOptionNodes(menu);
      let match = findMatchingOption(options, rawValue, rawLabel);
      const wantedValue = norm(rawValue);
      const wantedLabel = norm(rawLabel);
      const isOther = wantedValue === 'other' || wantedLabel === 'other' || wantedLabel === 'other (please specify)';
      if (!match && isOther) {
        await selectOtherViaSearchFlow(root);
        menu = getVisibleVisionDropdownMenu();
        options = getVisionDropdownOptionNodes(menu);
        match = findMatchingOption(options, rawValue, rawLabel);
      }
      if (!match) return false;
      if (!isVisionOptionChecked(match)) {
        await clickVisionOptionToggle(match);
        await delay(160);
      }
      return true;
    };

    const applyPass = async () => {
      const opened = await openAndGetOptions();
      if (!opened) return false;
      const { button } = opened;

      const currentMenu = getVisibleVisionDropdownMenu();
      const currentOptions = getVisionDropdownOptionNodes(currentMenu);
      const currentSelected = getVisionCheckedOptionValues(currentOptions);
      const wantsOther = targetValues.has('Other')
        || targetLabels.has('other (please specify)')
        || targetLabels.has('other');

      if (!wantBlank) {
        for (const option of currentOptions) {
          const value = getVisionOptionValue(option);
          const label = norm(getVisionOptionLabel(option));
          const shouldBeChecked = targetValues.has(value) || targetLabels.has(label);
          const checked = isVisionOptionChecked(option);
          if (checked && !shouldBeChecked) {
            await clickVisionOptionToggle(option);
            await delay(140);
          }
        }

        for (const wantedValue of wantedValues) {
          const wantedLabel = wantedLabels.find((label) => norm(label) === norm(wantedValue)) || wantedValue;
          const isOther = norm(wantedValue) === 'other' || norm(wantedLabel) === 'other' || norm(wantedLabel) === 'other (please specify)';
          await ensureOptionChecked(button, wantedValue, wantedLabel, { scrollBottom: isOther || wantsOther });
        }

        for (const wantedLabel of wantedLabels) {
          const isOther = norm(wantedLabel) === 'other' || norm(wantedLabel) === 'other (please specify)';
          await ensureOptionChecked(button, wantedLabel, wantedLabel, { scrollBottom: isOther || wantsOther });
        }
      } else if (currentSelected.length) {
        for (const option of currentOptions) {
          if (isVisionOptionChecked(option)) {
            await clickVisionOptionToggle(option);
            await delay(120);
          }
        }
      }

      const finalMenu = getVisibleVisionDropdownMenu();
      const finalOptions = getVisionDropdownOptionNodes(finalMenu);
      const finalSelected = getVisionCheckedOptionValues(finalOptions);
      const matches = setsMatch(finalSelected);
      await clearAndBlurVisionProductTypeSearch(root);
      await closeVisionMenuButton(button);
      return matches;
    };

    const currentSelectionMatches = async () => {
      const button = findVisionFieldButton(root, 'Select product type');
      const buttonText = norm((button?.innerText || button?.textContent || '').trim());
      if (wantBlank) {
        return !buttonText || buttonText === norm('select product type');
      }
      const allLabelsPresent = wantedLabels.every((label) => buttonText.includes(norm(label)));
      if (allLabelsPresent) return true;
      const live = await readVisionProductTypeSelection(root);
      const selectedValues = Array.isArray(live?.values) ? live.values : [];
      return setsMatch(selectedValues);
    };

    const waitForOtherInput = async (timeoutMs = 3000) => {
      const start = Date.now();
      let otherInput = findVisionCustomTypeInput(root);
      while (!otherInput && Date.now() - start < timeoutMs) {
        await delay(100);
        otherInput = findVisionCustomTypeInput(root);
      }
      return otherInput;
    };

    const setOtherInputValue = async (otherInput, value) => {
      if (!otherInput) return false;
      const desired = String(value || '').trim();
      if (!desired) return false;

      try { otherInput.focus(); } catch (_error) {}
      await delay(80);
      setInputValue(otherInput, desired);
      await delay(80);
      otherInput.dispatchEvent(new Event('input', { bubbles: true }));
      otherInput.dispatchEvent(new Event('change', { bubbles: true }));
      try {
        otherInput.dispatchEvent(new FocusEvent('blur', { bubbles: true }));
      } catch (_error) {
        otherInput.blur?.();
      }
      await delay(120);

      if (String(otherInput.value || '').trim() === desired) return true;

      const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
      try { otherInput.focus(); } catch (_error) {}
      await delay(50);
      if (nativeSetter) {
        nativeSetter.call(otherInput, desired);
      } else {
        otherInput.value = desired;
      }
      otherInput.dispatchEvent(new InputEvent('input', { bubbles: true, data: desired, inputType: 'insertText' }));
      otherInput.dispatchEvent(new Event('change', { bubbles: true }));
      try {
        otherInput.dispatchEvent(new FocusEvent('blur', { bubbles: true }));
      } catch (_error) {
        otherInput.blur?.();
      }
      await delay(150);

      return String(otherInput.value || '').trim() === desired;
    };

    const passOneOk = await applyPass();
    if (!passOneOk && !(await currentSelectionMatches())) {
      return false;
    }

    const wantsOther = wantedValues.includes('Other')
      || wantedLabels.map((label) => norm(label)).includes('other (please specify)')
      || wantedLabels.map((label) => norm(label)).includes('other');
    if (wantsOther && customText) {
      await delay(300);
      const otherInput = await waitForOtherInput(3000);
      if (otherInput) {
        await setOtherInputValue(otherInput, customText);
      }
    }
    return true;
  }

  async function restoreVisionProfileProductType(root, profile) {
    const values = profile?.productTypeValues?.length ? profile.productTypeValues : profile?.productTypeValue;
    const labels = profile?.productTypeLabels?.length ? profile.productTypeLabels : profile?.productType;
    const customText = profile?.productTypeCustomText || '';
    const labelList = (Array.isArray(labels) ? labels : [labels]).map((label) => norm(label)).filter(Boolean);
    const valueList = (Array.isArray(values) ? values : [values]).map((value) => norm(value)).filter(Boolean);
    const hasOther = valueList.includes('other')
      || labelList.includes('other')
      || labelList.includes('other (please specify)');

    if (!hasOther) {
      return restoreVisionProductType(root, values, labels, customText);
    }

    await restoreVisionProductType(
      root,
      (Array.isArray(values) ? values : [values]).filter((value) => norm(value) !== 'other'),
      (Array.isArray(labels) ? labels : [labels]).filter((label) => {
        const normalized = norm(label);
        return normalized !== 'other' && normalized !== 'other (please specify)';
      }),
      ''
    );

    const opened = await openVisionProductTypeMenu(root, 2200);
    if (opened) {
      await selectOtherViaSearchFlow(root);
    }

    if (customText) {
      await delay(220);
      const start = Date.now();
      let otherInput = findVisionCustomTypeInput(root);
      while (!otherInput && Date.now() - start < 3000) {
        await delay(100);
        otherInput = findVisionCustomTypeInput(root);
      }
      if (otherInput) {
        try { otherInput.focus(); } catch (_error) {}
        await delay(60);
        setInputValue(otherInput, customText);
        otherInput.dispatchEvent(new Event('input', { bubbles: true }));
        otherInput.dispatchEvent(new Event('change', { bubbles: true }));
        try {
          otherInput.dispatchEvent(new FocusEvent('blur', { bubbles: true }));
        } catch (_error) {
          otherInput.blur?.();
        }
      }
    }

    return true;
  }

  async function selectVisionDropdownOption(root, labelText, optionValue, optionLabel, forceSet = false) {
    const button = findVisionFieldButton(root, labelText);
    if (!button) return false;
    const currentLabel = (button.innerText || button.textContent || '').trim();
    // Skip only when labels match AND we're not forcing (force used for swapped field restore)
    if (!forceSet && optionLabel && norm(currentLabel) === norm(optionLabel)) return true;
    button.click();
    const menu = await waitForVisionMenu();
    if (!menu) return false;
    const options = getVisionDropdownOptionNodes(menu);
    const match = findVisionOptionMatch(options, optionValue, optionLabel);
    if (!match) {
      button.click();
      await delay(80);
      return false;
    }
    match.click();
    await delay(150);
    return true;
  }

  async function restoreVisionProductFeatures(root, selectedValues = [], selectedLabels = []) {
    const button = findVisionFieldButton(root || document, 'Generate product features');
    if (!button) return false;
    button.click();
    const menu = await waitForVisionMenu(1500);
    if (!menu) return false;
    const options = getVisionDropdownOptionNodes(menu);
    const wanted = new Set((selectedValues || []).map((v) => String(v)));
    const wantedLabels = (selectedLabels || []).map((label) => norm(label || '')).filter(Boolean);
    options.forEach((li) => {
      const value = String(parseOptionValue(li.getAttribute('data-value')) ?? '');
      const text = norm(li.textContent || '');
      const checked = !li.querySelector('svg')?.classList.contains('invisible');
      const shouldBeChecked = wanted.has(value) || wantedLabels.some((label) => text === label || text.includes(label));
      if (checked !== shouldBeChecked) li.click();
    });
    button.click();
    await delay(150);
    return true;
  }

  function uniqueNormalizedList(items) {
    const seen = new Set();
    const out = [];
    (items || []).forEach((item) => {
      const raw = String(item || '').trim();
      const key = norm(raw);
      if (!raw || !key || seen.has(key)) return;
      seen.add(key);
      out.push(raw);
    });
    return out;
  }

  function getVisionDropdownSelection(root, labelText) {
    const button = findVisionFieldButton(root, labelText);
    const label = (button?.innerText || button?.textContent || '').trim();
    let value = button?.getAttribute('data-value');
    if (value == null || value === '') value = button?.dataset?.value;
    if (value == null || value === '') value = label || null;
    const labels = uniqueNormalizedList(label
      .split(',')
      .map((part) => part.trim())
      .filter(Boolean));
    const values = uniqueNormalizedList(String(value == null ? '' : value)
      .split(',')
      .map((part) => parseOptionValue(part.trim()))
      .filter((part) => part != null && part !== ''));
    return {
      value: parseOptionValue(value),
      label,
      values,
      labels
    };
  }

  async function getVisionProductTypeSelection(root) {
    const live = await readVisionProductTypeSelection(root);
    if (live && (live.values.length || live.labels.length)) return live;
    return getVisionDropdownSelection(root, 'Select product type');
  }

  function getVisionProductFeatureSelection() {
    const button = findVisionFieldButton(document, 'Generate product features');
    if (!button) return { values: [], labels: [] };
    const rawValue = button.getAttribute('data-value') || button.dataset?.value || '';
    const values = String(rawValue)
      .split(',')
      .map((part) => parseOptionValue(part.trim()))
      .filter((value) => value != null && value !== '');
    const labels = (button.innerText || button.textContent || '')
      .split(',')
      .map((part) => part.trim())
      .filter(Boolean);
    return { values, labels };
  }

  async function captureVisionProfile(root) {
    const inputSlot = getVisionDropdownSelection(root, 'Input File Slot');
    const productType = await getVisionProductTypeSelection(root);
    const platform = getVisionDropdownSelection(root, 'Select platform');
    const model = getVisionDropdownSelection(root, 'Select model');
    const titleField = getVisionDropdownSelection(root, 'Title field');
    const descriptionField = getVisionDropdownSelection(root, 'Description field');
    const tagsField = getVisionDropdownSelection(root, 'Tags field');
    const writingMode = getVisionDropdownSelection(root, 'Writing Mode');
    const productFeatures = getVisionProductFeatureSelection();
    const productTypeCustomInput = findVisionCustomTypeInput(root);
    return {
      id: uid(),
      name: `${platform.label || 'Vision'} ${productType.label || 'Preset'}`.trim(),
      createdAt: Date.now(),
      inputSlotValue: inputSlot.value,
      inputSlotLabel: inputSlot.label,
      productTypeValue: productType.value,
      productTypeValues: productType.values,
      productType: productType.label,
      productTypeLabels: productType.labels,
      productTypeCustomText: String(productType.customText || (productType.labels.some((label) => norm(label) === 'other' || norm(label) === 'other (please specify)') ? (productTypeCustomInput?.value || '') : '')).trim(),
      platformValue: platform.value,
      platform: platform.label,
      modelValue: model.value,
      model: model.label,
      titleFieldValue: titleField.value,
      titleField: titleField.label,
      descriptionFieldValue: descriptionField.value,
      descriptionField: descriptionField.label,
      tagsFieldValue: tagsField.value,
      tagsField: tagsField.label,
      writingModeValue: writingMode.value,
      writingMode: writingMode.label,
      productFeatureValues: productFeatures.values,
      productFeatureLabels: productFeatures.labels,
      customInstructions: findVisionCITextarea(root)?.value || ''
    };
  }

  function getVisionProfiles() {
    return new Promise((resolve) => {
      if (!extensionStorage || !extensionRuntime?.id) {
        resolve([]);
        return;
      }
      extensionStorage.get({ [VISION_PROFILE_STORAGE_KEY]: [] }, (data) => {
        if (chrome.runtime?.lastError) {
          resolve([]);
          return;
        }
        resolve(Array.isArray(data[VISION_PROFILE_STORAGE_KEY]) ? data[VISION_PROFILE_STORAGE_KEY] : []);
      });
    });
  }

  function setVisionProfiles(items) {
    return new Promise((resolve) => {
      if (!extensionStorage || !extensionRuntime?.id) {
        resolve();
        return;
      }
      try {
        extensionStorage.set({ [VISION_PROFILE_STORAGE_KEY]: items }, () => resolve());
      } catch (_error) {
        resolve();
      }
    });
  }

  function openVisionProfileManager(root) {
    ensureVisionPMStyle();
    closeVisionProfileManager();
    if (!visionProfileSaveHandlerInstalled) {
      visionProfileSaveHandlerInstalled = true;
      document.addEventListener('click', async (event) => {
        const target = event.target;
        if (!(target instanceof Element)) return;
        const saveButton = target.closest('#ldd-vision-profile-save-btn');
        if (!saveButton) return;
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation?.();
        await latestVisionProfileSave?.();
      }, true);
    }
    const modal = document.createElement('div');
    modal.id = VISION_PROFILE_MODAL_ID;
    modal.innerHTML = `
      <div class="ldd-pm-backdrop"></div>
      <div class="ldd-pm-card">
        <div class="ldd-pm-top">
          <div class="ldd-pm-title-wrap">
            <div class="ldd-pm-title"><img src="${VISION_PRESET_LOGO_URL}" alt="" /><span>Profile Manager</span></div>
            <div class="ldd-pm-sub">Save and load your Vision AI setup.</div>
          </div>
          <button type="button" class="ldd-pm-close">×</button>
        </div>
        <div class="ldd-pm-actions">
          <button type="button" class="ldd-pm-action primary" id="ldd-vision-profile-save-btn" data-role="save-current" style="margin:0 auto;display:inline-flex;min-width:220px;justify-content:center;">Save Current as Profile</button>
          <div class="ldd-pm-save-status" data-role="save-status" style="display:none;align-self:center;font-size:12px;font-weight:800;color:#16a34a;">Saved ✓</div>
        </div>
        <div class="ldd-pm-list"></div>
      </div>
    `;
    document.body.appendChild(modal);

    const list = modal.querySelector('.ldd-pm-list');
    const saveStatus = modal.querySelector('[data-role="save-status"]');
    const saveBtn = modal.querySelector('#ldd-vision-profile-save-btn');
    const close = () => closeVisionProfileManager();
    const state = { items: [], renamingId: null, confirmDeleteId: null };

    const saveCurrentPreset = async () => {
      if (saveBtn instanceof HTMLElement) saveBtn.textContent = 'Saving...';
      const preset = await captureVisionProfile(root);
      state.items.unshift(preset);
      await setVisionProfiles(state.items);
      render();
      flashSaved();
      if (saveBtn instanceof HTMLElement && saveBtn.isConnected) saveBtn.textContent = 'Save Current as Profile';
      // Show CI save prompt if there are custom instructions
      const ciText = (preset.customInstructions || '').trim();
      if (ciText) openCISavePrompt(ciText, root, state);
    };
    latestVisionProfileSave = saveCurrentPreset;

    const flashSaved = () => {
      if (!(saveStatus instanceof HTMLElement)) return;
      saveStatus.style.display = 'block';
      saveStatus.textContent = 'Saved ✓';
      window.setTimeout(() => {
        if (saveStatus.isConnected) saveStatus.style.display = 'none';
      }, 1400);
    };

    const render = () => {
      const pinned = state.items.filter((i) => i.pinned).sort((a, b) => Number(b.createdAt || 0) - Number(a.createdAt || 0));
      const rest = state.items.filter((i) => !i.pinned).sort((a, b) => Number(b.createdAt || 0) - Number(a.createdAt || 0));
      const items = [...pinned, ...rest];
      if (!list) return;
      const renderCard = (item) => {
        const isRenaming = state.renamingId === item.id;
        const isConfirmingDelete = state.confirmDeleteId === item.id;
        const hasOtherType = Boolean(
          (Array.isArray(item.productTypeLabels) && item.productTypeLabels.some((label) => {
            const normalized = norm(label);
            return normalized === 'other' || normalized === 'other (please specify)';
          }))
          || (Array.isArray(item.productTypeValues) && item.productTypeValues.some((value) => norm(value) === 'other'))
          || norm(item.productType) === 'other'
          || norm(item.productType) === 'other (please specify)'
          || norm(item.productTypeValue) === 'other'
        );
        const displayProductTypes = (() => {
          const labels = Array.isArray(item.productTypeLabels) && item.productTypeLabels.length
            ? [...item.productTypeLabels]
            : [item.productType].filter(Boolean);
          const customText = String(item.productTypeCustomText || '').trim();
          if (!labels.length) return item.productType || '';
          return labels.map((label) => {
            const normalized = norm(label);
            if ((normalized === 'other' || normalized === 'other (please specify)') && customText) {
              return customText;
            }
            return label;
          }).filter(Boolean).join(', ');
        })();
        const profileKind = hasOtherType ? 'Digital' : 'Print on Demand';
        const titleText = String(item.name || 'Untitled Profile');
        const previewParts = [displayProductTypes, item.platform, item.model, item.writingMode]
          .filter(Boolean)
          .filter((part, index, arr) => arr.findIndex((entry) => norm(entry) === norm(part)) === index)
          .filter((part) => !norm(titleText).includes(norm(part)));
        const preview = escapeHTML(previewParts.join(' • ') || 'Profile');
        return `
        <div class="ldd-pm-item${item.pinned ? ' pinned' : ''}" data-id="${item.id}">
          <div class="ldd-pm-head">
            <div class="ldd-pm-name">
              <span>${escapeHTML(titleText)}</span>
              ${item.pinned ? '<span class="ldd-pm-pin-badge">📌 pinned</span>' : ''}
            </div>
            <div class="ldd-pm-icon-row">
              <button type="button" class="ldd-pm-icon-btn${item.pinned ? ' active' : ''}" data-action="pin" data-id="${item.id}">
                <svg viewBox="0 0 24 24"><path d="M12 2a7 7 0 0 1 7 7c0 4-7 13-7 13S5 13 5 9a7 7 0 0 1 7-7z"/><circle cx="12" cy="9" r="2.5"/></svg>
                <span class="ldd-tip">${item.pinned ? 'Unpin' : 'Pin'}</span>
              </button>
              <button type="button" class="ldd-pm-icon-btn" data-action="rename" data-id="${item.id}">
                <svg viewBox="0 0 24 24"><path d="M17 3a2.85 2.85 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/></svg>
                <span class="ldd-tip">Rename</span>
              </button>
              <button type="button" class="ldd-pm-icon-btn" data-action="duplicate" data-id="${item.id}">
                <svg viewBox="0 0 24 24"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                <span class="ldd-tip">Duplicate</span>
              </button>
              <button type="button" class="ldd-pm-icon-btn danger" data-action="delete" data-id="${item.id}">
                <svg viewBox="0 0 24 24"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="m19 6-1 14H6L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/></svg>
                <span class="ldd-tip">Delete</span>
              </button>
            </div>
          </div>
          ${isRenaming ? `
          <div class="ldd-pm-rename-row">
            <input type="text" class="ldd-pm-rename-input" data-rename-id="${item.id}" value="${escapeHTML(item.name || '')}" maxlength="80" placeholder="Profile name…" />
            <button type="button" class="ldd-pm-rename-ok" data-action="rename-ok" data-id="${item.id}">Save</button>
            <button type="button" class="ldd-pm-rename-cancel" data-action="rename-cancel">Cancel</button>
          </div>` : ''}
          <div class="ldd-pm-preview">${preview}</div>
          <div class="ldd-pm-type-badge ${hasOtherType ? 'digital' : 'pod'}">${profileKind}</div>
          ${hasOtherType && item.productTypeCustomText ? `<div class="ldd-pm-preview" style="color:#b45309;font-size:11px;font-weight:700;">Digital profile types: ${escapeHTML(item.productTypeCustomText)}</div>` : ''}
          ${item.customInstructions ? `<div class="ldd-pm-preview" style="color:#4f46e5;font-size:11px;">CI: ${escapeHTML(String(item.customInstructions || '').slice(0, 120))}${(item.customInstructions || '').length > 120 ? '…' : ''}</div>` : ''}
          <div class="ldd-pm-actions">
            <button type="button" class="ldd-pm-action primary" data-action="load" data-id="${item.id}">Load Profile</button>
          </div>
          ${isConfirmingDelete ? `
            <div class="ldd-pm-confirm">
              <div class="ldd-pm-confirm-text">Delete this profile?</div>
              <div class="ldd-pm-confirm-actions">
                <button type="button" class="ldd-pm-action" data-action="delete-cancel">Cancel</button>
                <button type="button" class="ldd-pm-action danger" data-action="delete-confirm" data-id="${item.id}">Delete</button>
              </div>
            </div>
          ` : ''}
        </div>`;
      };
      const isDigitalProfile = (item) => {
        const labels = [
          ...(Array.isArray(item.productTypeLabels) ? item.productTypeLabels : [item.productType]),
          item.productType
        ].map((label) => norm(label)).filter(Boolean);
        const values = [
          ...(Array.isArray(item.productTypeValues) ? item.productTypeValues : [item.productTypeValue]),
          item.productTypeValue
        ].map((value) => norm(value)).filter(Boolean);
        return values.includes('digital')
          || values.includes('other')
          || labels.includes('digital')
          || labels.includes('other')
          || labels.includes('other (please specify)');
      };
      const podItems = items.filter((item) => !isDigitalProfile(item));
      const digitalItems = items.filter((item) => !podItems.includes(item));
      list.innerHTML = `
        <div class="ldd-pm-section-note">Do not combine Print on Demand and Digital types in the same profile, as it will not work properly.</div>
        <div class="ldd-pm-column">
          <div class="ldd-pm-column-head pod">Print on Demand</div>
          ${podItems.length ? podItems.map(renderCard).join('') : '<div class="ldd-pm-empty">No Print on Demand profiles yet.</div>'}
        </div>
        <div class="ldd-pm-column">
          <div class="ldd-pm-column-head digital">Digital<div class="ldd-pm-column-sub">Select &quot;Other&quot; in Product Types &amp; Then Enter Type in text box</div></div>
          ${digitalItems.length ? digitalItems.map(renderCard).join('') : '<div class="ldd-pm-empty">No Digital profiles yet.</div>'}
        </div>
      `;
      // Focus rename input if renaming
      if (state.renamingId) {
        const inp = list.querySelector(`[data-rename-id="${state.renamingId}"]`);
        if (inp instanceof HTMLInputElement) { inp.focus(); inp.select(); }
      }
    };

    saveBtn?.addEventListener('click', async (event) => {
      event.preventDefault();
      event.stopPropagation();
      await saveCurrentPreset();
    });

    modal.addEventListener('click', async (event) => {
      const target = event.target;
      if (!(target instanceof HTMLElement)) return;

      if (target.closest('#ldd-vision-profile-save-btn')) {
        await saveCurrentPreset();
        return;
      }
      if (target.closest('.ldd-pm-backdrop') || target.closest('.ldd-pm-close')) {
        close();
        return;
      }

      const action = target.dataset.action;
      const id = target.dataset.id;

      if (action === 'pin') {
        const item = state.items.find((i) => i.id === id);
        if (item) { item.pinned = !item.pinned; await setVisionProfiles(state.items); render(); }
        return;
      }
      if (action === 'rename') {
        state.renamingId = state.renamingId === id ? null : id;
        render();
        return;
      }
      if (action === 'rename-ok') {
        const inp = list.querySelector(`[data-rename-id="${id}"]`);
        const newName = (inp instanceof HTMLInputElement ? inp.value : '').trim();
        if (newName) {
          const item = state.items.find((i) => i.id === id);
          if (item) item.name = newName;
        }
        state.renamingId = null;
        await setVisionProfiles(state.items);
        render();
        return;
      }
      if (action === 'rename-cancel') {
        state.renamingId = null;
        render();
        return;
      }
      if (action === 'duplicate') {
        const item = state.items.find((i) => i.id === id);
        if (item) {
          const copy = Object.assign({}, item, { id: uid(), name: (item.name || 'Profile') + ' (copy)', createdAt: Date.now(), pinned: false });
          state.items.unshift(copy);
          await setVisionProfiles(state.items);
          render();
        }
        return;
      }
      if (action === 'delete') {
        state.confirmDeleteId = id;
        render();
        return;
      }
      if (action === 'delete-cancel') {
        state.confirmDeleteId = null;
        render();
        return;
      }
      if (action === 'delete-confirm') {
        state.items = state.items.filter((item) => item.id !== id);
        if (state.renamingId === id) state.renamingId = null;
        if (state.confirmDeleteId === id) state.confirmDeleteId = null;
        await setVisionProfiles(state.items);
        render();
        return;
      }
      if (action === 'load') {
        const found = state.items.find((item) => item.id === id);
        if (!found) return;
        // Close modal first so MD dropdowns are accessible
        closeVisionProfileManager();
        await delay(120);
        // Load sequence with longer gaps to let React settle
        await restoreVisionProfileProductType(root, found);
        await delay(300);
        await selectVisionDropdownOption(root, 'Select platform', found.platformValue, found.platform, true);
        await delay(200);
        await selectVisionDropdownOption(root, 'Select model', found.modelValue, found.model, true);
        await delay(200);
        await selectVisionDropdownOption(root, 'Title field', found.titleFieldValue, found.titleField, true);
        await delay(150);
        await selectVisionDropdownOption(root, 'Description field', found.descriptionFieldValue, found.descriptionField, true);
        await delay(150);
        await selectVisionDropdownOption(root, 'Tags field', found.tagsFieldValue, found.tagsField, true);
        await delay(150);
        await selectVisionDropdownOption(root, 'Writing Mode', found.writingModeValue, found.writingMode, true);
        await delay(200);
        await restoreVisionProductFeatures(root, found.productFeatureValues, found.productFeatureLabels);
        // Verify & retry any dropdowns that didn't stick
        await delay(300);
        const retryList = [
          ['Select platform', found.platformValue, found.platform],
          ['Select model', found.modelValue, found.model],
          ['Title field', found.titleFieldValue, found.titleField],
          ['Description field', found.descriptionFieldValue, found.descriptionField],
          ['Tags field', found.tagsFieldValue, found.tagsField],
        ];
        for (const [label, value, labelVal] of retryList) {
          const btn = findVisionFieldButton(root, label);
          const current = norm((btn?.innerText || btn?.textContent || '').trim());
          if (labelVal && current !== norm(labelVal)) {
            await selectVisionDropdownOption(root, label, value, labelVal, true);
            await delay(150);
          }
        }
        // Restore custom instructions
        if (typeof found.customInstructions === 'string') {
          if (found.customInstructions && !isVisionCIChecked(root)) {
            clickVisionCICheckbox(root);
            await delay(200);
          }
          const ciStart = Date.now();
          let ciTarget = findVisionCITextarea(root);
          while (!ciTarget && Date.now() - ciStart < 2200) {
            await delay(80);
            ciTarget = findVisionCITextarea(root);
          }
          if (ciTarget) setTextareaValue(ciTarget, found.customInstructions || '');
        }
      }
    });

    // Allow Enter key to confirm rename
    modal.addEventListener('keydown', async (event) => {
      if (event.key === 'Enter' && state.renamingId) {
        const inp = list.querySelector(`[data-rename-id="${state.renamingId}"]`);
        const newName = (inp instanceof HTMLInputElement ? inp.value : '').trim();
        if (newName) {
          const item = state.items.find((i) => i.id === state.renamingId);
          if (item) item.name = newName;
        }
        state.renamingId = null;
        await setVisionProfiles(state.items);
        render();
      }
      if (event.key === 'Escape' && state.renamingId) {
        state.renamingId = null;
        render();
      }
    });

    getVisionProfiles().then((items) => {
      state.items = Array.isArray(items) ? items : [];
      render();
    });
  }

  function openVisionPromptManager(root) {
    ensureVisionPMStyle();
    closeVisionPromptManager();
    const modal = document.createElement('div');
    modal.id = VISION_PM_MODAL_ID;
    modal.innerHTML = `
      <div class="ldd-pm-backdrop"></div>
      <div class="ldd-pm-card">
        <div class="ldd-pm-top">
          <div class="ldd-pm-title-wrap">
            <div class="ldd-pm-title"><img src="${VISION_PRESET_LOGO_URL}" alt="" /><span>Prompt Manager</span></div>
            <div class="ldd-pm-sub">Save, organize, and reuse your prompt snippets.</div>
            <div class="ldd-pm-sub">Saved Custom Instructions for Vision AI.</div>
          </div>
          <button type="button" class="ldd-pm-close">×</button>
        </div>
        <div class="ldd-pm-toolbar">
          <input type="text" class="ldd-pm-search" placeholder="Search prompts..." />
          <button type="button" class="ldd-pm-toolbar-btn" data-role="use-last">Use Last</button>
          <button type="button" class="ldd-pm-toolbar-btn primary" data-role="new">New Custom Instruction</button>
        </div>
        <div class="ldd-pm-list"></div>
      </div>
    `;
    document.body.appendChild(modal);
    const search = modal.querySelector('.ldd-pm-search');
    const list = modal.querySelector('.ldd-pm-list');
    const close = () => closeVisionPromptManager();
    const state = { items: [], search: '', editingId: null };

    const saveItems = async () => {
      await setClipboardItems(state.items);
    };

    const pastePromptToCI = (content) => {
      if (!isVisionCIChecked(root)) clickVisionCICheckbox(root);
      window.setTimeout(() => {
        const target = findVisionCITextarea(root) || findPasteTarget();
        const ok = setTextareaValue(target, String(content || ''));
        if (ok) closeVisionPromptManager();
      }, 90);
    };

    const sortedFilteredItems = () => {
      const q = norm(state.search || '');
      return state.items
        .filter((item) => !q || norm(item.name || '').includes(q) || norm(item.content || '').includes(q))
        .sort((a, b) => Number(b.pinned || false) - Number(a.pinned || false) || Number(b.createdAt || 0) - Number(a.createdAt || 0));
    };

    const render = () => {
      const filtered = sortedFilteredItems();
      list.innerHTML = '';
      if (!filtered.length) {
        list.innerHTML = '<div class="ldd-pm-empty">No saved prompts yet.</div>';
        return;
      }
      filtered.forEach((item) => {
        const card = document.createElement('div');
        card.className = `ldd-pm-item ${item.pinned ? 'pinned' : ''}`.trim();

        if (item.id === state.editingId) {
          card.innerHTML = `
            <div class="ldd-pm-edit">
              <input type="text" class="ldd-pm-edit-name" maxlength="80" value="${escapeHTML(item.name || '')}" placeholder="Prompt name..." />
              <textarea class="ldd-pm-edit-content" placeholder="Prompt content...">${escapeHTML(item.content || '')}</textarea>
              <div class="ldd-pm-actions">
                <button type="button" class="ldd-pm-action primary" data-action="save">Save</button>
                <button type="button" class="ldd-pm-action" data-action="cancel">Cancel</button>
              </div>
            </div>
          `;
          card.querySelector('[data-action="save"]')?.addEventListener('click', async () => {
            const name = (card.querySelector('.ldd-pm-edit-name')?.value || '').trim() || 'Untitled';
            const content = (card.querySelector('.ldd-pm-edit-content')?.value || '').trim();
            const target = state.items.find((entry) => entry.id === item.id);
            if (target) {
              target.name = name;
              target.content = content;
              target.createdAt = target.createdAt || Date.now();
              await saveItems();
            }
            state.editingId = null;
            render();
          });
          card.querySelector('[data-action="cancel"]')?.addEventListener('click', async () => {
            const target = state.items.find((entry) => entry.id === item.id);
            if (target && !target.content && (target.name === 'New Custom Instruction' || target.name === 'Untitled')) {
              state.items = state.items.filter((entry) => entry.id !== item.id);
              await saveItems();
            }
            state.editingId = null;
            render();
          });
          list.appendChild(card);
          window.setTimeout(() => card.querySelector('.ldd-pm-edit-name')?.focus(), 20);
          return;
        }

        card.innerHTML = `
          <div class="ldd-pm-head">
            <div class="ldd-pm-name">${item.pinned ? '<span class="ldd-pm-pin">📌</span>' : ''}<span>${escapeHTML(item.name || 'Untitled')}</span></div>
          </div>
          <div class="ldd-pm-preview">${escapeHTML(makePromptPreview(item.content))}</div>
          <div class="ldd-pm-actions">
            <button type="button" class="ldd-pm-action primary" data-action="paste">Paste to Custom Instructions</button>
            <button type="button" class="ldd-pm-action" data-action="copy">Copy</button>
            <button type="button" class="ldd-pm-action" data-action="edit">Edit</button>
            <button type="button" class="ldd-pm-action" data-action="pin">${item.pinned ? 'Unpin' : 'Pin'}</button>
            <button type="button" class="ldd-pm-action danger" data-action="delete">Delete</button>
          </div>
        `;
        card.querySelector('[data-action="paste"]')?.addEventListener('click', () => pastePromptToCI(item.content));
        card.querySelector('[data-action="copy"]')?.addEventListener('click', async (event) => {
          await copyPromptText(item.content || '');
          const btn = event.currentTarget;
          const prev = btn.textContent;
          btn.textContent = 'Copied!';
          window.setTimeout(() => { btn.textContent = prev; }, 700);
        });
        card.querySelector('[data-action="edit"]')?.addEventListener('click', () => {
          state.editingId = item.id;
          render();
        });
        card.querySelector('[data-action="pin"]')?.addEventListener('click', async () => {
          const target = state.items.find((entry) => entry.id === item.id);
          if (!target) return;
          target.pinned = !target.pinned;
          await saveItems();
          render();
        });
        card.querySelector('[data-action="delete"]')?.addEventListener('click', async () => {
          state.items = state.items.filter((entry) => entry.id !== item.id);
          await saveItems();
          render();
        });
        list.appendChild(card);
      });
    };

    modal.querySelector('.ldd-pm-backdrop')?.addEventListener('click', close);
    modal.querySelector('.ldd-pm-close')?.addEventListener('click', close);
    search?.addEventListener('input', () => {
      state.search = search.value || '';
      render();
    });
    modal.querySelector('[data-role="new"]')?.addEventListener('click', async () => {
      const newItem = { id: uid(), name: 'New Custom Instruction', content: '', pinned: false, createdAt: Date.now() };
      state.items.unshift(newItem);
      await saveItems();
      state.editingId = newItem.id;
      render();
    });
    modal.querySelector('[data-role="use-last"]')?.addEventListener('click', () => {
      const latest = state.items.slice().sort((a, b) => Number(b.createdAt || 0) - Number(a.createdAt || 0))[0];
      if (latest) pastePromptToCI(latest.content || '');
    });

    getClipboardItems().then((items) => {
      state.items = items;
      render();
      window.setTimeout(() => search?.focus(), 20);
    });
  }

  function injectVisionPromptManagerButton(root) {
    if (!root || !root.isConnected) return;
    try {
      ensureVisionPMStyle();
      const existing = root.querySelector('#' + VISION_PM_BUTTON_ID);
      const existingProfile = root.querySelector('#' + VISION_PROFILE_BUTTON_ID);
      if (existing && existingProfile) return;
      const row = findVisionCIRow(root);
      if (!row || !row.isConnected) return;
      const ensureWrap = () => {
        if (!row || !row.isConnected) return null;
        let wrap = row.querySelector('.ldd-vision-launchers');
        if (wrap) return wrap;
        wrap = document.createElement('div');
        wrap.className = 'ldd-vision-launchers';
        wrap.style.display = 'flex';
        wrap.style.flexWrap = 'wrap';
        wrap.style.alignItems = 'center';
        wrap.style.gap = '8px';
        wrap.style.marginTop = '8px';
        row.appendChild(wrap);
        return wrap;
      };
      const wrap = ensureWrap();
      if (!wrap) return;
      const btn = existing || document.createElement('button');
      btn.type = 'button';
      btn.id = VISION_PM_BUTTON_ID;
      btn.innerHTML = `<img src="${VISION_PRESET_LOGO_URL}" alt="" /><span>Prompt Manager</span><span class="ldd-vision-btn-tip">Save and reuse prompt snippets</span>`;
      btn.onclick = (event) => {
        event.preventDefault();
        event.stopPropagation();
        if (window.LDDSharedPromptManager?.open) {
          window.LDDSharedPromptManager.open();
        } else {
          openVisionPromptManager(root);
        }
      };
      const profileBtn = existingProfile || document.createElement('button');
      profileBtn.type = 'button';
      profileBtn.id = VISION_PROFILE_BUTTON_ID;
    profileBtn.innerHTML = `<img src="${VISION_PRESET_LOGO_URL}" alt="" /><span>Save / Load Profile</span><span class="ldd-vision-btn-tip">Save current settings or load a saved profile</span>`;
      profileBtn.onclick = (event) => {
        event.preventDefault();
        event.stopPropagation();
        openVisionProfileManager(root);
      };
      if (!btn.isConnected) wrap.appendChild(btn);
      if (!profileBtn.isConnected) wrap.appendChild(profileBtn);
    } catch (_error) {
      root.querySelector('.ldd-vision-launchers')?.remove();
    }
  }

  // ── CI Save Prompt ────────────────────────────────────────────────────────
  const CI_SAVE_PROMPT_ID = 'ldd-ci-save-prompt';

  function closeCISavePrompt() {
    document.getElementById(CI_SAVE_PROMPT_ID)?.remove();
  }

  function openCISavePrompt(ciText, root, profileState) {
    closeCISavePrompt();
    const prompt = document.createElement('div');
    prompt.id = CI_SAVE_PROMPT_ID;
    const preview = String(ciText || '').slice(0, 180);
    prompt.innerHTML = `
      <div class="ldd-csp-backdrop"></div>
      <div class="ldd-csp-card">
        <div class="ldd-csp-title"><img src="${VISION_PRESET_LOGO_URL}" alt="" /><span>Also save Custom Instructions?</span></div>
        <div class="ldd-csp-sub">Your profile is saved. Want to also store the CI text elsewhere?</div>
        <div class="ldd-csp-preview">${escapeHTML(preview)}${ciText.length > 180 ? '…' : ''}</div>
        <div class="ldd-csp-btns">
          <button type="button" class="ldd-csp-btn primary" data-csp="pm">Prompt Manager</button>
          <button type="button" class="ldd-csp-btn primary" data-csp="both">Both</button>
          <button type="button" class="ldd-csp-btn" data-csp="profile">New Profile</button>
          <button type="button" class="ldd-csp-btn skip" data-csp="skip">Skip</button>
        </div>
      </div>
    `;
    document.body.appendChild(prompt);

    prompt.addEventListener('click', async (event) => {
      const target = event.target;
      if (!(target instanceof HTMLElement)) return;
      if (target.closest('.ldd-csp-backdrop')) { closeCISavePrompt(); return; }
      const choice = target.dataset.csp;
      if (!choice) return;
      closeCISavePrompt();
      if (choice === 'skip') return;

      const saveToPM = choice === 'pm' || choice === 'both';
      const saveAsProfile = choice === 'profile';

      if (saveToPM && extensionStorage && extensionRuntime?.id) {
        try {
          const existing = await new Promise((resolve) => {
            extensionStorage.get({ clipboardItems: [] }, (d) => {
              if (chrome.runtime?.lastError) resolve([]);
              else resolve(Array.isArray(d.clipboardItems) ? d.clipboardItems : []);
            });
          });
          const newItem = {
            id: uid(),
            text: ciText,
            label: 'CI ' + new Date().toLocaleDateString(),
            section: 'custom-instructions',
            createdAt: Date.now()
          };
          existing.unshift(newItem);
          await new Promise((resolve) => extensionStorage.set({ clipboardItems: existing }, () => resolve()));
        } catch (_err) {}
      }

      if (saveAsProfile && root) {
        try {
          const preset = await captureVisionProfile(root);
          preset.customInstructions = ciText;
          preset.name = (preset.name || 'Profile') + ' (CI only)';
          const existing = await getVisionProfiles();
          existing.unshift(preset);
          await setVisionProfiles(existing);
          // Refresh the profile list if the modal is still open
          if (profileState) {
            profileState.items = existing;
          }
        } catch (_err) {}
      }
    });
  }

  function runVisionPreset() {
    if (!visionPresetsEnabled) return;
    const root = findVisionModalRoot();
    if (!root) {
      if (visionMountedRoot) {
        document.getElementById(VISION_PRESET_BLOCK_ID)?.remove();
        closeVisionPromptManager();
        visionMountedRoot = null;
        visionCIAutoCheckedForRoot = null;
        visionWriteInProgress = false;
      }
      return;
    }
    if (root !== visionMountedRoot) {
      document.getElementById(VISION_PRESET_BLOCK_ID)?.remove();
      closeVisionPromptManager();
      visionMountedRoot = root;
      visionCIAutoCheckedForRoot = null;
    }
    mountVisionPresetBlock(root);
    ensureVisionCustomInstructionsEnabled(root);
    injectVisionPromptManagerButton(root);
  }

  function queueVisionPresetRun(delay) {
    if (visionRunScheduled) return;
    visionRunScheduled = true;
    window.setTimeout(() => { visionRunScheduled = false; runVisionPreset(); },
      delay != null ? delay : VISION_RUN_DEBOUNCE_MS);
  }

    window.setInterval(() => queueVisionPresetRun(0), VISION_RUN_INTERVAL_MS);
  const visionPresetObserver = new MutationObserver(() => queueVisionPresetRun());
  visionPresetObserver.observe(document.body || document.documentElement, { childList: true, subtree: true });
  queueVisionPresetRun(0);
  loadAndApplySettings();

  // The SPA may not have fully rendered on first load. Poll every 1200ms for
  // up to 24s and re-apply settings until the enhancer is actually mounted.
  // Using 1200ms (longer than bindEvents takes) prevents concurrent enable()
  // calls that would race and tear out each other's DOM roots.
  let _startupTicks = 0;
  const _startupPoll = window.setInterval(() => {
    _startupTicks++;
    if (window.LDDEnhancer?.isOpen !== undefined && document.getElementById("ldd-enhancer-root")) {
      window.clearInterval(_startupPoll);
      return;
    }
    loadAndApplySettings();
    if (_startupTicks >= 20) window.clearInterval(_startupPoll);
  }, 1200);

  let lastKnownLocation = window.location.href || "";
  window.setInterval(() => {
    const currentLocation = window.location.href || "";
    if (currentLocation === lastKnownLocation) return;
    lastKnownLocation = currentLocation;
    loadAndApplySettings();
  }, 250);

  if (typeof chrome !== "undefined" && chrome?.storage?.onChanged?.addListener) {
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName !== "local") return;
      if (!changes.enhancerEnabled && !changes.qaBarEnabled && !changes.dropperEnabled &&
          !changes.visionAIPresetsEnabled && !changes.visionAIAutoEnableCI &&
          !changes.globalThemeEnabled && !changes.globalThemeMode &&
          !changes.globalThemeSolidColor && !changes.globalThemeGradientColor &&
          !changes.globalThemeBrightness) return;
      extensionStorage?.get(DEFAULT_SETTINGS).then((settings) => applyFeatureSettings(settings));
    });
  }

  if (typeof chrome !== "undefined" && chrome?.runtime?.onMessage?.addListener) {
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (message?.type === "ldd/paste" && typeof message.text === "string") {
        const ok = pasteIntoPage(message.text);
        sendResponse({ ok });
        return true;
      }
      if (message?.type === "ldd/ping") {
        sendResponse({ ok: true, url: window.location.href });
        return true;
      }
      return false;
    });
  }


  // ── Video Mockup Smart Selection Buttons ─────────────────────────────────
  const LDD_VM_BAR_ID = "ldd-vm-select-bar";
  const LDD_VM_LOGO_URL = chrome.runtime.getURL("assets/logo.png");

  function vmSleep(ms) {
    return new Promise((resolve) => window.setTimeout(resolve, ms));
  }

  function hardClick(element) {
    if (!element) return false;
    ["pointerdown", "mousedown", "pointerup", "mouseup", "click"].forEach((type) => {
      element.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
    });
    if (typeof element.click === "function") element.click();
    return true;
  }

  function isSlotFilled(slotEl) {
    const img = slotEl.querySelector("img");
    if (!img) return false;
    if ((img.className || "").includes("opacity-10")) return false;
    if ((img.alt || "").trim() === "MyDesigns Logo") return false;
    const src = (img.getAttribute("src") || "").trim();
    if (!src) return false;
    return true;
  }

  function getVideoMockupModal() {
    return Array.from(document.querySelectorAll("div[role='dialog'], div")).find((el) => {
      if (!el.querySelector) return false;
      const text = norm(el.textContent || "");
      return text.includes("create video mockups") && text.includes("clear all") && !!el.querySelector('[class*="aspect-square"], .aspect-square');
    }) || null;
  }

  function getSlotItems(modal) {
    if (!modal) return [];
    const grid = modal.querySelector('[data-v-0ef3f0b1][class*="grid"], [class*="grid"]');
    const scope = grid || modal;
    const cards = Array.from(scope.querySelectorAll('.aspect-square, [class*="aspect-square"]'));
    const seen = new Set();
    return cards.map((card) => card.closest('[data-v-0ef3f0b1].flex.flex-col.items-center, .flex.flex-col.items-center, label, button, div') || card).filter((item) => {
      if (!item || seen.has(item)) return false;
      seen.add(item);
      return true;
    });
  }

  function clickSlot(slotItem) {
    const target =
      slotItem?.querySelector?.('input[type="checkbox"], input[type="radio"]') ||
      slotItem?.querySelector?.('button[role="checkbox"], [aria-checked], [role="button"]') ||
      slotItem?.querySelector?.('.aspect-square, [class*="aspect-square"]') ||
      slotItem;
    return hardClick(target);
  }

  function clearAllSlots(modal) {
    const clearBtn = Array.from(modal.querySelectorAll("button, div, span")).find((el) =>
      norm(el.textContent) === "clear all" && isElementVisible(el)
    );
    return hardClick(clearBtn);
  }

  async function applyVideoMockupSelection(modal, picker) {
    if (!modal) return;
    clearAllSlots(modal);
    await vmSleep(140);
    let items = getSlotItems(modal);
    if (!items.length) {
      await vmSleep(220);
      items = getSlotItems(modal);
    }
    const picked = picker(items).filter(Boolean);
    for (const item of picked) {
      clickSlot(item);
      await vmSleep(24);
    }
  }

  function injectVideoMockupBar(modal) {
    if (modal.querySelector("#" + LDD_VM_BAR_ID)) return;

    const grid = modal.querySelector('[data-v-0ef3f0b1][class*="grid"]');
    if (!grid) return;

    const bar = document.createElement("div");
    bar.id = LDD_VM_BAR_ID;
    bar.style.cssText = [
      "display:flex",
      "align-items:center",
      "gap:12px",
      "margin:0 0 12px 0",
      "padding:10px 12px",
      "flex-wrap:wrap",
      "border-radius:16px",
      "border:1px solid rgba(30,41,59,.10)",
      "background:linear-gradient(180deg, rgba(255,255,255,.98), rgba(248,250,252,.96))",
      "box-shadow:0 12px 32px rgba(15,23,42,.08)"
    ].join(";") + ";";

    const label = document.createElement("div");
    label.style.cssText = [
      "display:flex",
      "align-items:center",
      "gap:8px",
      "font-size:11px",
      "font-weight:900",
      "letter-spacing:.08em",
      "text-transform:uppercase",
      "color:#475569",
      "white-space:nowrap",
      "padding:0 2px"
    ].join(";") + ";";
    const labelLogo = document.createElement("img");
    labelLogo.src = LDD_VM_LOGO_URL;
    labelLogo.alt = "LDD";
    labelLogo.style.cssText = "width:18px;height:18px;object-fit:contain;border-radius:5px;flex:0 0 18px;";
    const labelText = document.createElement("span");
    labelText.textContent = "Quick Select";
    label.append(labelLogo, labelText);

    const dock = document.createElement("div");
    dock.style.cssText = [
      "display:flex",
      "align-items:center",
      "gap:8px",
      "flex-wrap:wrap",
      "padding:6px",
      "border-radius:14px",
      "border:1px solid rgba(30,41,59,.08)",
      "background:rgba(255,255,255,.72)",
      "box-shadow:inset 0 1px 0 rgba(255,255,255,.75)"
    ].join(";") + ";";

    function makeBtn(text, onClick, accent = false) {
      const b = document.createElement("button");
      b.type = "button";
      b.textContent = text;
      const baseBg = accent ? "linear-gradient(180deg, #2f3d58, #1e2a3a)" : "linear-gradient(180deg, #ffffff, #f8fafc)";
      const hoverBg = accent ? "linear-gradient(180deg, #394b6a, #243246)" : "linear-gradient(180deg, #ffffff, #eef2f7)";
      const baseColor = accent ? "#ffffff" : "#334155";
      b.style.cssText = [
        "height:34px",
        "padding:0 14px",
        "border-radius:10px",
        `border:1px solid ${accent ? "rgba(30,42,58,.42)" : "rgba(148,163,184,.28)"}`,
        `background:${baseBg}`,
        `color:${baseColor}`,
        "font-size:12px",
        "font-weight:800",
        "cursor:pointer",
        "white-space:nowrap",
        "box-shadow:0 6px 16px rgba(15,23,42,.08)",
        "transition:transform .12s ease, box-shadow .12s ease, background .12s ease, color .12s ease"
      ].join(";") + ";";
      b.addEventListener("mouseenter", () => {
        b.style.background = hoverBg;
        b.style.transform = "translateY(-1px)";
        b.style.boxShadow = "0 10px 20px rgba(15,23,42,.12)";
      });
      b.addEventListener("mouseleave", () => {
        b.style.background = baseBg;
        b.style.transform = "translateY(0)";
        b.style.boxShadow = "0 6px 16px rgba(15,23,42,.08)";
      });
      b.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        onClick();
      });
      return b;
    }

    const buttonSpecs = [
      { label: "First 1", picker: (items) => items.slice(0, 1) },
      { label: "First 3", picker: (items) => items.slice(0, 3) },
      { label: "First 5", picker: (items) => items.slice(0, 5) },
      { label: "First 8", picker: (items) => items.slice(0, 8) },
      { label: "First 10", picker: (items) => items.slice(0, 10) },
      { label: "First 12", picker: (items) => items.slice(0, 12) },
      { label: "First 15", picker: (items) => items.slice(0, 15) },
      { label: "First 20", picker: (items) => items.slice(0, 20) },
      { label: "All Filled", picker: (items) => items.filter(isSlotFilled), accent: true },
      { label: "Skip 1", picker: (items) => items.filter(isSlotFilled).slice(1) },
      { label: "Skip 2", picker: (items) => items.filter(isSlotFilled).slice(2) },
      { label: "Skip 3", picker: (items) => items.filter(isSlotFilled).slice(3) }
    ];

    const modalWrap = document.createElement("div");
    modalWrap.style.cssText = [
      "position:fixed",
      "inset:0",
      "z-index:2147483647",
      "display:none",
      "align-items:center",
      "justify-content:center"
    ].join(";") + ";";

    const backdrop = document.createElement("div");
    backdrop.style.cssText = [
      "position:absolute",
      "inset:0",
      "background:rgba(15,23,42,.42)",
      "backdrop-filter:blur(6px)"
    ].join(";") + ";";

    const card = document.createElement("div");
    card.style.cssText = [
      "position:relative",
      "z-index:1",
      "width:min(92vw, 360px)",
      "border-radius:22px",
      "border:1px solid rgba(148,163,184,.26)",
      "background:#ffffff",
      "box-shadow:0 26px 70px rgba(15,23,42,.24)",
      "padding:18px"
    ].join(";") + ";";
    card.innerHTML = `
      <button type="button" data-vm-close="1" style="position:absolute;top:12px;right:12px;width:34px;height:34px;border:none;border-radius:999px;background:#f1f5f9;color:#475569;font-size:18px;font-weight:700;cursor:pointer;">×</button>
      <div style="font-size:18px;font-weight:900;color:#1e2a3a;margin-bottom:4px;">Select Filled (Custom)</div>
      <div style="font-size:12px;line-height:1.5;color:#64748b;margin-bottom:14px;">Pick the slot range to scan, then it will select only the filled ones inside that range.</div>
      <div style="display:grid;gap:12px;">
        <label style="display:grid;gap:6px;font-size:12px;font-weight:800;color:#334155;">
          Start Slot
          <input data-vm-start type="number" min="1" value="2" style="height:40px;border-radius:12px;border:1px solid rgba(148,163,184,.34);padding:0 12px;font-size:14px;font-weight:700;color:#1e293b;background:#fff;" />
        </label>
        <label style="display:grid;gap:6px;font-size:12px;font-weight:800;color:#334155;">
          End Slot
          <input data-vm-end type="number" min="1" value="10" style="height:40px;border-radius:12px;border:1px solid rgba(148,163,184,.34);padding:0 12px;font-size:14px;font-weight:700;color:#1e293b;background:#fff;" />
        </label>
        <label style="display:flex;align-items:center;gap:10px;font-size:12px;font-weight:700;color:#475569;">
          <input data-vm-skip type="checkbox" checked style="width:16px;height:16px;accent-color:#1e2a3a;" />
          Skip first filled slot
        </label>
      </div>
      <div style="display:flex;justify-content:center;gap:10px;margin-top:16px;">
        <button type="button" data-vm-close="1" style="height:38px;padding:0 14px;border-radius:12px;border:1px solid rgba(148,163,184,.28);background:#fff;color:#475569;font-size:12px;font-weight:800;cursor:pointer;">Cancel</button>
        <button type="button" data-vm-apply="1" style="height:38px;padding:0 16px;border:none;border-radius:12px;background:linear-gradient(180deg, #2f3d58, #1e2a3a);color:#fff;font-size:10px;font-weight:900;cursor:pointer;box-shadow:0 10px 20px rgba(30,42,58,.22);">Apply</button>
      </div>
    `;

    function closeCustomModal() {
      modalWrap.style.display = "none";
    }

    function openCustomModal() {
      const items = getSlotItems(modal);
      const startInput = card.querySelector('[data-vm-start]');
      const endInput = card.querySelector('[data-vm-end]');
      if (startInput) startInput.value = "2";
      if (endInput) endInput.value = String(Math.max(items.length, 10));
      modalWrap.style.display = "flex";
      setTimeout(() => startInput?.focus(), 20);
    }

    modalWrap.addEventListener("click", (event) => {
      if (event.target === modalWrap || event.target === backdrop || event.target?.dataset?.vmClose) closeCustomModal();
    });
    card.querySelector('[data-vm-apply]')?.addEventListener("click", async () => {
      const start = Number(card.querySelector('[data-vm-start]')?.value || 1);
      const end = Number(card.querySelector('[data-vm-end]')?.value || 1);
      const skipFirst = !!card.querySelector('[data-vm-skip]')?.checked;
      const rangeStart = Math.max(1, Math.min(start, end));
      const rangeEnd = Math.max(rangeStart, Math.max(start, end));
      await applyVideoMockupSelection(modal, (items) => {
        const ranged = items.slice(rangeStart - 1, rangeEnd).filter(isSlotFilled);
        return skipFirst ? ranged.slice(1) : ranged;
      });
      closeCustomModal();
    });

    bar.appendChild(label);
    buttonSpecs.forEach(({ label, picker, accent }) => {
      dock.appendChild(makeBtn(label, () => applyVideoMockupSelection(modal, picker), Boolean(accent)));
    });
    bar.appendChild(dock);
    grid.parentElement.insertBefore(bar, grid);
  }

  // Observe for the Video Mockups modal opening
  const vmModalObserver = new MutationObserver(() => {
    const modal = getVideoMockupModal();
    if (modal) injectVideoMockupBar(modal);
  });
  vmModalObserver.observe(document.body || document.documentElement, { childList: true, subtree: true });

  // ── Keyboard shortcuts + cheatsheet card ─────────────────────────────────


  maybeOpenWhatsNew();

})();



