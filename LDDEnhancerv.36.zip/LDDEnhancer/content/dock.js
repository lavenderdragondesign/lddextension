(() => {
  function getPageType() {
    const origin = window.location.origin || "";
    const path = (window.location.pathname || "").replace(/\/+$/, "");
    if (origin !== "https://mydesigns.io") return "other";
    const hasDreamerUI = Boolean(
      document.querySelector('textarea[placeholder="Enter a prompt..."]') ||
      Array.from(document.querySelectorAll('button')).some((btn) => (btn.textContent || '').includes('Start Dreaming')) ||
      Array.from(document.querySelectorAll('span,div')).some((el) => (el.textContent || '').trim() === 'Parallel Prompts')
    );
    if (hasDreamerUI) return "dreamer";

    const hasListingsUI = Boolean(
      Array.from(document.querySelectorAll('button')).some((btn) => {
        const text = (btn.textContent || '').trim().toLowerCase();
        return text === 'choose action' || text.includes('choose action');
      }) || document.getElementById('ldd-listings-toolbar-center-fixed')
    );
    if (hasListingsUI) return "listings";

    if (path === "/app/listings") return "listings";
    if (path === "/app/dreamer") return "dreamer";
    return "other";
  }

  const ROOT_ID = "ldd-clean-dock-root";
  const DOCK_ID = "ldd-clean-dock";
  const STYLE_ID = "ldd-clean-dock-style";
  const HOTSPOT_ID = "ldd-clean-dock-hotspot";
  const HOTSPOT_LEFT_ID = "ldd-clean-dock-hotspot-left";
  const HOTSPOT_RIGHT_ID = "ldd-clean-dock-hotspot-right";
  const HANDLE_ID = "ldd-clean-dock-handle";
  const TIP_ID = "ldd-clean-dock-tip";
  const SETTINGS_BUBBLE_ID = "ldd-clean-dock-settings-bubble";
  const THEME_MODAL_ID = "ldd-clean-dock-theme-modal";
  const PROMPT_MODAL_ID = "ldd-clean-dock-prompt-modal";
  const MORE_TOOLS_MODAL_ID = "ldd-clean-dock-more-tools-modal";
  const MODE_KEY = "lddDropSingleListing";
  const DOCK_AUTOHIDE_KEY = "lddDockAutohideSeconds";
  const DOCK_EFFECT_KEY = "lddDockChevronEffect";
  const DOCK_THEME_KEY = "lddDockTheme";
  const DOCK_DISABLED_KEY = "lddDockDisabled";
  const DOCK_ANIMATIONS_KEY = "lddDockAnimationsEnabled";
  const DOCK_TOOL_PREFS_KEY = "lddDockToolPrefs";
const BUBBLE_WAKE_TIP_ENABLED_KEY = "lddBubbleWakeTipEnabled";

function isWakeTipEnabled() {
  try {
    const raw = localStorage.getItem(BUBBLE_WAKE_TIP_ENABLED_KEY);
    return raw === null ? true : raw !== "false";
  } catch (e) {
    return true;
  }
}

function showDockWakeTip(targetEl, text) {
  if (!targetEl || !isWakeTipEnabled()) return;

  const existing = document.getElementById("ldd-wake-tooltip");
  if (existing) existing.remove();

  const rect = targetEl.getBoundingClientRect();
  const tip = document.createElement("div");
  tip.id = "ldd-wake-tooltip";
  tip.textContent = text;
  Object.assign(tip.style, {
    position: "fixed",
    zIndex: "2147483647",
    padding: "10px 14px",
    borderRadius: "14px",
    background: "#fff",
    color: "#1e293b",
    fontSize: "12px",
    fontWeight: "700",
    lineHeight: "1.2",
    whiteSpace: "nowrap",
    border: "1px solid rgba(15,23,42,.08)",
    boxShadow: "0 14px 36px rgba(15,23,42,.18)",
    pointerEvents: "none",
    opacity: "0",
    transform: "translateY(6px)",
    transition: "opacity .18s ease, transform .18s ease"
  });
  document.body.appendChild(tip);

  const tipRect = tip.getBoundingClientRect();
  const margin = 12;
  let left = rect.left + rect.width / 2 - tipRect.width / 2;
  let top = rect.top - tipRect.height - 12;

  if (left < margin) left = margin;
  if (left + tipRect.width > window.innerWidth - margin) left = window.innerWidth - tipRect.width - margin;
  if (top < margin) top = rect.bottom + 12;

  tip.style.left = `${left}px`;
  tip.style.top = `${top}px`;

  requestAnimationFrame(() => {
    const active = document.getElementById("ldd-wake-tooltip");
    if (!active) return;
    active.style.opacity = "1";
    active.style.transform = "translateY(0)";
  });
}

function hideDockWakeTip() {
  const node = document.getElementById("ldd-wake-tooltip");
  if (!node) return;
  node.style.opacity = "0";
  node.style.transform = "translateY(6px)";
  setTimeout(() => node.remove(), 180);
}

  function nuke() {
    document.getElementById(ROOT_ID)?.remove();
    document.getElementById(STYLE_ID)?.remove();
    document.getElementById(TIP_ID)?.remove();
    document.getElementById("ldd-dreamer-prompt-manager-btn")?.remove();
    document.getElementById("ldd-dreamer-test-modal")?.remove();
    document.getElementById(MORE_TOOLS_MODAL_ID)?.remove();
  }

  if (getPageType() === "other") {
    nuke();
    try { delete window.__LDD_CLEAN_DOCK_INSTANCE__; } catch (e) {}
    return;
  }

  if (window.__LDD_CLEAN_DOCK_INSTANCE__?.destroy) {
    try { window.__LDD_CLEAN_DOCK_INSTANCE__.destroy(); } catch (e) {}
  }

  const LOGO_URL = (() => {
    try { return chrome.runtime.getURL("assets/logo.png"); } catch (e) { return ""; }
  })();

  const ACTION_ITEMS = [
    { id: "image-mockups", label: "Image Mockups", icon: "image", action: () => triggerMenuAction("Image Mockups"), defaultSection: "main" },
    { id: "video-mockups", label: "Video Mockups", icon: "video", action: () => triggerMenuAction("Video Mockups"), defaultSection: "main" },
    { id: "vision-ai", label: "Vision AI", icon: "sparkles", action: () => triggerMenuAction("Vision AI"), defaultSection: "main" },
    { id: "remove-background", label: "Remove Background", icon: "erase", action: () => triggerMenuAction("Remove Background"), defaultSection: "main" },
    { id: "upscale", label: "Upscale", icon: "upscale", action: () => triggerMenuAction("Upscale Image"), defaultSection: "main" },
    { id: "vectorize", label: "Vectorize", icon: "shapes", action: () => triggerMenuAction("Vectorize Image"), defaultSection: "main" },
    { id: "canvas", label: "Canvas", icon: "palette", action: () => triggerMenuAction("Canvas"), defaultSection: "main" },
    { id: "dream-ai", label: "Dream AI", icon: "wand", action: () => { window.location.href = "https://mydesigns.io/app/dreamer"; }, defaultSection: "main" },
    { id: "color-overlay", label: "Color Overlay", icon: "droplets", action: () => triggerMenuAction("Color Overlay"), defaultSection: "main" },
    { id: "pattern-overlay", label: "Pattern Overlay", icon: "pattern", action: () => triggerMenuAction("Pattern Overlay"), defaultSection: "main" },
    { id: "edit-bulk", label: "Edit in Bulk", icon: "layers", action: () => triggerMenuAction("Edit in Bulk"), defaultSection: "main" },
    { id: "compressor", label: "Compressor", icon: "compressor", action: () => window.LDDCompressor?.toggle?.(), defaultSection: "main" },
    { id: "resizer", label: "Resizer", icon: "resizer", action: () => window.LDDResizer?.toggle?.(), defaultSection: "main" },
    { id: "prompt-manager", label: "Prompt Manager", icon: "files", action: () => openDockPromptModal(), defaultSection: "main" },
    { id: "download-files", label: "Download Files", icon: "download", action: () => triggerMenuAction("Download"), defaultSection: "main" },
    { id: "move-collection", label: "Move to Collection", icon: "foldermove", action: () => triggerMenuAction(["Move to Collection", "Move to collection"]), defaultSection: "main" },
    { id: "duplicate-listings", label: "Duplicate Listings", icon: "copy", action: () => triggerMenuAction(["Duplicate Listing", "Duplicate Listings"]), defaultSection: "main" },
    { id: "change-file-slot", label: "Change File Slot", icon: "swap", action: () => triggerMenuAction(["Change file slot", "Change File Slot"]), defaultSection: "main" },
    { id: "delete-listings", label: "Delete Listings", icon: "trash", action: () => triggerMenuAction(["Delete Listing", "Delete Listings"]), defaultSection: "main", className: "ldd-danger-btn" },
    { id: "pdf-gen", label: "LavenderDragonDesign's Custom Branded PDF Generator", icon: "pdf", action: () => chrome.runtime.sendMessage({ type: "ldd/openPdfGen" }), defaultSection: "main" },
  ];

  const DREAMER_ACTION_ITEMS = [
    { id: "prompt-manager", label: "Prompt Manager", icon: "files", action: () => openDockPromptModal(), defaultSection: "main" },
    { id: "listings", label: "Listings", icon: "layers", action: () => { window.location.href = "https://mydesigns.io/app/listings"; }, defaultSection: "main" },
  ];

  const DOCK_GROUPS = [
    {
      id: "ai",
      title: "Tools",
      items: ["image-mockups", "video-mockups", "vision-ai", "dream-ai", "prompt-manager", "remove-background", "upscale", "vectorize", "canvas", "color-overlay", "pattern-overlay"]
    },
    {
      id: "files",
      title: "File Tools",
      items: ["compressor", "resizer", "pdf-gen", "download-files"]
    },
    {
      id: "listing",
      title: "Listing Tools",
      items: ["edit-bulk", "move-collection", "duplicate-listings", "change-file-slot", "delete-listings"]
    }
  ];

  const DREAMER_DOCK_GROUPS = [
    {
      id: "dreamer-main",
      title: "Dream Tools",
      items: ["prompt-manager", "listings"]
    }
  ];

  function icon(name) {
    const map = {
      image:'<svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><path d="m21 15-5-5L5 21"></path></svg>',
      video:'<svg viewBox="0 0 24 24"><path d="m22 8-6 4 6 4V8Z"></path><rect x="2" y="6" width="14" height="12" rx="2"></rect></svg>',
      sparkles:'<svg viewBox="0 0 24 24"><path d="M9.937 15.5A2 2 0 0 0 8.5 14.063L6 13.5l2.5-.563A2 2 0 0 0 9.937 11.5L10.5 9l.563 2.5A2 2 0 0 0 12.5 12.937L15 13.5l-2.5.563A2 2 0 0 0 11.063 15.5L10.5 18l-.563-2.5Z"></path><path d="M20 3v4"></path><path d="M22 5h-4"></path><path d="M4 17v2"></path><path d="M5 18H3"></path></svg>',
      erase:'<svg viewBox="0 0 24 24"><path d="m7 21 9.586-9.586a2 2 0 0 0 0-2.828l-3.172-3.172a2 2 0 0 0-2.828 0L2 14v3a4 4 0 0 0 4 4Z"></path><path d="M22 21H7"></path><path d="m5 11 8 8"></path></svg>',
      upscale:'<svg viewBox="0 0 24 24"><path d="M16 3h5v5"></path><path d="m21 3-7 7"></path><path d="M8 21H3v-5"></path><path d="m3 21 7-7"></path></svg>',
      shapes:'<svg viewBox="0 0 24 24"><path d="M14.5 4.5 18 8l-3.5 3.5L11 8l3.5-3.5Z"></path><path d="M6 5h4v4H6z"></path><circle cx="7.5" cy="16.5" r="2.5"></circle><path d="M16 14h5v5h-5z"></path></svg>',
      palette:'<svg viewBox="0 0 24 24"><path d="M12 22a1 1 0 0 0 1-1v-1a2 2 0 0 1 2-2h1a4 4 0 0 0 0-8 8 8 0 1 0-8 8h1a2 2 0 0 1 2 2v1a1 1 0 0 0 1 1Z"></path><circle cx="6" cy="11" r="1"></circle><circle cx="8.5" cy="7.5" r="1"></circle><circle cx="13.5" cy="7.5" r="1"></circle><circle cx="16" cy="11" r="1"></circle></svg>',
      settings:'<svg viewBox="0 0 24 24"><path d="M12 3a2 2 0 0 1 2 2v.28a7.75 7.75 0 0 1 1.88.78l.2-.2a2 2 0 1 1 2.83 2.83l-.2.2c.34.6.61 1.24.78 1.88H19a2 2 0 1 1 0 4h-.28a7.75 7.75 0 0 1-.78 1.88l.2.2a2 2 0 1 1-2.83 2.83l-.2-.2a7.75 7.75 0 0 1-1.88.78V19a2 2 0 1 1-4 0v-.28a7.75 7.75 0 0 1-1.88-.78l-.2.2a2 2 0 1 1-2.83-2.83l.2-.2A7.75 7.75 0 0 1 5.28 13H5a2 2 0 1 1 0-4h.28c.17-.64.44-1.28.78-1.88l-.2-.2A2 2 0 1 1 8.69 4.1l.2.2c.6-.34 1.24-.61 1.88-.78V5a2 2 0 0 1 2-2Z"></path><circle cx="12" cy="12" r="3"></circle></svg>',
      upload:'<svg viewBox="0 0 24 24"><path d="M12 3v12"></path><path d="m7 8 5-5 5 5"></path><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path></svg>',
      files:'<svg viewBox="0 0 24 24"><path d="M20 7h-7a2 2 0 0 1-2-2V2"></path><path d="M9 18a2 2 0 0 0 2 2h9V7l-5-5H5a2 2 0 0 0-2 2v7"></path><path d="M3 15h6"></path><path d="M6 12v6"></path></svg>',
      wand:'<svg viewBox="0 0 24 24"><path d="M15 4V2"></path><path d="M15 16v-2"></path><path d="M8 9h2"></path><path d="M20 9h2"></path><path d="M17.8 11.8 19 13"></path><path d="M15 9h0"></path><path d="M17.8 6.2 19 5"></path><path d="m3 21-9-9"></path><path d="M12.2 6.2 11 5"></path></svg>',
      droplets:'<svg viewBox="0 0 24 24"><path d="M7 16a5 5 0 0 0 10 0c0-2.5-2.5-5.5-5-9-2.5 3.5-5 6.5-5 9Z"></path><path d="M12 2v2"></path></svg>',
      pattern:'<svg viewBox="0 0 24 24"><circle cx="7" cy="7" r="2"></circle><circle cx="17" cy="7" r="2"></circle><circle cx="7" cy="17" r="2"></circle><circle cx="17" cy="17" r="2"></circle><path d="M9 7h6"></path><path d="M7 9v6"></path><path d="M15 17h2"></path><path d="M17 15v2"></path></svg>',
      layers:'<svg viewBox="0 0 24 24"><path d="m12 3 9 4.5-9 4.5-9-4.5L12 3Z"></path><path d="m3 12 9 4.5 9-4.5"></path><path d="m3 16.5 9 4.5 9-4.5"></path></svg>',
      compressor:'<svg viewBox="0 0 24 24"><path d="M4 8h16"></path><path d="M4 16h16"></path><path d="M8 4v4"></path><path d="M16 16v4"></path><path d="M12 9v6"></path></svg>',
      resizer:'<svg viewBox="0 0 24 24"><path d="M21 3h-6"></path><path d="M21 9V3"></path><path d="m14 10 7-7"></path><path d="M3 15h6"></path><path d="M3 21v-6"></path><path d="m10 14-7 7"></path></svg>',
      download:'<svg viewBox="0 0 24 24"><path d="M12 3v12"></path><path d="m7 10 5 5 5-5"></path><path d="M5 21h14"></path></svg>',
      foldermove:'<svg viewBox="0 0 24 24"><path d="M3 7a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7z"></path><path d="M8 12h8"></path><path d="m13 9 3 3-3 3"></path></svg>',
      copy:'<svg viewBox="0 0 24 24"><rect x="9" y="9" width="13" height="13" rx="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>',
      swap:'<svg viewBox="0 0 24 24"><path d="M7 7h11"></path><path d="m13 3 5 4-5 4"></path><path d="M17 17H6"></path><path d="m11 21-5-4 5-4"></path></svg>',
      more:'<svg viewBox="0 0 24 24"><circle cx="5" cy="12" r="1.75"></circle><circle cx="12" cy="12" r="1.75"></circle><circle cx="19" cy="12" r="1.75"></circle></svg>',
      trash:'<svg viewBox="0 0 24 24"><path d="M3 6h18"></path><path d="M8 6V4h8v2"></path><path d="m19 6-1 14H6L5 6"></path><path d="M10 11v6"></path><path d="M14 11v6"></path></svg>',
      pdf:'<svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6Z"></path><path d="M14 2v6h6"></path><path d="M8 13h1.5a1.5 1.5 0 0 1 0 3H8v-3Z"></path><path d="M12 13h2"></path><path d="M12 16h2"></path><path d="M16 13v3"></path></svg>'
    };
    return map[name] || map.image;
  }

  function closeMoreToolsModal() {
    document.getElementById(MORE_TOOLS_MODAL_ID)?.remove();
  }

  async function readDockToolPrefs() {
    const stored = await getStorage({ [DOCK_TOOL_PREFS_KEY]: {} });
    return stored?.[DOCK_TOOL_PREFS_KEY] && typeof stored[DOCK_TOOL_PREFS_KEY] === "object"
      ? stored[DOCK_TOOL_PREFS_KEY]
      : {};
  }

  function getToolSection(item, prefs = {}) {
    return "main";
  }

  async function getDockActionLayout(items = ACTION_ITEMS) {
    const prefs = await readDockToolPrefs();
    return {
      prefs,
      main: items,
      more: []
    };
  }

  async function saveDockToolSection(id, section) {
    const prefs = await readDockToolPrefs();
    prefs[id] = section === "main" ? "main" : "more";
    setStorage({ [DOCK_TOOL_PREFS_KEY]: prefs });
  }

  function norm(value) {
    return (value || "").replace(/\s+/g, " ").trim().toLowerCase();
  }

  function getStorage(defaults) {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get(defaults, (result) => resolve(result || defaults));
      } catch (e) {
        resolve(defaults);
      }
    });
  }

  function setStorage(obj) {
    try { chrome.storage.local.set(obj); } catch (e) {}
  }

  async function areDockAnimationsEnabled() {
    const stored = await getStorage({ [DOCK_ANIMATIONS_KEY]: true });
    return stored[DOCK_ANIMATIONS_KEY] !== false;
  }

  function findChooseButton() {
    return Array.from(document.querySelectorAll("button")).find((button) => {
      const text = norm(button.innerText || button.textContent || "");
      return text === "choose action" || text.includes("choose action");
    }) || null;
  }

  function openChooseActionMenu() {
    const chooseButton = findChooseButton();
    if (!chooseButton) return false;
    chooseButton.click();
    return true;
  }

  function getActionButtons() {
    const labels = [
      "image mockups",
      "video mockups",
      "vision ai",
      "edit in bulk",
      "color overlay",
      "pattern overlay",
      "remove background",
      "upscale image",
      "vectorize image",
      "canvas",
      "delete listing",
      "delete listings",
      "move to collection",
      "duplicate listing",
      "duplicate listings",
      "change file slot",
      "download"
    ];

    return Array.from(document.querySelectorAll("button")).filter((button) => {
      const text = norm(button.innerText || button.textContent || "");
      if (!text || text.includes("choose action")) return false;

      const looksLikeDropdownAction =
        button.className.includes("min-w-[230px]") ||
        button.closest("li.min-w-32") ||
        button.closest("div.absolute") ||
        button.closest('div[style*="position: absolute"]');

      return looksLikeDropdownAction && labels.some((label) => text.includes(label));
    });
  }

  function clickActionButton(labels) {
    const wanted = (Array.isArray(labels) ? labels : [labels]).map((label) => norm(label));
    const buttons = getActionButtons();

    for (const button of buttons) {
      const spans = Array.from(button.querySelectorAll("span"));
      for (const span of spans) {
        if (wanted.includes(norm(span.textContent || ""))) {
          button.click();
          return true;
        }
      }
    }

    for (const button of buttons) {
      const text = norm(button.innerText || button.textContent || "");
      if (wanted.includes(text)) {
        button.click();
        return true;
      }
    }

    for (const button of buttons) {
      const text = norm(button.innerText || button.textContent || "");
      if (wanted.some((wantedLabel) => text.includes(wantedLabel))) {
        button.click();
        return true;
      }
    }

    return false;
  }

  function triggerMenuAction(labels) {
    if (!openChooseActionMenu()) return;

    let tries = 0;
    const timerId = window.setInterval(() => {
      tries += 1;
      const clicked = clickActionButton(labels);
      if (clicked || tries > 30) {
        window.clearInterval(timerId);
      }
    }, 160);
  }

  function openEnhancerSettings() {
    // Panel removed — settings bubble is the settings UI now
    const settingsBtn = document.querySelector(`#${SETTINGS_BUBBLE_ID} [data-action="open-theme-card"]`);
    if (settingsBtn) return; // bubble already open
    const anchor = document.getElementById("ldd-sidebar-bubble") || document.getElementById(HANDLE_ID);
    if (anchor) toggleDockSettingsBubble(anchor);
  }

  function closeDockSettingsBubble() {
    document.getElementById(SETTINGS_BUBBLE_ID)?.remove();
    document.getElementById("ldd-legal-flyout")?.remove();
    if (closeDockSettingsBubbleOutsideHandler) {
      document.removeEventListener("pointerdown", closeDockSettingsBubbleOutsideHandler, true);
      closeDockSettingsBubbleOutsideHandler = null;
    }
  }

  function closeDockDisableConfirm() {
    document.getElementById("ldd-dock-disable-confirm")?.remove();
  }

  function closeDockThemeModal() {
    document.getElementById(THEME_MODAL_ID)?.remove();
  }

  function closeDockPromptModal() {
    document.getElementById(PROMPT_MODAL_ID)?.remove();
  }

  async function openMoreToolsModal() {
    closeMoreToolsModal();
    const { main, more } = await getDockActionLayout(ACTION_ITEMS);

    const modal = document.createElement("div");
    modal.id = MORE_TOOLS_MODAL_ID;

    const renderToolButton = (item) => `
      <button type="button" class="ldd-more-tools-action ${item.className || ""}" data-tool-run="${item.id}">
        <span class="ldd-more-tools-icon">${icon(item.icon)}</span>
        <span class="ldd-more-tools-label">${item.label}</span>
      </button>
    `;

    const renderManageCard = (title, section, entries, hint) => `
      <div class="ldd-white-card-manage-block">
        <div class="ldd-white-card-manage-head">
          <div>
            <div class="ldd-white-card-manage-title">${title}</div>
            <div class="ldd-white-card-manage-hint">${hint}</div>
          </div>
          <div class="ldd-white-card-manage-count">${entries.length}</div>
        </div>
        <div class="ldd-white-card-manage-list">
          ${entries.map((item) => `
            <div class="ldd-white-card-tool-row">
              <div class="ldd-white-card-tool-meta">
                <span class="ldd-white-card-tool-icon">${icon(item.icon)}</span>
                <span>${item.label}</span>
              </div>
              <button type="button" class="ldd-white-card-toggle" data-tool-move="${item.id}" data-target-section="${section === "main" ? "more" : "main"}">
                ${section === "main" ? "Move to More Tools" : "Show on Main Dock"}
              </button>
            </div>
          `).join("") || `<div class="ldd-prompt-empty">Nothing here yet.</div>`}
        </div>
      </div>
    `;

    modal.innerHTML = `
      <div class="ldd-prompt-modal-backdrop" data-close-more-tools="1"></div>
      <div class="ldd-more-tools-card" role="dialog" aria-modal="true" aria-label="More Tools">
        <button type="button" class="ldd-modal-x" data-more-tools-action="close" aria-label="Close more tools">×</button>
        <div class="ldd-more-tools-shell">
          <div class="ldd-more-tools-column ldd-more-tools-library">
            <div class="ldd-prompt-eyebrow">Dock overflow</div>
            <div class="ldd-prompt-modal-title">More Tools</div>
            <div class="ldd-prompt-sidebar-copy">Utility actions live here by default, and you can promote any of them back onto the main dock.</div>
            <div class="ldd-more-tools-grid">
              ${more.map(renderToolButton).join("") || '<div class="ldd-prompt-empty">No extra tools right now. Promote some from the manager if you want.</div>'}
            </div>
          </div>
          <div class="ldd-more-tools-column ldd-white-card-manager">
            <div class="ldd-white-card-manager-head">
              <div>
                <div class="ldd-white-card-manager-title">Manage dock visibility</div>
                <div class="ldd-white-card-manager-copy">Choose what stays visible on the main dock versus tucked under More Tools.</div>
              </div>
            </div>
            ${renderManageCard("Visible on main dock", "main", main, "Best for things you use constantly.")}
            ${renderManageCard("Inside More Tools", "more", more, "Great for utility and destructive actions.")}
          </div>
        </div>
      </div>
    `;

    modal.addEventListener("click", async (event) => {
      const target = event.target;
      if (!(target instanceof HTMLElement)) return;
      const runBtn = target.closest('[data-tool-run]');
      const moveBtn = target.closest('[data-tool-move]');

      if (target.matches('[data-close-more-tools="1"]') || target.matches('[data-more-tools-action="close"]')) {
        closeMoreToolsModal();
        return;
      }

      if (runBtn instanceof HTMLElement) {
        const found = ACTION_ITEMS.find((item) => item.id === runBtn.dataset.toolRun);
        if (!found) return;
        found.action?.();
        closeMoreToolsModal();
        window.dispatchEvent(new CustomEvent("ldd-dock-action-clicked", { detail: { tipText: found.label, svgName: found.icon } }));
        return;
      }

      if (moveBtn instanceof HTMLElement) {
        await saveDockToolSection(moveBtn.dataset.toolMove, moveBtn.dataset.targetSection);
        closeMoreToolsModal();
        scheduleSync(true);
      }
    });

    document.body.appendChild(modal);
  }

  function closeDreamerTestModal() {
    document.getElementById('ldd-dreamer-test-modal')?.remove();
  }

  function openDreamerTestModal() {
    closeDreamerTestModal();
    const modal = document.createElement('div');
    modal.id = 'ldd-dreamer-test-modal';
    modal.innerHTML = `
      <div class="ldd-prompt-modal-backdrop" data-close-dreamer-test="1"></div>
      <div class="ldd-prompt-modal-card" role="dialog" aria-modal="true" aria-label="Dreamer prompt manager test">
        <button type="button" class="ldd-modal-x" data-close-dreamer-test="1" aria-label="Close test">×</button>
        <div class="ldd-prompt-modal-title">Dreamer Prompt Manager Test</div>
        <div class="ldd-prompt-empty">If you can see this, the Dream AI button click works.</div>
      </div>
    `;
    modal.addEventListener('click', (event) => {
      const target = event.target;
      if (target instanceof HTMLElement && target.matches('[data-close-dreamer-test="1"]')) {
        closeDreamerTestModal();
      }
    });
    document.body.appendChild(modal);
  }

  function uid() {
    return `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
  }

  function clipText(value, maxLen = 180) {
    const text = String(value || "").replace(/\s+/g, " ").trim();
    return text.length > maxLen ? `${text.slice(0, maxLen - 1)}…` : text;
  }

  function findCustomInstructionsTarget() {
    const selectors = [
      'textarea[placeholder*="Custom Instructions" i]',
      'textarea[placeholder*="instructions" i]',
      'textarea[placeholder*="emojis" i]',
      'textarea',
      'input[type="text"]'
    ];
    for (const selector of selectors) {
      const element = document.querySelector(selector);
      if (element && typeof element.focus === "function") return element;
    }
    return null;
  }

  function pasteToCustomInstructions(text) {
    const target = findCustomInstructionsTarget();
    if (!target || !String(text || "").trim()) return false;
    target.focus();
    target.value = String(text || "");
    target.dispatchEvent(new Event("input", { bubbles: true }));
    target.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }

  function noteOpenCustomInstructions() {
    return "Open Custom Instructions box before pasting. If it is closed, the tool will try to open it for you.";
  }

  function isDreamerPage() {
    const origin = window.location.origin || "";
    const path = (window.location.pathname || "").replace(/\/+$/, "");
    return origin === "https://mydesigns.io" && path === "/app/dreamer";
  }

  function findDreamPromptTarget() {
    const selectors = [
      'textarea[placeholder*="prompt" i]',
      'textarea[placeholder*="describe" i]',
      'textarea'
    ];
    for (const selector of selectors) {
      const element = document.querySelector(selector);
      if (element && typeof element.focus === "function") return element;
    }
    return null;
  }

  function pasteToDreamAI(text) {
    const target = findDreamPromptTarget();
    if (!target || !String(text || "").trim()) return false;
    target.focus();
    target.value = String(text || "");
    target.dispatchEvent(new Event("input", { bubbles: true }));
    target.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }

  function pullCurrentDreamPrompt() {
    const target = findDreamPromptTarget();
    return String(target?.value || "").trim();
  }

  function goToDreamAI() {
    try { window.location.href = "https://mydesigns.io/app/dreamer"; } catch (_error) {}
  }

  function goToVisionAI() {
    try { window.location.href = "https://mydesigns.io/app/listings"; } catch (_error) {}
  }

  function isVisionPage() {
    const origin = window.location.origin || "";
    const path = (window.location.pathname || "").replace(/\/+$/, "");
    return origin === "https://mydesigns.io" && path === "/app/listings";
  }

  function tryOpenVisionAIChooser() {
    if (!openChooseActionMenu()) return false;
    return triggerMenuAction("Vision AI");
  }

  function pasteToVisionAI(text) {
    if (!String(text || "").trim()) return false;
    if (!isVisionPage()) {
      sessionStorage.setItem("lddPendingVisionPaste", String(text || ""));
      goToVisionAI();
      return true;
    }
    const directOk = pasteToCustomInstructions(text);
    if (directOk) return true;
    const opened = tryOpenVisionAIChooser();
    if (!opened) {
      sessionStorage.setItem("lddPendingVisionPaste", String(text || ""));
      return false;
    }
    window.setTimeout(() => {
      pasteToCustomInstructions(text);
    }, 900);
    return true;
  }

  function queueDreamPull() {
    sessionStorage.setItem("lddPendingDreamPull", "true");
    goToDreamAI();
  }

  function queueDreamPaste(text) {
    sessionStorage.setItem("lddPendingDreamPaste", String(text || ""));
    goToDreamAI();
  }

  function flushPendingPromptActions() {
    try {
      const pendingVisionPaste = sessionStorage.getItem("lddPendingVisionPaste");
      if (pendingVisionPaste && isVisionPage()) {
        const opened = tryOpenVisionAIChooser();
        if (opened) {
          sessionStorage.removeItem("lddPendingVisionPaste");
          window.setTimeout(() => pasteToCustomInstructions(pendingVisionPaste), 900);
        }
      }

      const pendingDreamPaste = sessionStorage.getItem("lddPendingDreamPaste");
      if (pendingDreamPaste && isDreamerPage()) {
        const ok = pasteToDreamAI(pendingDreamPaste);
        if (ok) sessionStorage.removeItem("lddPendingDreamPaste");
      }

      const pendingDreamPull = sessionStorage.getItem("lddPendingDreamPull");
      if (pendingDreamPull && isDreamerPage()) {
        const pulled = pullCurrentDreamPrompt();
        if (pulled) {
          sessionStorage.removeItem("lddPendingDreamPull");
          readPromptItems().then(async (items) => {
            items.unshift({ id: uid(), name: "Pulled Dream Prompt", content: pulled, pinned: false, createdAt: Date.now(), category: "dreams" });
            await writePromptItems(items);
          });
        }
      }
    } catch (_error) {}
  }

  function showDockToast(message) {
    const existing = document.getElementById("ldd-dock-action-toast");
    if (existing) existing.remove();
    const toast = document.createElement("div");
    toast.id = "ldd-dock-action-toast";
    toast.textContent = message;
    Object.assign(toast.style, {
      position: "fixed",
      left: "50%",
      bottom: "24px",
      transform: "translateX(-50%) translateY(8px)",
      zIndex: "2147483647",
      background: "#ffffff",
      color: "#1e293b",
      border: "1px solid rgba(148,163,184,.22)",
      borderRadius: "14px",
      boxShadow: "0 16px 36px rgba(15,23,42,.18)",
      padding: "12px 16px",
      fontSize: "12px",
      fontWeight: "800",
      opacity: "0",
      transition: "opacity .18s ease, transform .18s ease"
    });
    document.body.appendChild(toast);
    requestAnimationFrame(() => {
      toast.style.opacity = "1";
      toast.style.transform = "translateX(-50%) translateY(0)";
    });
    window.setTimeout(() => {
      toast.style.opacity = "0";
      toast.style.transform = "translateX(-50%) translateY(8px)";
      window.setTimeout(() => toast.remove(), 180);
    }, 1800);
  }

  function readPromptItems() {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get({ clipboardItems: [] }, (data) => {
          const items = Array.isArray(data?.clipboardItems) ? data.clipboardItems : [];
          resolve(items.slice());
        });
      } catch (_error) {
        resolve([]);
      }
    });
  }

  function writePromptItems(items) {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.set({ clipboardItems: items }, () => resolve());
      } catch (_error) {
        resolve();
      }
    });
  }

  function normalizePromptItem(item) {
    return {
      ...item,
      category: item?.category === "dreams" ? "dreams" : "custom-instructions"
    };
  }

  async function openDockPromptModal() {
    closeDockPromptModal();
    let items = (await readPromptItems()).map(normalizePromptItem);
    let query = "";
    let editingId = null;
    let activeCategory = isDreamerPage() ? "dreams" : "all";
    const onDreamPage = isDreamerPage();
    const onVisionPage = isVisionPage();

    const renderDisabledCard = (message) => `
      <div class="ldd-prompt-empty ldd-prompt-disabled-card">
        ${message}
      </div>
    `;

    const renderTooltipDisabledButton = (label, message, attrs = "") => `
      <span class="ldd-disabled-tooltip-wrap" data-disabled-tip="${String(message || "").replace(/"/g, '&quot;')}">
        <button type="button" ${attrs} disabled>${label}</button>
      </span>
    `;

    const modal = document.createElement("div");
    modal.id = PROMPT_MODAL_ID;
    modal.innerHTML = `
      <div class="ldd-prompt-modal-backdrop" data-close-prompt="1"></div>
      <div class="ldd-prompt-modal-card" role="dialog" aria-modal="true" aria-label="Prompt manager">
        <button type="button" class="ldd-modal-x" data-prompt-action="close" aria-label="Close prompt manager">×</button>
        <div class="ldd-prompt-shell">
          <aside class="ldd-prompt-sidebar">
            <div>
              <div class="ldd-prompt-eyebrow">Shared library</div>
              <div class="ldd-prompt-modal-title">Prompt Manager</div>
              <div class="ldd-prompt-sidebar-copy">Save, search, pin, and quickly paste Custom Instructions or Dream prompts from one place.</div>
            </div>
            <div class="ldd-prompt-sidebar-actions">
              <button type="button" class="ldd-prompt-toolbar-btn ldd-prompt-primary-btn" data-prompt-action="new-custom">New Custom Instruction</button>
              <button type="button" class="ldd-prompt-toolbar-btn" data-prompt-action="new-dream">New Dream</button>
              ${onDreamPage
                ? '<button type="button" class="ldd-prompt-toolbar-btn" data-prompt-action="pull-dream">Pull Current Dream Prompt</button>'
                : `<span class="ldd-disabled-tooltip-wrap" data-disabled-tip="Open Dream AI to pull prompts."><button type="button" class="ldd-prompt-toolbar-btn" data-prompt-action="pull-dream" disabled>Pull Current Dream Prompt</button></span>`}
            </div>
            <div class="ldd-prompt-sidebar-tabs">
              <button type="button" class="ldd-prompt-filter-btn active" data-prompt-filter="all">All prompts</button>
              <button type="button" class="ldd-prompt-filter-btn" data-prompt-filter="custom-instructions">Custom Instructions</button>
              <button type="button" class="ldd-prompt-filter-btn" data-prompt-filter="dreams">Dream prompts</button>
            </div>
          </aside>
          <div class="ldd-prompt-mainpanel">
            <div class="ldd-prompt-toolbar">
              <input type="text" id="ldd-dock-prompt-search" class="ldd-prompt-search" placeholder="Search prompts..." />
              <div class="ldd-prompt-toolbar-meta" id="ldd-dock-prompt-stats"></div>
            </div>
            <div class="ldd-prompt-list" id="ldd-dock-prompt-list"></div>
          </div>
        </div>
        <div class="ldd-prompt-modal-actions">
          <button type="button" class="ldd-prompt-secondary-btn" data-prompt-action="close">Close</button>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    const searchEl = modal.querySelector("#ldd-dock-prompt-search");
    const listEl = modal.querySelector("#ldd-dock-prompt-list");
    const statsEl = modal.querySelector("#ldd-dock-prompt-stats");

    const filteredItems = () => {
      const q = query.trim().toLowerCase();
      return items
        .slice()
        .sort((a, b) => Number(b?.pinned || false) - Number(a?.pinned || false) || Number(b?.createdAt || 0) - Number(a?.createdAt || 0))
        .filter((item) => {
          if (activeCategory !== "all" && item.category !== activeCategory) return false;
          if (!q) return true;
          return String(item?.name || "").toLowerCase().includes(q) || String(item?.content || "").toLowerCase().includes(q);
        });
    };

    const renderSection = (sectionTitle, sectionItems, category) => {
      const dreamActionsDisabled = category === "dreams" && !onDreamPage;
      const visionActionsDisabled = category === "custom-instructions" && !onVisionPage;
      const actionsDisabled = dreamActionsDisabled || visionActionsDisabled;
      const disabledMessage = dreamActionsDisabled
        ? "Open Dream AI to add or paste Dream prompts."
        : (visionActionsDisabled ? "Open Listings → Vision AI to add or paste Custom Instructions." : noteOpenCustomInstructions());
      if (!sectionItems.length) {
        const empty = category === "dreams"
          ? '<div class="ldd-prompt-empty">No saved Dream prompts yet.</div>'
          : '<div class="ldd-prompt-empty">No saved Custom Instructions yet.</div>';
        return `
          <section class="ldd-prompt-section">
            <div class="ldd-prompt-section-head">
              <div class="ldd-prompt-section-title">${sectionTitle}</div>
              ${category === "dreams" ? `<div class="ldd-prompt-dream-tools"><img src="${LOGO_URL}" alt="LDD" class="ldd-prompt-mini-logo" />${onDreamPage ? '<button type="button" class="ldd-prompt-toolbar-btn" data-prompt-action="pull-dream">Pull Current Dream Prompt</button>' : renderTooltipDisabledButton('Pull Current Dream Prompt', 'Open Dream AI to pull prompts.', 'class="ldd-prompt-toolbar-btn" data-prompt-action="pull-dream"')}</div>` : ""}
            </div>
            ${actionsDisabled ? renderDisabledCard(disabledMessage) : ""}
            ${empty}
          </section>
        `;
      }

      return `
        <section class="ldd-prompt-section">
          <div class="ldd-prompt-section-head">
            <div class="ldd-prompt-section-title">${sectionTitle}</div>
            ${category === "dreams" ? `<div class="ldd-prompt-dream-tools"><img src="${LOGO_URL}" alt="LDD" class="ldd-prompt-mini-logo" />${onDreamPage ? '<button type="button" class="ldd-prompt-toolbar-btn" data-prompt-action="pull-dream">Pull Current Dream Prompt</button>' : renderTooltipDisabledButton('Pull Current Dream Prompt', 'Open Dream AI to pull prompts.', 'class="ldd-prompt-toolbar-btn" data-prompt-action="pull-dream"')}</div>` : ""}
          </div>
          ${actionsDisabled ? renderDisabledCard(disabledMessage) : ""}
          <div class="ldd-prompt-section-list">
            ${sectionItems.map((item) => {
              const pasteLabel = category === "dreams" ? "Paste to Dream AI" : "Paste to Custom Instructions";
              if (item.id === editingId) {
                return `
                  <div class="ldd-prompt-card editing" data-id="${item.id}">
                    <div class="ldd-prompt-editor">
                      <input type="text" class="ldd-prompt-editor-name" data-edit-field="name" data-id="${item.id}" value="${String(item?.name || "").replace(/"/g, '&quot;')}" placeholder="Prompt name" />
                      <textarea class="ldd-prompt-editor-content" data-edit-field="content" data-id="${item.id}" placeholder="Prompt content">${String(item?.content || "")}</textarea>
                      <div class="ldd-prompt-card-actions">
                        <button type="button" data-prompt-item-action="save" data-id="${item.id}">Save</button>
                        <button type="button" data-prompt-item-action="cancel" data-id="${item.id}">Cancel</button>
                        ${renderTooltipDisabledButton(pasteLabel, 'Hit Save before pasting', `data-prompt-item-action="paste" data-id="${item.id}"`)}
                        <button type="button" data-prompt-item-action="delete" data-id="${item.id}">Delete</button>
                      </div>
                    </div>
                  </div>
                `;
              }
              return `
                  <div class="ldd-prompt-card ${item?.pinned ? "pinned" : ""}" data-id="${item.id}">
                    <div class="ldd-prompt-card-top">
                      <div class="ldd-prompt-card-name">${clipText(item?.name || "Untitled", 48)}</div>
                      <div class="ldd-prompt-card-preview">${clipText(item?.content || "", 180)}</div>
                    </div>
                    <div class="ldd-prompt-card-actions">
                      <button type="button" data-prompt-item-action="edit" data-id="${item.id}">Edit</button>
                      <button type="button" data-prompt-item-action="copy" data-id="${item.id}">Copy</button>
                      ${actionsDisabled
                        ? renderTooltipDisabledButton(pasteLabel, disabledMessage, `data-prompt-item-action="paste" data-id="${item.id}"`)
                        : `<button type="button" data-prompt-item-action="paste" data-id="${item.id}">${pasteLabel}</button>`}
                      <button type="button" data-prompt-item-action="pin" data-id="${item.id}">${item?.pinned ? "Unpin" : "Pin"}</button>
                      <button type="button" data-prompt-item-action="delete" data-id="${item.id}">Delete</button>
                    </div>
                </div>
              `;
            }).join("")}
          </div>
        </section>
      `;
    };

    const renderList = () => {
      if (!listEl) return;
      const visible = filteredItems();
      const customCount = items.filter((item) => item.category !== "dreams").length;
      const dreamCount = items.filter((item) => item.category === "dreams").length;
      if (statsEl) statsEl.textContent = `${visible.length} shown • ${customCount} custom • ${dreamCount} dreams`;
      modal.querySelectorAll('.ldd-prompt-filter-btn').forEach((btn) => btn.classList.toggle('active', btn.dataset.promptFilter === activeCategory));
      if (!visible.length) {
        listEl.innerHTML = '<div class="ldd-prompt-empty">No saved prompts yet.</div>';
        return;
      }
      const customItems = visible.filter((item) => item.category !== "dreams");
      const dreamItems = visible.filter((item) => item.category === "dreams");

      listEl.innerHTML = [
        renderSection("Saved Custom Instructions", customItems, "custom-instructions"),
        renderSection("Saved Dreams", dreamItems, "dreams")
      ].join("");
    };

    modal.addEventListener("click", async (event) => {
      const target = event.target;
      if (!(target instanceof HTMLElement)) return;

      if (target.matches('[data-close-prompt="1"]') || target.matches('[data-prompt-action="close"]')) {
        closeDockPromptModal();
        return;
      }

      if (target.matches('[data-prompt-action="new-custom"]')) {
        items.unshift({ id: uid(), name: "New Custom Instruction", content: "", pinned: false, createdAt: Date.now(), category: "custom-instructions" });
        await writePromptItems(items);
        editingId = items[0]?.id || null;
        renderList();
        return;
      }

      if (target.matches('[data-prompt-action="new-dream"]')) {
        items.unshift({ id: uid(), name: "New Dream Prompt", content: "", pinned: false, createdAt: Date.now(), category: "dreams" });
        await writePromptItems(items);
        editingId = items[0]?.id || null;
        renderList();
        return;
      }

      if (target.matches('[data-prompt-action="pull-dream"]')) {
        if (!isDreamerPage()) {
          queueDreamPull();
          closeDockPromptModal();
          return;
        }
        const pulled = pullCurrentDreamPrompt();
        if (!pulled) return;
        items.unshift({ id: uid(), name: "Pulled Dream Prompt", content: pulled, pinned: false, createdAt: Date.now(), category: "dreams" });
        await writePromptItems(items);
        activeCategory = "dreams";
        showDockToast("Dream prompt pulled.");
        closeDockPromptModal();
        return;
      }

      if (target.matches('[data-prompt-filter]')) {
        activeCategory = target.dataset.promptFilter || 'all';
        renderList();
        return;
      }

      if (target.matches('[data-prompt-item-action="edit"]')) {
        editingId = target.dataset.id || null;
        renderList();
        return;
      }

      if (target.matches('[data-prompt-item-action="cancel"]')) {
        editingId = null;
        renderList();
        return;
      }

      if (target.matches('[data-prompt-item-action="save"]')) {
        const id = target.dataset.id;
        const card = modal.querySelector(`.ldd-prompt-card.editing[data-id="${id}"]`);
        const nameEl = card?.querySelector('[data-edit-field="name"]');
        const contentEl = card?.querySelector('[data-edit-field="content"]');
        items = items.map((item) => item.id === id ? {
          ...item,
          name: String(nameEl?.value || "Untitled").trim() || "Untitled",
          content: String(contentEl?.value || "")
        } : item);
        await writePromptItems(items);
        editingId = null;
        renderList();
        return;
      }

      if (target.matches('[data-prompt-item-action="copy"]')) {
        const found = items.find((item) => item.id === target.dataset.id);
        if (!found) return;
        try { await navigator.clipboard.writeText(String(found.content || "")); } catch (_error) {}
        return;
      }

      if (target.matches('[data-prompt-item-action="paste"]')) {
        const found = items.find((item) => item.id === target.dataset.id);
        if (!found) return;
        if (found.category === "dreams") {
          if (!isDreamerPage()) {
            queueDreamPaste(found.content || "");
            closeDockPromptModal();
            return;
          }
          const ok = pasteToDreamAI(found.content || "");
          if (ok) {
            showDockToast("Pasted to Dream AI.");
            closeDockPromptModal();
          }
        } else {
          const ok = pasteToVisionAI(found.content || "");
          if (ok) {
            showDockToast("Pasted to Custom Instructions.");
            closeDockPromptModal();
          }
        }
        return;
      }

      if (target.matches('[data-prompt-item-action="pin"]')) {
        items = items.map((item) => item.id === target.dataset.id ? { ...item, pinned: !item.pinned } : item);
        await writePromptItems(items);
        renderList();
        return;
      }

      if (target.matches('[data-prompt-item-action="delete"]')) {
        items = items.filter((item) => item.id !== target.dataset.id);
        if (editingId === target.dataset.id) editingId = null;
        await writePromptItems(items);
        renderList();
      }
    });

    searchEl?.addEventListener("input", (event) => {
      query = String(event.target.value || "");
      renderList();
    });

    renderList();
  }

  window.LDDSharedPromptManager = window.LDDSharedPromptManager || {};
  window.LDDSharedPromptManager.open = () => openDockPromptModal();

  flushPendingPromptActions();

  async function openDockThemeModal() {
    closeDockThemeModal();
    const theme = await getStorage({
      globalThemeEnabled: false,
      globalThemeMode: "gradient",
      globalThemeSolidColor: "#1f4ed8",
      globalThemeGradientColor: "#7c3aed",
      globalThemeBrightness: 100
    });

    const modal = document.createElement("div");
    modal.id = THEME_MODAL_ID;
    modal.innerHTML = `
      <div class="ldd-theme-modal-backdrop" data-close-theme="1"></div>
      <div class="ldd-theme-modal-card" role="dialog" aria-modal="true" aria-label="Theme settings">
        <button type="button" class="ldd-modal-x" data-theme-action="close" aria-label="Close theme settings">×</button>
        <div class="ldd-theme-modal-title">Theme</div>
        <div class="ldd-theme-modal-stack">
          <span>Mode</span>
          <div class="ldd-theme-mode-group">
            <button type="button" class="ldd-theme-mode-btn ${theme.globalThemeMode === "solid" ? "active" : ""}" data-theme-mode="solid">Solid</button>
            <button type="button" class="ldd-theme-mode-btn ${theme.globalThemeMode !== "solid" ? "active" : ""}" data-theme-mode="gradient">Gradient</button>
          </div>
        </div>
        <label class="ldd-theme-modal-stack">
          <span>Primary Color</span>
          <input type="color" id="ldd-dock-theme-solid" value="${theme.globalThemeSolidColor || "#1f4ed8"}" />
        </label>
        <label class="ldd-theme-modal-stack">
          <span>Secondary Color</span>
          <input type="color" id="ldd-dock-theme-gradient" value="${theme.globalThemeGradientColor || "#7c3aed"}" />
        </label>
        <label class="ldd-theme-modal-stack">
          <span>Brightness <strong id="ldd-dock-theme-brightness-value">${Number(theme.globalThemeBrightness) || 100}%</strong></span>
          <input type="range" id="ldd-dock-theme-brightness" min="70" max="130" step="1" value="${Number(theme.globalThemeBrightness) || 100}" />
        </label>
        <div class="ldd-theme-modal-stack">
          <span>Presets</span>
          <div class="ldd-theme-presets-grid">
            <button type="button" class="ldd-theme-preset-btn" data-preset-solid="#1f4ed8" data-preset-gradient="#7c3aed" data-preset-mode="gradient" data-preset-brightness="100">Blue Purple</button>
            <button type="button" class="ldd-theme-preset-btn" data-preset-solid="#0f766e" data-preset-gradient="#14b8a6" data-preset-mode="gradient" data-preset-brightness="100">Teal Mint</button>
            <button type="button" class="ldd-theme-preset-btn" data-preset-solid="#ea580c" data-preset-gradient="#f59e0b" data-preset-mode="gradient" data-preset-brightness="100">Sunset</button>
            <button type="button" class="ldd-theme-preset-btn" data-preset-solid="#be185d" data-preset-gradient="#f472b6" data-preset-mode="gradient" data-preset-brightness="100">Rose Pop</button>
            <button type="button" class="ldd-theme-preset-btn" data-preset-solid="#111827" data-preset-gradient="#374151" data-preset-mode="solid" data-preset-brightness="100">Graphite</button>
            <button type="button" class="ldd-theme-preset-btn" data-preset-solid="#166534" data-preset-gradient="#22c55e" data-preset-mode="gradient" data-preset-brightness="100">Forest</button>
          </div>
        </div>
        <div class="ldd-theme-modal-preview-wrap">
          <span>Preview</span>
          <div class="ldd-theme-modal-preview" id="ldd-dock-theme-preview"></div>
        </div>
        <div class="ldd-theme-modal-actions">
          <button type="button" class="ldd-theme-primary-btn" data-theme-action="enable">${theme.globalThemeEnabled ? "Theme Enabled" : "Enable Theme"}</button>
          <button type="button" class="ldd-theme-secondary-btn" data-theme-action="off">Off</button>
          <button type="button" class="ldd-theme-secondary-btn" data-theme-action="reset">Reset</button>
          <button type="button" class="ldd-theme-secondary-btn" data-theme-action="close">Close</button>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    const solidEl = modal.querySelector("#ldd-dock-theme-solid");
    const gradientEl = modal.querySelector("#ldd-dock-theme-gradient");
    const brightnessEl = modal.querySelector("#ldd-dock-theme-brightness");
    const brightnessValueEl = modal.querySelector("#ldd-dock-theme-brightness-value");
    const previewEl = modal.querySelector("#ldd-dock-theme-preview");
    const enableBtn = modal.querySelector('[data-theme-action="enable"]');
    let themeEnabled = Boolean(theme.globalThemeEnabled);

    const refreshPreview = () => {
      if (!previewEl || !solidEl || !gradientEl || !brightnessEl) return;
      const mode = modal.querySelector(".ldd-theme-mode-btn.active")?.dataset?.themeMode || "gradient";
      const solid = solidEl.value || "#1f4ed8";
      const gradient = gradientEl.value || "#7c3aed";
      const brightness = Number(brightnessEl.value) || 100;
      if (brightnessValueEl) brightnessValueEl.textContent = `${brightness}%`;
      if (enableBtn) enableBtn.textContent = themeEnabled ? "Theme Enabled" : "Enable Theme";
      previewEl.style.background = mode === "solid" ? solid : `linear-gradient(135deg, ${solid}, ${gradient})`;
      previewEl.style.filter = `brightness(${brightness}%)`;
      gradientEl.disabled = mode === "solid";
      gradientEl.style.opacity = mode === "solid" ? ".55" : "1";
    };

    const persistTheme = () => {
      const mode = modal.querySelector(".ldd-theme-mode-btn.active")?.dataset?.themeMode || "gradient";
      setStorage({
        globalThemeEnabled: themeEnabled,
        globalThemeMode: mode,
        globalThemeSolidColor: solidEl?.value || "#1f4ed8",
        globalThemeGradientColor: gradientEl?.value || "#7c3aed",
        globalThemeBrightness: Number(brightnessEl?.value) || 100
      });
    };

    modal.addEventListener("click", (event) => {
      const target = event.target;
      if (!(target instanceof HTMLElement)) return;
      if (target.matches('[data-close-theme="1"]') || target.matches('[data-theme-action="close"]')) {
        closeDockThemeModal();
        return;
      }
      if (target.matches('[data-theme-action="enable"]')) {
        themeEnabled = true;
        refreshPreview();
        persistTheme();
        return;
      }
      if (target.matches('[data-theme-action="off"]')) {
        themeEnabled = false;
        refreshPreview();
        persistTheme();
        return;
      }
      if (target.matches('[data-theme-action="reset"]')) {
        themeEnabled = false;
        if (solidEl) solidEl.value = '#1f4ed8';
        if (gradientEl) gradientEl.value = '#7c3aed';
        if (brightnessEl) brightnessEl.value = '100';
        modal.querySelectorAll('.ldd-theme-mode-btn').forEach((btn) => btn.classList.toggle('active', btn.dataset.themeMode === 'gradient'));
        refreshPreview();
        persistTheme();
        return;
      }
      if (target.matches('.ldd-theme-preset-btn')) {
        const mode = target.dataset.presetMode || 'gradient';
        const solid = target.dataset.presetSolid || '#1f4ed8';
        const gradient = target.dataset.presetGradient || '#7c3aed';
        const brightness = Number(target.dataset.presetBrightness) || 100;
        if (solidEl) solidEl.value = solid;
        if (gradientEl) gradientEl.value = gradient;
        if (brightnessEl) brightnessEl.value = String(brightness);
        modal.querySelectorAll('.ldd-theme-mode-btn').forEach((btn) => btn.classList.toggle('active', btn.dataset.themeMode === mode));
        refreshPreview();
        persistTheme();
        return;
      }
      if (target.matches('.ldd-theme-mode-btn')) {
        modal.querySelectorAll('.ldd-theme-mode-btn').forEach((btn) => btn.classList.toggle('active', btn === target));
        refreshPreview();
        persistTheme();
      }
    });

    [solidEl, gradientEl, brightnessEl].forEach((el) => {
      el?.addEventListener("input", () => {
        refreshPreview();
        persistTheme();
      });
      el?.addEventListener("change", () => {
        refreshPreview();
        persistTheme();
      });
    });

    refreshPreview();
  }

  function showDockDisableConfirm(onConfirm) {
    closeDockDisableConfirm();
    const wrap = document.createElement("div");
    wrap.id = "ldd-dock-disable-confirm";
    wrap.innerHTML = `
      <div class="ldd-white-card-backdrop"></div>
      <div class="ldd-white-card-popup" role="dialog" aria-modal="true" aria-label="Disable dock confirmation">
        <div class="ldd-white-card-title">Hide dock?</div>
        <div class="ldd-white-card-body">
          If you turn the dock off, you’ll need to re-enable it from the Chrome toolbar extension icon and open settings there.
        </div>
        <div class="ldd-white-card-actions">
          <button type="button" class="ldd-white-card-btn ldd-white-card-btn-secondary" data-action="cancel">Cancel</button>
          <button type="button" class="ldd-white-card-btn ldd-white-card-btn-danger" data-action="confirm">Yes, hide dock</button>
        </div>
      </div>
    `;

    wrap.addEventListener("click", (event) => {
      const target = event.target;
      if (!(target instanceof HTMLElement)) return;
      if (target.matches(".ldd-white-card-backdrop") || target.matches('[data-action="cancel"]')) {
        closeDockDisableConfirm();
        return;
      }
      if (target.matches('[data-action="confirm"]')) {
        closeDockDisableConfirm();
        onConfirm?.();
      }
    });

    document.body.appendChild(wrap);
  }

  let closeDockSettingsBubbleOutsideHandler = null;

  async function toggleDockSettingsBubble(anchorEl) {
    const existing = document.getElementById(SETTINGS_BUBBLE_ID);
    if (existing) {
      closeDockSettingsBubble();
      return;
    }

    const state = await getStorage({
      enhancerEnabled: true,
      dropperEnabled: true,
      dndAutoRename: true,
      cardActionsEnabled: true,
      visionAIAutoEnableCI: true,
      qaTooltipsEnabled: true,
      [DOCK_ANIMATIONS_KEY]: true,
      [DOCK_DISABLED_KEY]: false,
      [DOCK_AUTOHIDE_KEY]: 60,
      [DOCK_THEME_KEY]: "glass-light"
    });

    const bubble = document.createElement("div");
    bubble.id = SETTINGS_BUBBLE_ID;
    bubble.innerHTML = `
      <div class="ldd-settings-bubble-card">
        <div class="ldd-settings-bubble-title">Enhancer Settings</div>
        <label class="ldd-settings-bubble-row">
          <span>MD Enhancer</span>
          <input type="checkbox" data-setting="enhancerEnabled" ${state.enhancerEnabled !== false ? "checked" : ""} />
        </label>
        <label class="ldd-settings-bubble-row">
          <span>Dock enabled</span>
          <input type="checkbox" data-setting="dockEnabled" ${state[DOCK_DISABLED_KEY] ? "" : "checked"} />
        </label>
        <label class="ldd-settings-bubble-row">
          <span>Drag & Drop Upload</span>
          <input type="checkbox" data-setting="dropperEnabled" ${state.dropperEnabled !== false ? "checked" : ""} />
        </label>
        <label class="ldd-settings-bubble-row">
          <span>Auto Rename</span>
          <input type="checkbox" data-setting="dndAutoRename" ${state.dndAutoRename !== false ? "checked" : ""} />
        </label>
        <label class="ldd-settings-bubble-row">
          <span>Card Quick Actions</span>
          <input type="checkbox" data-setting="cardActionsEnabled" ${state.cardActionsEnabled !== false ? "checked" : ""} />
        </label>
        <label class="ldd-settings-bubble-row">
          <span>QA Tooltips</span>
          <input type="checkbox" data-setting="qaTooltipsEnabled" ${state.qaTooltipsEnabled !== false ? "checked" : ""} />
        </label>
        <label class="ldd-settings-bubble-row">
          <span>Auto-enable CI in Vision AI</span>
          <input type="checkbox" data-setting="visionAIAutoEnableCI" ${state.visionAIAutoEnableCI !== false ? "checked" : ""} />
        </label>
        <label class="ldd-settings-bubble-row">
          <span>Wake tooltips</span>
          <input type="checkbox" data-setting="wakeTooltips" ${isWakeTipEnabled() ? "checked" : ""} />
        </label>
        <label class="ldd-settings-bubble-row">
          <span>Dock animations</span>
          <input type="checkbox" data-setting="dockAnimations" ${state[DOCK_ANIMATIONS_KEY] !== false ? "checked" : ""} />
        </label>
        <label class="ldd-settings-bubble-stack">
          <span>Hide delay</span>
          <select data-setting="autohide">
            <option value="0">Off</option>
            <option value="5">5 sec</option>
            <option value="30">30 sec</option>
            <option value="1">1 sec</option>
            <option value="60">1 min</option>
            <option value="120">2 min</option>
            <option value="3">3 sec</option>
            <option value="8">8 sec</option>
            <option value="10">10 sec</option>
            <option value="15">15 sec</option>
            <option value="20">20 sec</option>
          </select>
        </label>
        <label class="ldd-settings-bubble-stack">
          <span>Dock theme</span>
          <select data-setting="theme">
            <option value="glass-light">Glass Light</option>
            <option value="glass-dark">Glass Dark</option>
            <option value="midnight">Midnight</option>
            <option value="sunset">Sunset</option>
            <option value="rainbow">Rainbow</option>
            <option value="neon-pink">Neon Pink</option>
          </select>
        </label>
        <button type="button" class="ldd-settings-bubble-link" data-action="open-theme-card">MD UI Theme Settings</button>
        <button type="button" class="ldd-settings-bubble-link ldd-settings-bubble-link--muted" data-action="open-legal">⚖️ Legal &amp; Privacy</button>
      </div>
    `;

    document.body.appendChild(bubble);

    const autohideSelect = bubble.querySelector('[data-setting="autohide"]');
    const themeSelect = bubble.querySelector('[data-setting="theme"]');
    if (autohideSelect) autohideSelect.value = String(state[DOCK_AUTOHIDE_KEY] ?? 10);
    if (themeSelect) themeSelect.value = String(state[DOCK_THEME_KEY] || "glass-light");

    const rect = anchorEl.getBoundingClientRect();
    const bubbleRect = bubble.getBoundingClientRect();
    const margin = 12;
    let left = rect.left + rect.width / 2 - bubbleRect.width / 2;
    let top = rect.top - bubbleRect.height - 14;
    if (left < margin) left = margin;
    if (left + bubbleRect.width > window.innerWidth - margin) left = window.innerWidth - bubbleRect.width - margin;
    if (top < margin) top = rect.bottom + 14;
    bubble.style.left = `${left}px`;
    bubble.style.top = `${top}px`;
    const anchorCenter = rect.left + rect.width / 2;
    const arrowLeft = Math.max(22, Math.min(bubbleRect.width - 22, anchorCenter - left));
    bubble.style.setProperty('--ldd-bubble-arrow-left', `${arrowLeft}px`);
    bubble.style.setProperty('--ldd-bubble-origin', `${arrowLeft}px bottom`);

    bubble.addEventListener("click", async (event) => {
      event.stopPropagation();
      const target = event.target;
      if (!(target instanceof HTMLElement)) return;

      if (target.matches('[data-action="open-legal"]')) {
        const existing = document.getElementById("ldd-legal-flyout");
        if (existing) { existing.remove(); target.innerHTML = "⚖️ Legal &amp; Privacy"; return; }

        const flyout = document.createElement("div");
        flyout.id = "ldd-legal-flyout";
        flyout.innerHTML = `
          <div class="ldd-legal-flyout-title">⚖️ Legal &amp; Privacy</div>
          <div class="ldd-legal-entry"><strong>🔒 Privacy Policy</strong><p>LDD MD Enhancer does not collect, transmit, or store any personal data on external servers. All data — clipboard items, theme preferences, and settings — is stored exclusively in <code>chrome.storage.local</code> and never leaves your device. No analytics, tracking, or third-party data services are used.</p></div>
          <div class="ldd-legal-entry"><strong>🚫 Data Collection</strong><p>This extension collects <strong>no user data whatsoever</strong>. No browsing history, keystrokes, form inputs, identifiers, or usage metrics. No cookies, no telemetry, no network calls to any external service.</p></div>
          <div class="ldd-legal-entry"><strong>⚠️ Liability Disclaimer</strong><p>Provided "as is" without warranty of any kind. LavenderDragonDesign shall not be liable for any damages arising from the use or inability to use this extension. Use is entirely at your own risk.</p></div>
          <div class="ldd-legal-entry"><strong>™ Trademarks &amp; Copyrights</strong><p><strong>MyDesigns®</strong> is a registered trademark of its respective owner. This extension is independent and not affiliated with or endorsed by MyDesigns. The LDD Enhancer is Copyright © LavenderDragonDesign. All rights reserved.</p></div>
        `;
        document.body.appendChild(flyout);

        // Position: align top with bubble, to the left of it
        const bubbleRect = bubble.getBoundingClientRect();
        const flyoutW = 260;
        const margin = 10;
        flyout.style.width = flyoutW + "px";
        flyout.style.top = bubbleRect.top + "px";
        // place left of bubble, fall back to right if no room
        const leftPos = bubbleRect.left - flyoutW - margin;
        flyout.style.left = (leftPos >= margin ? leftPos : bubbleRect.right + margin) + "px";
        // clamp vertically so it doesn't go off screen
        const flyoutH = flyout.offsetHeight;
        const maxTop = window.innerHeight - flyoutH - margin;
        if (parseFloat(flyout.style.top) > maxTop) flyout.style.top = Math.max(margin, maxTop) + "px";

        target.innerHTML = "⚖️ Legal &amp; Privacy ✕";
        return;
      }

      if (target.matches('[data-action="open-theme-card"]')) {
        openDockThemeModal();
        return;
      }

    });

    bubble.addEventListener("change", (event) => {
      event.stopPropagation();
      const target = event.target;
      if (!(target instanceof HTMLElement)) return;

      if (target.matches('[data-setting="dockEnabled"]')) {
        if (!target.checked) {
          target.checked = true;
          showDockDisableConfirm(() => {
            setStorage({ [DOCK_DISABLED_KEY]: true });
            closeDockSettingsBubble();
          });
          return;
        }
        setStorage({ [DOCK_DISABLED_KEY]: false });
        return;
      }

      if (target.matches('[data-setting="enhancerEnabled"]')) {
        setStorage({ enhancerEnabled: target.checked });
        return;
      }

      if (target.matches('[data-setting="dropperEnabled"]')) {
        setStorage({ dropperEnabled: target.checked });
        return;
      }

      if (target.matches('[data-setting="dndAutoRename"]')) {
        setStorage({ dndAutoRename: target.checked });
        return;
      }

      if (target.matches('[data-setting="cardActionsEnabled"]')) {
        setStorage({ cardActionsEnabled: target.checked });
        window.dispatchEvent(new CustomEvent("ldd-card-actions-toggle", { detail: { enabled: target.checked } }));
        return;
      }

      if (target.matches('[data-setting="qaTooltipsEnabled"]')) {
        setStorage({ qaTooltipsEnabled: target.checked });
        return;
      }

      if (target.matches('[data-setting="visionAIAutoEnableCI"]')) {
        setStorage({ visionAIAutoEnableCI: target.checked });
        return;
      }

      if (target.matches('[data-setting="wakeTooltips"]')) {
        try {
          localStorage.setItem(BUBBLE_WAKE_TIP_ENABLED_KEY, target.checked ? "true" : "false");
        } catch (e) {}
        return;
      }

      if (target.matches('[data-setting="dockAnimations"]')) {
        setStorage({ [DOCK_ANIMATIONS_KEY]: target.checked });
        return;
      }

      if (target.matches('[data-setting="autohide"]')) {
        setStorage({ [DOCK_AUTOHIDE_KEY]: Number(target.value) || 0 });
      }

      if (target.matches('[data-setting="theme"]')) {
        setStorage({ [DOCK_THEME_KEY]: String(target.value || "glass-light") });
      }
    });

    requestAnimationFrame(() => bubble.classList.add("show"));

    closeDockSettingsBubbleOutsideHandler = (event) => {
      const target = event.target;
      if (!(target instanceof Node)) return;
      const legalFlyout = document.getElementById("ldd-legal-flyout");
      if (bubble.contains(target) || anchorEl.contains(target) || legalFlyout?.contains(target)) return;
      closeDockSettingsBubble();
    };

    document.addEventListener("pointerdown", closeDockSettingsBubbleOutsideHandler, true);
  }

  function injectStyle() {
    document.getElementById(STYLE_ID)?.remove();
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      #${ROOT_ID}{
        position:fixed;
        left:0;
        right:0;
        bottom:0;
        z-index:999999;
        pointer-events:none;
        font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,sans-serif;
      }
      #${HOTSPOT_ID}{
        position:fixed;
        left:0;
        right:0;
        bottom:0;
        height:44px;
        z-index:999999;
        pointer-events:none;
        background:transparent;
      }
      #${HOTSPOT_ID} .ldd-hotspot-corner{
        position:absolute;
        bottom:0;
        width:92px;
        height:44px;
        pointer-events:auto;
        background:transparent;
      }
      #${HOTSPOT_LEFT_ID}{left:0;}
      #${HOTSPOT_RIGHT_ID}{right:0;}
      #${HANDLE_ID}{
        position:absolute;
        left:50%;
        bottom:-12px;
        transform:translateX(-50%);
        z-index:1000003;
        width:74px;
        height:26px;
        border-radius:999px;
        background:rgba(15,23,42,.94);
        border:1px solid rgba(255,255,255,.16);
        box-shadow:0 10px 26px rgba(15,23,42,.30), 0 0 0 1px rgba(255,255,255,.05) inset;
        display:flex;
        align-items:center;
        justify-content:center;
        pointer-events:none;
        opacity:0;
        transition:opacity .18s ease, transform .18s ease, box-shadow .18s ease, background .18s ease;
      }
      #${HANDLE_ID} .ldd-wake-pill{
        width:34px;
        height:5px;
        border-radius:999px;
        background:rgba(255,255,255,.92);
        box-shadow:0 0 14px rgba(255,255,255,.26);
      }

#${HANDLE_ID} .ldd-wake-hint{
  position:absolute;
  bottom:100%;
  left:50%;
  transform:translate(-50%, -6px);
  padding:6px 10px;
  border-radius:999px;
  background:rgba(15,23,42,.92);
  color:#f8fafc;
  font-size:10px;
  font-weight:700;
  letter-spacing:.01em;
  white-space:nowrap;
  box-shadow:0 10px 24px rgba(15,23,42,.24);
  opacity:0;
  pointer-events:none;
  transition:opacity .18s ease, transform .18s ease;
}
#${ROOT_ID}.hidden #${HANDLE_ID}:hover .ldd-wake-hint,
#${ROOT_ID}.hidden #${HOTSPOT_LEFT_ID}:hover ~ #${DOCK_ID} #${HANDLE_ID} .ldd-wake-hint,
#${ROOT_ID}.hidden #${HOTSPOT_RIGHT_ID}:hover ~ #${DOCK_ID} #${HANDLE_ID} .ldd-wake-hint{
  opacity:1;
  transform:translate(-50%, -10px);
}
      #${ROOT_ID}.theme-glass-light #${HANDLE_ID}{background:rgba(15,23,42,.92);}
      #${ROOT_ID}.theme-midnight #${HANDLE_ID}{background:rgba(2,6,23,.96);}
      #${ROOT_ID}.theme-glass-dark #${HANDLE_ID}{background:rgba(17,24,39,.96);border-color:rgba(255,255,255,.18);}
      #${ROOT_ID}.theme-lavender #${HANDLE_ID}{background:rgba(76,29,149,.94);}
      #${ROOT_ID}.theme-neon #${HANDLE_ID}{background:rgba(8,12,24,.96); border-color:rgba(56,189,248,.28);}
      #${DOCK_ID}{
        position:fixed;
        left:50vw !important;
        right:auto !important;
        bottom:10px;
        width:max-content;
        max-width:calc(100vw - 24px);
        margin:0 !important;
        transform:translate3d(-50%,0,0);
        transition:opacity .22s ease, box-shadow .18s ease, transform .22s ease;
        opacity:.98;
        pointer-events:auto;
        z-index:1000002;
      }
      #${ROOT_ID}.hidden #${DOCK_ID}{
        opacity:.92;
        transform:translate3d(-50%,66px,0);
      }
      #${ROOT_ID}.hidden #${HANDLE_ID}{
        opacity:1;
        pointer-events:auto;
      }
      #${ROOT_ID}.hidden.pulsing.effect-bounce #${HANDLE_ID}{
        animation:lddDockBounce 1.1s cubic-bezier(.22,1,.36,1) 5;
      }
      #${ROOT_ID}.hidden.pulsing.effect-premium #${HANDLE_ID}{
        animation:lddDockBounceGlow 1.15s cubic-bezier(.22,1,.36,1) 5;
      }
      #${ROOT_ID}.hidden.effect-premium #${HANDLE_ID}{
        overflow:visible;
      }
      #${ROOT_ID}.hidden.effect-premium #${HANDLE_ID}::after{
        content:"";
        position:absolute;
        inset:auto 6px -6px;
        height:12px;
        border-radius:999px;
        background:radial-gradient(ellipse at center, rgba(99,102,241,.30) 0%, rgba(99,102,241,.16) 45%, rgba(99,102,241,0) 82%);
        opacity:0;
        filter:blur(4px);
        transform:translateY(0) scale(.75);
        pointer-events:none;
      }
      #${ROOT_ID}.hidden.pulsing.effect-premium #${HANDLE_ID}::after{
        animation:lddDockGlowTrail 1.15s cubic-bezier(.22,1,.36,1) 5;
      }
      @keyframes lddDockBounce{
        0%,100%{transform:translateX(-50%) translateY(0) scale(1); box-shadow:0 8px 20px rgba(15,23,42,.16);}
        35%{transform:translateX(-50%) translateY(-8px) scale(1.06); box-shadow:0 14px 24px rgba(15,23,42,.2);}
        65%{transform:translateX(-50%) translateY(0) scale(.98); box-shadow:0 8px 18px rgba(15,23,42,.14);}
      }
      @keyframes lddDockBounceGlow{
        0%,100%{transform:translateX(-50%) translateY(0) scale(1); box-shadow:0 8px 20px rgba(15,23,42,.16), 0 0 0 rgba(99,102,241,0);}
        35%{transform:translateX(-50%) translateY(-9px) scale(1.08); box-shadow:0 16px 28px rgba(15,23,42,.22), 0 0 22px rgba(99,102,241,.18);}
        65%{transform:translateX(-50%) translateY(0) scale(.985); box-shadow:0 8px 18px rgba(15,23,42,.14), 0 0 10px rgba(99,102,241,.10);}
      }
      @keyframes lddDockGlowTrail{
        0%,100%{opacity:0; transform:translateY(0) scale(.75);}
        30%{opacity:.9; transform:translateY(1px) scale(1.15);}
        65%{opacity:.35; transform:translateY(0) scale(.92);}
      }
      #${DOCK_ID} .ldd-dock{
        display:flex;
        align-items:center;
        gap:12px;
        padding:10px 14px;
        border-radius:999px;
        background:rgba(255,255,255,.97);
        border:1px solid rgba(15,23,42,.08);
        box-shadow:0 12px 30px rgba(15,23,42,.18),0 2px 8px rgba(15,23,42,.06);
        backdrop-filter:blur(10px);
      }
      #${DOCK_ID} .ldd-dock.ldd-mini-dock{
        gap:10px;
        padding:10px 12px;
      }
      #${ROOT_ID}.theme-glass-light #${DOCK_ID} .ldd-dock{
        background:linear-gradient(180deg, rgba(255,255,255,.95), rgba(248,250,252,.90));
        border:1px solid rgba(255,255,255,.95);
        box-shadow:0 18px 40px rgba(15,23,42,.12), inset 0 1px 0 rgba(255,255,255,.88);
        backdrop-filter:blur(16px) saturate(145%);
      }
      #${ROOT_ID}.theme-glass-dark #${DOCK_ID} .ldd-dock{
        background:linear-gradient(180deg, rgba(255,255,255,.18), rgba(148,163,184,.16));
        border:1px solid rgba(255,255,255,.22);
        box-shadow:0 18px 42px rgba(2,6,23,.34), inset 0 1px 0 rgba(255,255,255,.18);
        backdrop-filter:blur(18px) saturate(140%);
      }
      #${ROOT_ID}.theme-glass-dark #${DOCK_ID} .ldd-icon-btn:hover{
        background:rgba(15,23,42,.08);
        box-shadow:0 8px 18px rgba(15,23,42,.12);
      }
      #${ROOT_ID}.theme-neon #${DOCK_ID} .ldd-dock{
        background:linear-gradient(180deg, rgba(10,14,28,.96), rgba(15,23,42,.92));
        border:1px solid rgba(56,189,248,.34);
        box-shadow:0 18px 44px rgba(2,6,23,.44), 0 0 0 1px rgba(56,189,248,.10) inset, 0 0 24px rgba(168,85,247,.14);
        backdrop-filter:blur(12px) saturate(150%);
      }
      #${ROOT_ID}.theme-neon #${DOCK_ID} .ldd-btn,
      #${ROOT_ID}.theme-neon #${DOCK_ID} .ldd-upload-label,
      #${ROOT_ID}.theme-neon #${DOCK_ID} .ldd-switch{color:#e2e8f0;}
      #${ROOT_ID}.theme-neon #${DOCK_ID} .ldd-btn svg{stroke:#f8fafc;}
      #${ROOT_ID}.theme-neon #${DOCK_ID} .ldd-divider{background:rgba(56,189,248,.22);}
      #${ROOT_ID}.theme-neon #${DOCK_ID} .ldd-icon-btn:hover{background:rgba(56,189,248,.10);box-shadow:0 8px 18px rgba(56,189,248,.14), 0 0 18px rgba(168,85,247,.10);}
      #${ROOT_ID}.theme-midnight #${DOCK_ID} .ldd-dock{
        background:linear-gradient(180deg, rgba(15,23,42,.96), rgba(15,23,42,.88));
        border:1px solid rgba(99,102,241,.26);
        box-shadow:0 18px 44px rgba(2,6,23,.42), 0 0 0 1px rgba(99,102,241,.08) inset;
        backdrop-filter:blur(10px);
      }
      #${ROOT_ID}.theme-midnight #${DOCK_ID} .ldd-btn,
      #${ROOT_ID}.theme-midnight #${DOCK_ID} .ldd-upload-label,
      #${ROOT_ID}.theme-midnight #${DOCK_ID} .ldd-switch{color:#e5e7eb;}
      #${ROOT_ID}.theme-midnight #${DOCK_ID} .ldd-btn svg{stroke:#f8fafc;}
      #${ROOT_ID}.theme-midnight #${DOCK_ID} .ldd-divider{background:rgba(148,163,184,.28);}
      #${ROOT_ID}.theme-glass-light-legacy #${DOCK_ID} .ldd-dock{
        background:#ffffff;
        border:1px solid rgba(15,23,42,.08);
        box-shadow:0 10px 24px rgba(15,23,42,.10), 0 1px 2px rgba(15,23,42,.04);
        backdrop-filter:none;
      }
      #${ROOT_ID}.theme-lavender #${DOCK_ID} .ldd-dock{
        background:linear-gradient(180deg, rgba(124,58,237,.16), rgba(255,255,255,.92));
        border:1px solid rgba(124,58,237,.20);
        box-shadow:0 18px 40px rgba(91,33,182,.16), inset 0 1px 0 rgba(255,255,255,.28);
        backdrop-filter:blur(12px) saturate(130%);
      }
      #${ROOT_ID}.theme-lavender #${DOCK_ID} .ldd-btn:hover{box-shadow:0 8px 20px rgba(124,58,237,.16);}
      
#${ROOT_ID}.theme-sunset #${HANDLE_ID}{
  background:rgba(124,45,18,.94);
  border-color:rgba(251,191,36,.26);
}
#${ROOT_ID}.theme-obsidian #${HANDLE_ID}{
  background:rgba(3,7,18,.96);
  border-color:rgba(148,163,184,.22);
}
#${ROOT_ID}.theme-rose #${HANDLE_ID}{
  background:rgba(136,19,55,.94);
  border-color:rgba(244,114,182,.26);
}
#${ROOT_ID}.theme-sunset #${DOCK_ID} .ldd-dock{
  background:linear-gradient(180deg, rgba(255,247,237,.96), rgba(254,215,170,.88));
  border:1px solid rgba(251,146,60,.28);
  box-shadow:0 18px 40px rgba(154,52,18,.18), inset 0 1px 0 rgba(255,255,255,.72);
  backdrop-filter:blur(10px) saturate(125%);
}
#${ROOT_ID}.theme-sunset #${DOCK_ID} .ldd-icon-btn:hover{
  background:rgba(251,146,60,.12);
  box-shadow:0 8px 18px rgba(249,115,22,.18);
}
#${ROOT_ID}.theme-obsidian #${DOCK_ID} .ldd-dock{
  background:linear-gradient(180deg, rgba(2,6,23,.97), rgba(15,23,42,.92));
  border:1px solid rgba(148,163,184,.18);
  box-shadow:0 18px 44px rgba(2,6,23,.48), inset 0 1px 0 rgba(255,255,255,.04);
  backdrop-filter:blur(10px) saturate(110%);
}
#${ROOT_ID}.theme-obsidian #${DOCK_ID} .ldd-btn,
#${ROOT_ID}.theme-obsidian #${DOCK_ID} .ldd-upload-label,
#${ROOT_ID}.theme-obsidian #${DOCK_ID} .ldd-switch{color:#e5e7eb;}
#${ROOT_ID}.theme-obsidian #${DOCK_ID} .ldd-btn svg{stroke:#f8fafc;}
#${ROOT_ID}.theme-obsidian #${DOCK_ID} .ldd-divider{background:rgba(148,163,184,.22);}
#${ROOT_ID}.theme-obsidian #${DOCK_ID} .ldd-icon-btn:hover{
  background:rgba(148,163,184,.10);
  box-shadow:0 8px 18px rgba(15,23,42,.24);
}
#${ROOT_ID}.theme-rose #${DOCK_ID} .ldd-dock{
  background:linear-gradient(180deg, rgba(255,241,242,.98), rgba(251,207,232,.9));
  border:1px solid rgba(244,114,182,.24);
  box-shadow:0 18px 40px rgba(157,23,77,.16), inset 0 1px 0 rgba(255,255,255,.76);
  backdrop-filter:blur(12px) saturate(130%);
}
#${ROOT_ID}.theme-rose #${DOCK_ID} .ldd-icon-btn:hover{
  background:rgba(244,114,182,.12);
  box-shadow:0 8px 18px rgba(244,114,182,.18);
}

#${ROOT_ID}.theme-rainbow #${HANDLE_ID}{
  background:linear-gradient(135deg,rgba(255,0,128,.92),rgba(255,200,0,.92),rgba(0,255,200,.92));
  border-color:rgba(255,255,255,.3);
}
#${ROOT_ID}.theme-rainbow #${DOCK_ID} .ldd-dock{
  background:linear-gradient(135deg,rgba(255,0,128,.18),rgba(255,200,0,.14),rgba(0,200,255,.18));
  border:1px solid rgba(255,100,200,.3);
  box-shadow:0 18px 40px rgba(200,0,150,.18), inset 0 1px 0 rgba(255,255,255,.7);
  backdrop-filter:blur(14px) saturate(160%);
}
#${ROOT_ID}.theme-rainbow #${DOCK_ID} .ldd-icon-btn:hover{
  background:linear-gradient(135deg,rgba(255,0,128,.15),rgba(0,200,255,.15));
  box-shadow:0 0 18px rgba(255,0,200,.2);
}
#${ROOT_ID}.theme-neon-green #${HANDLE_ID}{background:rgba(4,20,4,.96);border-color:rgba(0,255,100,.4);}
#${ROOT_ID}.theme-neon-green #${DOCK_ID} .ldd-dock{
  background:rgba(4,16,4,.94);
  border:1px solid rgba(0,255,100,.28);
  box-shadow:0 0 24px rgba(0,255,100,.18),0 18px 40px rgba(0,0,0,.5);
  backdrop-filter:blur(14px) saturate(120%);
}
#${ROOT_ID}.theme-neon-green #${DOCK_ID} .ldd-btn,
#${ROOT_ID}.theme-neon-green #${DOCK_ID} .ldd-upload-label,
#${ROOT_ID}.theme-neon-green #${DOCK_ID} .ldd-switch{color:#00ff64;}
#${ROOT_ID}.theme-neon-green #${DOCK_ID} .ldd-btn svg{stroke:#00ff64;}
#${ROOT_ID}.theme-neon-green #${DOCK_ID} .ldd-divider{background:rgba(0,255,100,.25);}
#${ROOT_ID}.theme-neon-green #${DOCK_ID} .ldd-icon-btn:hover{background:rgba(0,255,100,.1);box-shadow:0 0 18px rgba(0,255,100,.25);}
#${ROOT_ID}.theme-neon-pink #${HANDLE_ID}{background:rgba(20,4,14,.96);border-color:rgba(255,0,180,.4);}
#${ROOT_ID}.theme-neon-pink #${DOCK_ID} .ldd-dock{
  background:rgba(18,4,12,.94);
  border:1px solid rgba(255,0,180,.28);
  box-shadow:0 0 24px rgba(255,0,180,.18),0 18px 40px rgba(0,0,0,.5);
  backdrop-filter:blur(14px) saturate(120%);
}
#${ROOT_ID}.theme-neon-pink #${DOCK_ID} .ldd-btn,
#${ROOT_ID}.theme-neon-pink #${DOCK_ID} .ldd-upload-label,
#${ROOT_ID}.theme-neon-pink #${DOCK_ID} .ldd-switch{color:#ff40cc;}
#${ROOT_ID}.theme-neon-pink #${DOCK_ID} .ldd-btn svg{stroke:#ff40cc;}
#${ROOT_ID}.theme-neon-pink #${DOCK_ID} .ldd-divider{background:rgba(255,0,180,.25);}
#${ROOT_ID}.theme-neon-pink #${DOCK_ID} .ldd-icon-btn:hover{background:rgba(255,0,180,.1);box-shadow:0 0 18px rgba(255,0,180,.25);}
#${ROOT_ID}.theme-purple-gradient #${HANDLE_ID}{background:linear-gradient(135deg,rgba(88,28,135,.95),rgba(124,58,237,.92));}
#${ROOT_ID}.theme-purple-gradient #${DOCK_ID} .ldd-dock{
  background:linear-gradient(180deg,rgba(237,233,254,.98),rgba(221,214,254,.9));
  border:1px solid rgba(124,58,237,.22);
  box-shadow:0 18px 40px rgba(88,28,135,.16),inset 0 1px 0 rgba(255,255,255,.8);
  backdrop-filter:blur(12px) saturate(130%);
}
#${ROOT_ID}.theme-purple-gradient #${DOCK_ID} .ldd-icon-btn:hover{background:rgba(124,58,237,.12);box-shadow:0 8px 18px rgba(124,58,237,.18);}
#${ROOT_ID}.theme-ocean #${HANDLE_ID}{background:linear-gradient(135deg,rgba(3,105,161,.95),rgba(6,182,212,.9));}
#${ROOT_ID}.theme-ocean #${DOCK_ID} .ldd-dock{
  background:linear-gradient(180deg,rgba(224,242,254,.98),rgba(207,250,254,.9));
  border:1px solid rgba(6,182,212,.24);
  box-shadow:0 18px 40px rgba(3,105,161,.16),inset 0 1px 0 rgba(255,255,255,.8);
  backdrop-filter:blur(12px) saturate(130%);
}
#${ROOT_ID}.theme-ocean #${DOCK_ID} .ldd-icon-btn:hover{background:rgba(6,182,212,.12);box-shadow:0 8px 18px rgba(6,182,212,.18);}
#${ROOT_ID}.theme-custom #${HANDLE_ID}{background:var(--ldd-custom-color1,#3b82f6);}
#${ROOT_ID}.theme-custom #${DOCK_ID} .ldd-dock{
  background:linear-gradient(180deg, color-mix(in srgb, var(--ldd-custom-color1,#3b82f6) 12%, white 88%), color-mix(in srgb, var(--ldd-custom-color2,#6d28d9) 10%, white 90%));
  border:1px solid color-mix(in srgb, var(--ldd-custom-color1,#3b82f6) 30%, transparent 70%);
  box-shadow:0 18px 40px color-mix(in srgb, var(--ldd-custom-color1,#3b82f6) 20%, transparent 80%),inset 0 1px 0 rgba(255,255,255,.8);
  backdrop-filter:blur(12px) saturate(130%);
}
#${ROOT_ID}.theme-custom #${DOCK_ID} .ldd-icon-btn:hover{
  background:color-mix(in srgb, var(--ldd-custom-color1,#3b82f6) 12%, transparent 88%);
  box-shadow:0 8px 18px color-mix(in srgb, var(--ldd-custom-color1,#3b82f6) 20%, transparent 80%);
}

#${ROOT_ID}.icons-light #${DOCK_ID} .ldd-icon-btn,
#${ROOT_ID}.icons-light #${DOCK_ID} .ldd-upload-label,
#${ROOT_ID}.icons-light #${DOCK_ID} .ldd-switch{color:#f8fafc;}
#${ROOT_ID}.icons-light #${DOCK_ID} .ldd-icon-btn svg{stroke:#f8fafc;filter:drop-shadow(0 1px 1px rgba(2,6,23,.22));}
#${ROOT_ID}.icons-light #${DOCK_ID} .ldd-divider{background:rgba(248,250,252,.24);}
#${ROOT_ID}.icons-light #${DOCK_ID} .ldd-icon-btn:hover{background:rgba(255,255,255,.10);color:#fff;box-shadow:0 8px 18px rgba(15,23,42,.20);}
#${ROOT_ID}.icons-light #${DOCK_ID} .ldd-settings-btn{background:rgba(255,255,255,.14);color:#f8fafc;}
#${ROOT_ID}.icons-light #${DOCK_ID} .ldd-settings-btn:hover{background:rgba(255,255,255,.22);color:#fff;}
#${ROOT_ID}.icons-light #${DOCK_ID} .ldd-danger-btn{color:#ff6b6b;}
#${ROOT_ID}.icons-light #${DOCK_ID} .ldd-danger-btn:hover{background:rgba(255,107,107,.12);color:#ff8d8d;box-shadow:0 6px 16px rgba(255,107,107,.16);}
#${ROOT_ID}.icons-light #${DOCK_ID} .ldd-dock-group[data-group-id="listing"] .ldd-danger-btn{color:#ff6b6b;}
#${ROOT_ID}.icons-light #${DOCK_ID} .ldd-dock-group[data-group-id="listing"] .ldd-danger-btn svg{stroke:#ff6b6b;}
#${ROOT_ID}.icons-light #${DOCK_ID} .ldd-dock-group[data-group-id="listing"] .ldd-danger-btn:hover{background:rgba(255,107,107,.12);color:#ff8d8d;}
#${ROOT_ID}.icons-light #${DOCK_ID} .ldd-dock-group[data-group-id="ai"] .ldd-icon-btn{color:#c4b5fd;}
#${ROOT_ID}.icons-light #${DOCK_ID} .ldd-dock-group[data-group-id="ai"] .ldd-icon-btn:hover{background:rgba(196,181,253,.15);color:#ddd6fe;}
#${ROOT_ID}.icons-light #${DOCK_ID} .ldd-dock-group[data-group-id="files"] .ldd-icon-btn{color:#7dd3fc;}
#${ROOT_ID}.icons-light #${DOCK_ID} .ldd-dock-group[data-group-id="files"] .ldd-icon-btn:hover{background:rgba(125,211,252,.15);color:#bae6fd;}
#${ROOT_ID}.icons-light #${DOCK_ID} .ldd-dock-group[data-group-id="listing"] .ldd-icon-btn{color:#6ee7b7;}
#${ROOT_ID}.icons-light #${DOCK_ID} .ldd-dock-group[data-group-id="listing"] .ldd-icon-btn:hover{background:rgba(110,231,183,.15);color:#a7f3d0;}
#${ROOT_ID}.icons-dark #${DOCK_ID} .ldd-icon-btn,
#${ROOT_ID}.icons-dark #${DOCK_ID} .ldd-upload-label,
#${ROOT_ID}.icons-dark #${DOCK_ID} .ldd-switch{color:#0f172a;}
#${ROOT_ID}.icons-dark #${DOCK_ID} .ldd-icon-btn svg{stroke:#0f172a;filter:none;}
#${ROOT_ID}.icons-dark #${DOCK_ID} .ldd-divider{background:rgba(15,23,42,.12);}
#${ROOT_ID}.icons-dark #${DOCK_ID} .ldd-icon-btn:hover{background:rgba(15,23,42,.06);color:#020617;box-shadow:0 8px 18px rgba(15,23,42,.12);}
#${ROOT_ID}.icons-dark #${DOCK_ID} .ldd-settings-btn{background:rgba(15,23,42,.06);color:#334155;}
#${ROOT_ID}.icons-dark #${DOCK_ID} .ldd-settings-btn:hover{background:rgba(15,23,42,.10);color:#0f172a;}
#${ROOT_ID}.icons-dark #${DOCK_ID} .ldd-dock-group[data-group-id="ai"] .ldd-icon-btn{color:#7c3aed;}
#${ROOT_ID}.icons-dark #${DOCK_ID} .ldd-dock-group[data-group-id="ai"] .ldd-icon-btn:hover{background:rgba(124,58,237,.10);color:#6d28d9;}
#${ROOT_ID}.icons-dark #${DOCK_ID} .ldd-dock-group[data-group-id="files"] .ldd-icon-btn{color:#0284c7;}
#${ROOT_ID}.icons-dark #${DOCK_ID} .ldd-dock-group[data-group-id="files"] .ldd-icon-btn:hover{background:rgba(2,132,199,.10);color:#0369a1;}
#${ROOT_ID}.icons-dark #${DOCK_ID} .ldd-dock-group[data-group-id="listing"] .ldd-icon-btn{color:#059669;}
#${ROOT_ID}.icons-dark #${DOCK_ID} .ldd-dock-group[data-group-id="listing"] .ldd-icon-btn:hover{background:rgba(5,150,105,.10);color:#047857;}
#${ROOT_ID}.icons-depth #${DOCK_ID} .ldd-icon-btn svg{filter:drop-shadow(0 0 2px rgba(255,255,255,.22)) drop-shadow(0 1px 2px rgba(15,23,42,.18));}

#${DOCK_ID} .ldd-logo{
        width:32px;height:32px;border-radius:999px;object-fit:cover;display:block;background:#fff;
        border:1px solid rgba(15,23,42,.08);box-shadow:0 4px 10px rgba(15,23,42,.08);
      }
      #${DOCK_ID} .ldd-actions,#${DOCK_ID} .ldd-upload-row{display:flex;align-items:flex-end;gap:6px;}
      #${DOCK_ID} .ldd-dock-groups{display:flex;align-items:flex-end;gap:10px;}
      #${DOCK_ID} .ldd-dock-group{display:flex;flex-direction:column;align-items:center;gap:5px;}
      #${DOCK_ID} .ldd-dock-group-head{font-size:10px;font-weight:900;letter-spacing:.10em;text-transform:uppercase;color:#111827;line-height:1;white-space:nowrap;}
      #${DOCK_ID} .ldd-dock-group-actions{display:flex;align-items:center;gap:6px;}
      #${DOCK_ID} .ldd-group-divider{width:auto;min-width:16px;height:auto;align-self:flex-end;background:none;margin:0 4px 7px;color:#111827 !important;font-size:24px;font-weight:900;line-height:1;display:flex;align-items:center;justify-content:center;opacity:1;}
      #${DOCK_ID} .ldd-icon-btn{
        width:42px;height:42px;border:0;border-radius:12px;background:transparent;color:#334155;
        display:inline-flex;align-items:center;justify-content:center;cursor:pointer;padding:0;
        will-change:transform;
        transform-origin:center bottom;
        transition:transform .18s cubic-bezier(.22,1,.36,1), background .16s ease, color .16s ease, box-shadow .16s ease;
      }
      #${DOCK_ID} .ldd-actions .ldd-icon-btn,
      #${DOCK_ID} .ldd-upload-row .ldd-icon-btn{
        margin-inline:0;
        transition:transform .18s cubic-bezier(.22,1,.36,1), margin .18s cubic-bezier(.22,1,.36,1), background .16s ease, color .16s ease, box-shadow .16s ease;
      }
      #${DOCK_ID} .ldd-icon-btn:hover{
        background:#f8fafc;color:#111827;box-shadow:0 6px 16px rgba(15,23,42,.12);
      }
      #${DOCK_ID} .ldd-dock-group[data-group-id="ai"] .ldd-icon-btn{color:#7c3aed;}
      #${DOCK_ID} .ldd-dock-group[data-group-id="ai"] .ldd-icon-btn svg{stroke:#7c3aed;}
      #${DOCK_ID} .ldd-dock-group[data-group-id="ai"] .ldd-icon-btn:hover{background:rgba(124,58,237,.10);color:#6d28d9;box-shadow:0 6px 16px rgba(124,58,237,.16);}
      #${DOCK_ID} .ldd-dock-group[data-group-id="ai"] .ldd-dock-group-head{color:#7c3aed;}
      #${DOCK_ID} .ldd-dock-group[data-group-id="files"] .ldd-icon-btn{color:#0284c7;}
      #${DOCK_ID} .ldd-dock-group[data-group-id="files"] .ldd-icon-btn svg{stroke:#0284c7;}
      #${DOCK_ID} .ldd-dock-group[data-group-id="files"] .ldd-icon-btn:hover{background:rgba(2,132,199,.10);color:#0369a1;box-shadow:0 6px 16px rgba(2,132,199,.16);}
      #${DOCK_ID} .ldd-dock-group[data-group-id="files"] .ldd-dock-group-head{color:#0284c7;}
      #${DOCK_ID} .ldd-dock-group[data-group-id="listing"] .ldd-icon-btn{color:#059669;}
      #${DOCK_ID} .ldd-dock-group[data-group-id="listing"] .ldd-icon-btn svg{stroke:#059669;}
      #${DOCK_ID} .ldd-dock-group[data-group-id="listing"] .ldd-icon-btn:hover{background:rgba(5,150,105,.10);color:#047857;box-shadow:0 6px 16px rgba(5,150,105,.16);}
      #${DOCK_ID} .ldd-dock-group[data-group-id="listing"] .ldd-dock-group-head{color:#059669;}
      #${DOCK_ID} .ldd-icon-btn svg{width:20px;height:20px;stroke:currentColor !important;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;}
      #${DOCK_ID} .ldd-divider{width:1px;height:38px;background:rgba(15,23,42,.08);margin:0 2px;}
      #${DOCK_ID} .ldd-upload-block{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;min-height:42px;padding-right:2px;}
      #${DOCK_ID} .ldd-upload-label{font-size:10px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;color:#94a3b8;line-height:1;white-space:nowrap;text-align:center;width:100%;}
      #${DOCK_ID} .ldd-switch{position:relative;width:42px;height:22px;display:inline-flex;align-items:center;justify-content:center;}
      #${DOCK_ID} .ldd-switch input{position:absolute;inset:0;opacity:0;cursor:pointer;margin:0;}
      #${DOCK_ID} .ldd-switch-track{position:absolute;inset:0;border-radius:999px;background:#dbeafe;transition:background .16s ease;}
      #${DOCK_ID} .ldd-switch-thumb{position:absolute;top:2px;left:2px;width:18px;height:18px;border-radius:999px;background:#fff;box-shadow:0 1px 4px rgba(15,23,42,.18);transition:transform .16s ease;}
      #${DOCK_ID} .ldd-switch input:checked + .ldd-switch-track{background:#c7d2fe;}
      #${DOCK_ID} .ldd-switch input:checked + .ldd-switch-track .ldd-switch-thumb{transform:translateX(20px);}
      #${DOCK_ID} .ldd-settings-btn{background:#f8fafc;color:#475569;}
      #${DOCK_ID} .ldd-settings-btn:hover{background:#eef2ff;color:#312e81;}
      #${DOCK_ID} .ldd-danger-btn{color:#dc2626;}
      #${DOCK_ID} .ldd-danger-btn:hover{background:#fef2f2;color:#b91c1c;box-shadow:0 6px 16px rgba(220,38,38,.16);}
      #${DOCK_ID} .ldd-dock-group[data-group-id="listing"] .ldd-danger-btn{color:#dc2626;}
      #${DOCK_ID} .ldd-dock-group[data-group-id="listing"] .ldd-danger-btn svg{stroke:#dc2626;}
      #${DOCK_ID} .ldd-dock-group[data-group-id="listing"] .ldd-danger-btn:hover{background:#fef2f2;color:#b91c1c;box-shadow:0 6px 16px rgba(220,38,38,.16);}
      #${TIP_ID}{
        position:fixed;z-index:1000004;pointer-events:none;opacity:0;transform:translateY(4px);
        transition:opacity .14s ease,transform .14s ease;background:#fff;border:1px solid rgba(15,23,42,.08);
        box-shadow:0 10px 28px rgba(15,23,42,.14);border-radius:12px;padding:8px 10px;font-size:12px;font-weight:600;color:#334155;white-space:nowrap;
      }
      #${TIP_ID}.show{opacity:1;transform:translateY(0);}
      #${SETTINGS_BUBBLE_ID}{
        position:fixed;
        z-index:1000005;
        width:min(240px, calc(100vw - 24px));
        opacity:0;
        transform:translateY(8px) scale(.98);
        transform-origin:var(--ldd-bubble-origin, center bottom);
        transition:opacity .16s ease, transform .16s cubic-bezier(.22,1,.36,1);
      }
      #${SETTINGS_BUBBLE_ID}.show{
        opacity:1;
        transform:translateY(0) scale(1);
      }
      #${SETTINGS_BUBBLE_ID} .ldd-settings-bubble-card{
        position:relative;
        padding:12px;
        border-radius:16px;
        background:rgba(255,255,255,.98);
        border:1px solid rgba(15,23,42,.08);
        box-shadow:0 18px 40px rgba(15,23,42,.18), 0 4px 12px rgba(15,23,42,.08);
        backdrop-filter:blur(14px) saturate(135%);
      }
      #${SETTINGS_BUBBLE_ID} .ldd-settings-bubble-card::after{
        content:"";
        position:absolute;
        left:var(--ldd-bubble-arrow-left, 50%);
        bottom:-8px;
        width:16px;
        height:16px;
        background:rgba(255,255,255,.98);
        border-right:1px solid rgba(15,23,42,.08);
        border-bottom:1px solid rgba(15,23,42,.08);
        transform:translateX(-50%) rotate(45deg);
      }
      #${SETTINGS_BUBBLE_ID} .ldd-settings-bubble-title{
        font-size:12px;
        font-weight:800;
        color:#0f172a;
        margin-bottom:10px;
      }
      #${SETTINGS_BUBBLE_ID} .ldd-settings-bubble-row,
      #${SETTINGS_BUBBLE_ID} .ldd-settings-bubble-stack{
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:12px;
        margin-bottom:8px;
        font-size:12px;
        color:#334155;
      }
      #${SETTINGS_BUBBLE_ID} .ldd-settings-bubble-stack{
        align-items:flex-start;
        flex-direction:column;
      }
      #${SETTINGS_BUBBLE_ID} select{
        width:100%;
        height:36px;
        border-radius:12px;
        border:1px solid rgba(15,23,42,.10);
        background:#fff;
        color:#0f172a;
        padding:0 12px;
        font-size:12px;
        font-weight:600;
      }
      #${SETTINGS_BUBBLE_ID} input[type="checkbox"]{
        width:18px;
        height:18px;
      }
      #${SETTINGS_BUBBLE_ID} .ldd-settings-bubble-link{
        width:100%;
        height:38px;
        margin-top:4px;
        border:0;
        border-radius:12px;
        background:#eef2ff;
        color:#3730a3;
        font-size:12px;
        font-weight:800;
        cursor:pointer;
      }
      #${SETTINGS_BUBBLE_ID} .ldd-settings-bubble-link:hover{
        background:#e0e7ff;
      }
      #${SETTINGS_BUBBLE_ID} .ldd-settings-bubble-link--muted{
        background:transparent;
        color:#94a3b8;
        font-weight:600;
        height:28px;
        margin-top:0;
      }
      #${SETTINGS_BUBBLE_ID} .ldd-settings-bubble-link--muted:hover{
        background:#f1f5f9;
        color:#475569;
      }
      #ldd-legal-flyout{
        position:fixed;
        z-index:1000006;
        background:rgba(255,255,255,.98);
        border:1px solid rgba(15,23,42,.08);
        border-radius:16px;
        box-shadow:0 18px 40px rgba(15,23,42,.18), 0 4px 12px rgba(15,23,42,.08);
        backdrop-filter:blur(14px) saturate(135%);
        padding:14px;
        display:flex;
        flex-direction:column;
        gap:10px;
        overflow-y:auto;
        max-height:calc(100vh - 40px);
      }
      #ldd-legal-flyout .ldd-legal-flyout-title{
        font-size:12px;
        font-weight:800;
        color:#1e2a40;
        padding-bottom:8px;
        border-bottom:1px solid #e2e8f0;
        margin-bottom:2px;
      }
      #ldd-legal-flyout .ldd-legal-entry{
        background:#f8faff;
        border:1px dashed #cad4ea;
        border-radius:10px;
        padding:9px 11px;
        font-size:10px;
        color:#6f7c97;
        line-height:1.55;
      }
      #ldd-legal-flyout .ldd-legal-entry strong{
        display:block;
        font-size:10px;
        font-weight:800;
        color:#1e2a40;
        margin-bottom:4px;
      }
      #ldd-legal-flyout .ldd-legal-entry p{
        margin:0;
      }
      #ldd-legal-flyout .ldd-legal-entry code{
        font-size:9px;
        background:#eef2f9;
        padding:1px 3px;
        border-radius:3px;
        border:1px solid #cad4ea;
      }
      #ldd-dock-disable-confirm{
        position:fixed;
        inset:0;
        z-index:1000008;
      }
      #ldd-dock-disable-confirm .ldd-white-card-backdrop{
        position:absolute;
        inset:0;
        background:rgba(15,23,42,.24);
        backdrop-filter:blur(4px);
      }
      #ldd-dock-disable-confirm .ldd-white-card-popup{
        position:absolute;
        left:50%;
        top:50%;
        width:min(360px, calc(100vw - 28px));
        transform:translate(-50%, -50%);
        background:#fff;
        border:1px solid rgba(15,23,42,.08);
        border-radius:20px;
        box-shadow:0 24px 60px rgba(15,23,42,.22), 0 6px 20px rgba(15,23,42,.10);
        padding:18px;
      }
      #ldd-dock-disable-confirm .ldd-white-card-title{
        font-size:16px;
        font-weight:900;
        color:#0f172a;
        margin-bottom:8px;
      }
      #ldd-dock-disable-confirm .ldd-white-card-body{
        font-size:13px;
        line-height:1.5;
        color:#475569;
      }
      #ldd-dock-disable-confirm .ldd-white-card-actions{
        display:flex;
        justify-content:flex-end;
        gap:10px;
        margin-top:16px;
      }
      #ldd-dock-disable-confirm .ldd-white-card-btn{
        height:40px;
        padding:0 14px;
        border-radius:12px;
        border:0;
        cursor:pointer;
        font-size:12px;
        font-weight:800;
      }
      #ldd-dock-disable-confirm .ldd-white-card-btn-secondary{
        background:#f8fafc;
        color:#334155;
        border:1px solid rgba(15,23,42,.08);
      }
      #ldd-dock-disable-confirm .ldd-white-card-btn-danger{
        background:#dc2626;
        color:#fff;
      }
      #${THEME_MODAL_ID}{
        position:fixed;
        inset:0;
        z-index:1000007;
      }
      #${THEME_MODAL_ID} .ldd-theme-modal-backdrop{
        position:absolute;
        inset:0;
        background:rgba(15,23,42,.26);
      }
      #${THEME_MODAL_ID} .ldd-theme-modal-card{
        position:absolute;
        left:50%;
        top:50%;
        width:min(420px, calc(100vw - 28px));
        transform:translate(-50%, -50%);
        background:#fff;
        border:1px solid rgba(15,23,42,.08);
        border-radius:22px;
        box-shadow:0 24px 60px rgba(15,23,42,.22), 0 6px 20px rgba(15,23,42,.10);
        padding:18px;
      }
      #${THEME_MODAL_ID} .ldd-modal-x,
      #${PROMPT_MODAL_ID} .ldd-modal-x,
      #${MORE_TOOLS_MODAL_ID} .ldd-modal-x{
        position:absolute;
        top:12px;
        right:12px;
        width:34px;
        height:34px;
        border:1px solid rgba(15,23,42,.08);
        border-radius:999px;
        background:#f8fafc;
        color:#475569;
        font-size:20px;
        line-height:1;
        display:inline-flex;
        align-items:center;
        justify-content:center;
        cursor:pointer;
      }
      #${THEME_MODAL_ID} .ldd-modal-x:hover,
      #${PROMPT_MODAL_ID} .ldd-modal-x:hover,
      #${MORE_TOOLS_MODAL_ID} .ldd-modal-x:hover{
        background:#eef2ff;
        color:#312e81;
      }
      #${THEME_MODAL_ID} .ldd-theme-modal-title{
        font-size:18px;
        font-weight:900;
        color:#0f172a;
        margin-bottom:14px;
      }
      #${THEME_MODAL_ID} .ldd-theme-modal-row,
      #${THEME_MODAL_ID} .ldd-theme-modal-stack{
        display:flex;
        gap:12px;
        margin-bottom:12px;
        font-size:13px;
        color:#334155;
      }
      #${THEME_MODAL_ID} .ldd-theme-modal-row{
        align-items:center;
        justify-content:space-between;
      }
      #${THEME_MODAL_ID} .ldd-theme-modal-stack{
        flex-direction:column;
      }
      #${THEME_MODAL_ID} input[type="color"]{
        width:100%;
        height:44px;
        border:1px solid rgba(15,23,42,.08);
        border-radius:14px;
        background:#fff;
      }
      #${THEME_MODAL_ID} input[type="range"]{
        width:100%;
      }
      #${THEME_MODAL_ID} .ldd-theme-mode-group{
        display:flex;
        gap:8px;
      }
      #${THEME_MODAL_ID} .ldd-theme-mode-btn,
      #${THEME_MODAL_ID} .ldd-theme-secondary-btn,
      #${THEME_MODAL_ID} .ldd-theme-primary-btn{
        height:40px;
        padding:0 14px;
        border-radius:12px;
        border:1px solid rgba(15,23,42,.08);
        background:#f8fafc;
        color:#334155;
        font-size:12px;
        font-weight:800;
        cursor:pointer;
      }
      #${THEME_MODAL_ID} .ldd-theme-primary-btn{
        background:#4f46e5;
        color:#fff;
        border-color:#4f46e5;
      }
      #${THEME_MODAL_ID} .ldd-theme-mode-btn.active{
        background:#eef2ff;
        color:#3730a3;
        border-color:rgba(99,102,241,.22);
      }
      #${THEME_MODAL_ID} .ldd-theme-modal-preview-wrap{
        margin-top:4px;
        display:flex;
        flex-direction:column;
        gap:8px;
        font-size:13px;
        color:#334155;
      }
      #${THEME_MODAL_ID} .ldd-theme-modal-preview{
        height:84px;
        border-radius:16px;
        border:1px solid rgba(15,23,42,.08);
        box-shadow:inset 0 1px 0 rgba(255,255,255,.65);
      }
      #${THEME_MODAL_ID} .ldd-theme-presets-grid{
        display:grid;
        grid-template-columns:repeat(2, minmax(0, 1fr));
        gap:8px;
      }
      #${THEME_MODAL_ID} .ldd-theme-preset-btn{
        min-height:40px;
        padding:8px 10px;
        border-radius:12px;
        border:1px solid rgba(15,23,42,.08);
        background:#f8fafc;
        color:#334155;
        font-size:12px;
        font-weight:800;
        cursor:pointer;
      }
      #${THEME_MODAL_ID} .ldd-theme-preset-btn:hover{
        background:#eef2ff;
        color:#3730a3;
      }
      #${THEME_MODAL_ID} .ldd-theme-modal-actions{
        display:flex;
        justify-content:flex-end;
        flex-wrap:wrap;
        gap:8px;
        margin-top:16px;
      }
      #${PROMPT_MODAL_ID}{
        position:fixed;
        inset:0;
        z-index:1000007;
      }
      #${PROMPT_MODAL_ID} .ldd-prompt-modal-backdrop{
        position:absolute;
        inset:0;
        background:rgba(15,23,42,.22);
      }
      #${PROMPT_MODAL_ID} .ldd-prompt-modal-card{
        position:absolute;
        left:50%;
        top:50%;
        width:min(1120px, calc(100vw - 28px));
        max-height:min(84vh, 860px);
        overflow:hidden;
        transform:translate(-50%, -50%);
        background:#fff;
        border:1px solid rgba(15,23,42,.08);
        border-radius:22px;
        box-shadow:0 24px 60px rgba(15,23,42,.22), 0 6px 20px rgba(15,23,42,.10);
        padding:18px;
      }
      #${PROMPT_MODAL_ID} .ldd-prompt-shell,
      #${MORE_TOOLS_MODAL_ID} .ldd-more-tools-shell{display:grid;grid-template-columns:minmax(250px,320px) minmax(0,1fr);gap:18px;align-items:start;}
      #${PROMPT_MODAL_ID} .ldd-prompt-sidebar,
      #${MORE_TOOLS_MODAL_ID} .ldd-more-tools-column{border:1px solid rgba(15,23,42,.08);border-radius:20px;background:linear-gradient(180deg,#ffffff,#f8fbff);padding:18px;}
      #${PROMPT_MODAL_ID} .ldd-prompt-mainpanel{border:1px solid rgba(15,23,42,.08);border-radius:20px;background:#fff;padding:18px;min-height:540px;overflow:auto;}
      #${PROMPT_MODAL_ID} .ldd-prompt-eyebrow{font-size:11px;text-transform:uppercase;letter-spacing:.12em;color:#6366f1;font-weight:900;margin-bottom:8px;}
      #${PROMPT_MODAL_ID} .ldd-prompt-modal-title{
        font-size:18px;
        font-weight:900;
        color:#0f172a;
        margin-bottom:10px;
      }
      #${PROMPT_MODAL_ID} .ldd-prompt-sidebar-copy,
      #${MORE_TOOLS_MODAL_ID} .ldd-prompt-sidebar-copy{font-size:13px;line-height:1.55;color:#64748b;}
      #${PROMPT_MODAL_ID} .ldd-prompt-sidebar-actions,
      #${PROMPT_MODAL_ID} .ldd-prompt-sidebar-tabs{display:flex;flex-direction:column;gap:10px;margin-top:16px;}
      #${PROMPT_MODAL_ID} .ldd-prompt-toolbar{
        display:flex;
        gap:8px;
        margin-bottom:12px;
        align-items:center;
      }
      #${PROMPT_MODAL_ID} .ldd-prompt-toolbar-meta{font-size:12px;font-weight:700;color:#64748b;white-space:nowrap;}
      #${PROMPT_MODAL_ID} .ldd-prompt-search{
        flex:1;
        height:42px;
        border-radius:12px;
        border:1px solid rgba(15,23,42,.08);
        padding:0 12px;
        font-size:13px;
      }
      #${PROMPT_MODAL_ID} .ldd-prompt-toolbar-btn,
      #${PROMPT_MODAL_ID} .ldd-prompt-secondary-btn,
      #${PROMPT_MODAL_ID} .ldd-prompt-card-actions button{
        height:40px;
        padding:0 14px;
        border-radius:12px;
        border:1px solid rgba(15,23,42,.08);
        background:#f8fafc;
        color:#334155;
        font-size:12px;
        font-weight:800;
        cursor:pointer;
      }
      #${PROMPT_MODAL_ID} .ldd-prompt-primary-btn{background:#4f46e5;color:#fff;border-color:#4338ca;}
      #${PROMPT_MODAL_ID} .ldd-prompt-toolbar-btn:disabled,
      #${PROMPT_MODAL_ID} .ldd-prompt-secondary-btn:disabled,
      #${PROMPT_MODAL_ID} .ldd-prompt-card-actions button:disabled{
        background:#f8fafc !important;
        color:#94a3b8 !important;
        border-color:rgba(148,163,184,.26) !important;
        box-shadow:none !important;
        cursor:not-allowed;
        opacity:1;
      }
      #${PROMPT_MODAL_ID} .ldd-prompt-disabled-card{background:#fff;border:1px solid rgba(148,163,184,.22);box-shadow:0 10px 24px rgba(15,23,42,.08);color:#334155;text-align:left;}
      #${PROMPT_MODAL_ID} .ldd-disabled-tooltip-wrap{position:relative;display:inline-flex;}
      #${PROMPT_MODAL_ID} .ldd-disabled-tooltip-wrap > button{pointer-events:none;}
      #${PROMPT_MODAL_ID} .ldd-disabled-tooltip-wrap::after{
        content:attr(data-disabled-tip);
        position:absolute;
        left:50%;
        bottom:calc(100% + 8px);
        transform:translate(-50%, 4px);
        min-width:max-content;
        max-width:240px;
        padding:8px 10px;
        border-radius:12px;
        background:#fff;
        border:1px solid rgba(15,23,42,.08);
        box-shadow:0 10px 28px rgba(15,23,42,.14);
        color:#334155;
        font-size:12px;
        font-weight:600;
        line-height:1.35;
        white-space:normal;
        opacity:0;
        pointer-events:none;
        z-index:3;
        transition:opacity .14s ease, transform .14s ease;
      }
      #${PROMPT_MODAL_ID} .ldd-disabled-tooltip-wrap:hover::after{opacity:1;transform:translate(-50%, 0);}
      #${PROMPT_MODAL_ID} .ldd-prompt-filter-btn{height:40px;border-radius:12px;border:1px solid rgba(15,23,42,.08);background:#fff;color:#334155;font-size:12px;font-weight:800;cursor:pointer;text-align:left;padding:0 14px;}
      #${PROMPT_MODAL_ID} .ldd-prompt-filter-btn.active{background:#eef2ff;color:#3730a3;border-color:rgba(99,102,241,.22);}
      #${PROMPT_MODAL_ID} .ldd-prompt-list{
        display:flex;
        flex-direction:column;
        gap:14px;
      }
      #${PROMPT_MODAL_ID} .ldd-prompt-section{
        display:flex;
        flex-direction:column;
        gap:10px;
      }
      #${PROMPT_MODAL_ID} .ldd-prompt-section-head{
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:12px;
      }
      #${PROMPT_MODAL_ID} .ldd-prompt-section-title{
        font-size:14px;
        font-weight:900;
        color:#0f172a;
      }
      #${PROMPT_MODAL_ID} .ldd-prompt-section-list{
        display:flex;
        flex-direction:column;
        gap:10px;
      }
      #${PROMPT_MODAL_ID} .ldd-prompt-dream-tools{
        display:flex;
        align-items:center;
        gap:8px;
      }
      #${PROMPT_MODAL_ID} .ldd-prompt-mini-logo{
        width:22px;
        height:22px;
        border-radius:999px;
        object-fit:cover;
        border:1px solid rgba(15,23,42,.08);
      }
      #${PROMPT_MODAL_ID} .ldd-prompt-card{
        border:1px solid rgba(15,23,42,.08);
        border-radius:16px;
        background:#fff;
        overflow:hidden;
      }
      #${PROMPT_MODAL_ID} .ldd-prompt-card.editing{
        border-color:#818cf8;
        box-shadow:0 0 0 3px rgba(99,102,241,.10);
      }
      #${PROMPT_MODAL_ID} .ldd-prompt-card.pinned{
        border-left:4px solid #4f46e5;
      }
      #${PROMPT_MODAL_ID} .ldd-prompt-card-top{
        padding:12px;
      }
      #${PROMPT_MODAL_ID} .ldd-prompt-card-name{
        font-size:13px;
        font-weight:800;
        color:#0f172a;
        margin-bottom:6px;
      }
      #${PROMPT_MODAL_ID} .ldd-prompt-card-preview{
        font-size:12px;
        line-height:1.45;
        color:#64748b;
        white-space:pre-wrap;
      }
      #${PROMPT_MODAL_ID} .ldd-prompt-card-actions{
        display:flex;
        gap:8px;
        flex-wrap:wrap;
        padding:10px 12px 12px;
        border-top:1px solid rgba(15,23,42,.06);
      }
      #${PROMPT_MODAL_ID} .ldd-prompt-editor{
        padding:12px;
        display:flex;
        flex-direction:column;
        gap:10px;
      }
      #${PROMPT_MODAL_ID} .ldd-prompt-editor-name,
      #${PROMPT_MODAL_ID} .ldd-prompt-editor-content{
        width:100%;
        border:1px solid rgba(15,23,42,.08);
        border-radius:12px;
        padding:10px 12px;
        font-size:13px;
        color:#0f172a;
        background:#fff;
      }
      #${PROMPT_MODAL_ID} .ldd-prompt-editor-content{
        min-height:140px;
        resize:vertical;
      }
      #${PROMPT_MODAL_ID} .ldd-prompt-empty{
        padding:18px;
        border-radius:16px;
        border:1px dashed rgba(15,23,42,.14);
        color:#64748b;
        text-align:center;
        font-size:13px;
      }
      #${PROMPT_MODAL_ID} .ldd-prompt-modal-actions{
        display:flex;
        justify-content:flex-end;
        margin-top:14px;
      }
      #${MORE_TOOLS_MODAL_ID}{position:fixed;inset:0;z-index:1000007;}
      #${MORE_TOOLS_MODAL_ID} .ldd-more-tools-card{position:absolute;left:50%;top:50%;width:min(1160px, calc(100vw - 28px));max-height:min(86vh, 900px);overflow:auto;transform:translate(-50%, -50%);background:#f8fafc;border:1px solid rgba(15,23,42,.08);border-radius:24px;box-shadow:0 24px 60px rgba(15,23,42,.22), 0 6px 20px rgba(15,23,42,.10);padding:18px;}
      #${MORE_TOOLS_MODAL_ID} .ldd-more-tools-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin-top:18px;}
      #${MORE_TOOLS_MODAL_ID} .ldd-more-tools-action{display:flex;align-items:center;gap:12px;min-height:54px;border-radius:16px;border:1px solid rgba(15,23,42,.08);background:#fff;padding:12px 14px;cursor:pointer;text-align:left;color:#0f172a;font-size:13px;font-weight:800;}
      #${MORE_TOOLS_MODAL_ID} .ldd-more-tools-action:hover{box-shadow:0 10px 24px rgba(15,23,42,.10);transform:translateY(-1px);}
      #${MORE_TOOLS_MODAL_ID} .ldd-more-tools-icon,
      #${MORE_TOOLS_MODAL_ID} .ldd-white-card-tool-icon{width:18px;height:18px;display:inline-flex;align-items:center;justify-content:center;color:#4f46e5;}
      #${MORE_TOOLS_MODAL_ID} .ldd-more-tools-icon svg,
      #${MORE_TOOLS_MODAL_ID} .ldd-white-card-tool-icon svg{width:18px;height:18px;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;}
      #${MORE_TOOLS_MODAL_ID} .ldd-white-card-manager{background:#fff;}
      #${MORE_TOOLS_MODAL_ID} .ldd-white-card-manager-head{margin-bottom:16px;}
      #${MORE_TOOLS_MODAL_ID} .ldd-white-card-manager-title{font-size:17px;font-weight:900;color:#0f172a;}
      #${MORE_TOOLS_MODAL_ID} .ldd-white-card-manager-copy,
      #${MORE_TOOLS_MODAL_ID} .ldd-white-card-manage-hint{font-size:13px;line-height:1.5;color:#64748b;}
      #${MORE_TOOLS_MODAL_ID} .ldd-white-card-manage-block{border:1px solid rgba(15,23,42,.08);border-radius:18px;background:#fff;padding:14px;margin-top:12px;}
      #${MORE_TOOLS_MODAL_ID} .ldd-white-card-manage-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:10px;}
      #${MORE_TOOLS_MODAL_ID} .ldd-white-card-manage-title{font-size:14px;font-weight:900;color:#0f172a;}
      #${MORE_TOOLS_MODAL_ID} .ldd-white-card-manage-count{min-width:32px;height:32px;border-radius:999px;background:#eef2ff;color:#3730a3;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:12px;}
      #${MORE_TOOLS_MODAL_ID} .ldd-white-card-manage-list{display:flex;flex-direction:column;gap:10px;}
      #${MORE_TOOLS_MODAL_ID} .ldd-white-card-tool-row{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:12px 14px;border-radius:14px;background:#f8fafc;border:1px solid rgba(15,23,42,.05);}
      #${MORE_TOOLS_MODAL_ID} .ldd-white-card-tool-meta{display:flex;align-items:center;gap:10px;font-size:13px;font-weight:800;color:#1e293b;}
      #${MORE_TOOLS_MODAL_ID} .ldd-white-card-toggle{height:36px;padding:0 12px;border-radius:12px;border:1px solid rgba(15,23,42,.08);background:#fff;color:#334155;font-size:12px;font-weight:800;cursor:pointer;white-space:nowrap;}
      @media (max-width: 900px){#${PROMPT_MODAL_ID} .ldd-prompt-modal-card,#${MORE_TOOLS_MODAL_ID} .ldd-more-tools-card{width:min(100vw - 18px, 1000px);padding:14px;}#${PROMPT_MODAL_ID} .ldd-prompt-shell,#${MORE_TOOLS_MODAL_ID} .ldd-more-tools-shell{grid-template-columns:1fr;}#${PROMPT_MODAL_ID} .ldd-prompt-mainpanel{min-height:unset;}#${PROMPT_MODAL_ID} .ldd-prompt-toolbar{flex-direction:column;align-items:stretch;}}
      #${TIP_ID}{position:fixed;left:0;top:0;z-index:2147483647;pointer-events:none;opacity:0;transform:translate(-50%,-100%) translateY(6px);transition:opacity .15s ease,transform .15s ease;background:#fff;color:#1e293b;border:1px solid rgba(148,163,184,.22);box-shadow:0 14px 32px rgba(15,23,42,.16);border-radius:14px;padding:10px 12px;font-size:12px;font-weight:800;line-height:1.3;white-space:nowrap;}
      #${TIP_ID}.show{opacity:1;transform:translate(-50%,-100%) translateY(0);}
    `;
    document.head.appendChild(style);
  }

  function getTipEl() {
    let tip = document.getElementById(TIP_ID);
    if (!tip) {
      tip = document.createElement("div");
      tip.id = TIP_ID;
      document.documentElement.appendChild(tip);
    }
    return tip;
  }

  function attachTip(el, text) {
    let showTimer = null;
    let hideTimer = null;
    el.addEventListener("mouseenter", () => {
      clearTimeout(hideTimer);
      showTimer = setTimeout(() => {
        const tip = getTipEl();
        tip.textContent = text;
        const rect = el.getBoundingClientRect();
        tip.style.left = `${rect.left + rect.width / 2}px`;
        tip.style.top = `${rect.top - 10}px`;
        tip.style.transform = "translate(-50%, -100%)";
        tip.classList.add("show");
      }, 100);
    });
    el.addEventListener("mouseleave", () => {
      clearTimeout(showTimer);
      hideTimer = setTimeout(() => getTipEl().classList.remove("show"), 40);
    });
  }

  function makeIconButton(tipText, svgName, onClick, className = "") {
    const b = document.createElement("button");
    b.className = `ldd-icon-btn ${className}`.trim();
    b.type = "button";
    b.innerHTML = icon(svgName);
    b.dataset.iconName = svgName;
    b.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      onClick();
      window.dispatchEvent(new CustomEvent("ldd-dock-action-clicked", { detail: { tipText, svgName, keepDockOpen: b.dataset.keepDockOpen === "true" } }));
    });
    attachTip(b, tipText);
    return b;
  }

  function makeSettingsBubbleButton() {
    const button = makeIconButton("Dock Settings", "settings", () => toggleDockSettingsBubble(button), "ldd-settings-btn");
    button.dataset.keepDockOpen = "true";
    return button;
  }

  function getGroupedActions(actionsList = ACTION_ITEMS, groups = DOCK_GROUPS) {
    const actionMap = new Map(actionsList.map((item) => [item.id, item]));
    const used = new Set();
    const grouped = groups.map((group) => {
      const items = group.items.map((id) => actionMap.get(id)).filter(Boolean);
      items.forEach((item) => used.add(item.id));
      return { ...group, items };
    }).filter((group) => group.items.length);

    const leftovers = actionsList.filter((item) => !used.has(item.id));
    if (leftovers.length) grouped.push({ id: "more", title: "More Tools", items: leftovers });
    return grouped;
  }

  function makeMoreToolsButton() {
    const button = makeIconButton("More Tools", "more", () => openMoreToolsModal(), "ldd-settings-btn ldd-more-tools-btn");
    button.dataset.keepDockOpen = "true";
    return button;
  }

  function parseHexColor(hex) {
    const raw = String(hex || "").trim().replace("#", "");
    const value = raw.length === 3 ? raw.split("").map((c) => c + c).join("") : raw;
    if (!/^[0-9a-fA-F]{6}$/.test(value)) return null;
    return {
      r: parseInt(value.slice(0, 2), 16),
      g: parseInt(value.slice(2, 4), 16),
      b: parseInt(value.slice(4, 6), 16),
    };
  }

  function toLinear(v) {
    const n = v / 255;
    return n <= 0.03928 ? n / 12.92 : Math.pow((n + 0.055) / 1.055, 2.4);
  }

  function getLuminance(hex) {
    const rgb = parseHexColor(hex);
    if (!rgb) return null;
    return 0.2126 * toLinear(rgb.r) + 0.7152 * toLinear(rgb.g) + 0.0722 * toLinear(rgb.b);
  }

  function getMDThemeMode() {
    const html = document.documentElement;
    const body = document.body;
    const probes = [
      html?.getAttribute("data-theme"),
      body?.getAttribute("data-theme"),
      html?.getAttribute("data-color-mode"),
      body?.getAttribute("data-color-mode"),
      html?.className,
      body?.className,
    ].filter(Boolean).join(" ").toLowerCase();

    if (/light|theme-light|mode-light/.test(probes)) return "light";
    if (/dark|theme-dark|mode-dark/.test(probes)) return "dark";

    const bg = getComputedStyle(body || html).backgroundColor || "rgb(255,255,255)";
    const m = bg.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
    if (m) {
      const lum = 0.2126 * toLinear(Number(m[1])) + 0.7152 * toLinear(Number(m[2])) + 0.0722 * toLinear(Number(m[3]));
      return lum < 0.30 ? "dark" : "light";
    }
    return "dark";
  }

  function decideCustomIconMode(color1, color2, mdTheme) {
    const lum1 = getLuminance(color1);
    const lum2 = getLuminance(color2);
    if (lum1 == null && lum2 == null) return mdTheme === "dark" ? "light" : "dark";
    if (lum1 == null || lum2 == null) {
      const lum = lum1 ?? lum2;
      return lum > 0.42 ? "dark" : "light";
    }
    const avg = (lum1 + lum2) / 2;
    const diff = Math.abs(lum1 - lum2);
    const mixed = (lum1 > 0.58 && lum2 < 0.24) || (lum2 > 0.58 && lum1 < 0.24) || diff > 0.42;
    if (mixed) return mdTheme === "dark" ? "light" : "dark";
    return avg > 0.42 ? "dark" : "light";
  }

  function getThemeAppearance(themeMode, mdTheme) {
    const theme = String(themeMode || "glass-light").toLowerCase();
    switch (theme) {
      case "glass-light":
      case "glass-dark":
      case "sunset":
        return { iconMode: "dark", depth: false };
      case "midnight":
      case "neon-pink":
        return { iconMode: "light", depth: false };
      case "lavender":
        return { iconMode: "light", depth: true };
      case "rainbow":
        return { iconMode: mdTheme === "dark" ? "light" : "dark", depth: false };
      default:
        return { iconMode: mdTheme === "dark" ? "light" : "dark", depth: false };
    }
  }

  function applyDockAppearance(root, dockNode, themeMode, customColors) {
    if (!root || !dockNode) return;
    const mdTheme = getMDThemeMode();
    const appearance = getThemeAppearance(themeMode, mdTheme, customColors);
    root.classList.remove("icons-light", "icons-dark", "icons-depth", "md-light", "md-dark");
    root.classList.add(appearance.iconMode === "light" ? "icons-light" : "icons-dark");
    root.classList.add(mdTheme === "dark" ? "md-dark" : "md-light");
    if (appearance.depth) root.classList.add("icons-depth");
    dockNode.dataset.iconMode = appearance.iconMode;
    dockNode.dataset.mdTheme = mdTheme;
  }

  async function buildRoot(options = {}) {
    const { mini = false, actionsList = ACTION_ITEMS } = options;
    const state = await getStorage({ [MODE_KEY]: true, [DOCK_AUTOHIDE_KEY]: 60, [DOCK_EFFECT_KEY]: "premium", [DOCK_THEME_KEY]: "glass-light" });
    const layout = await getDockActionLayout(actionsList);
    const mainActions = mini && !layout.main.length ? actionsList : layout.main;
    const overflowActions = layout.more;
    const root = document.createElement("div");
    root.id = ROOT_ID;

    const hotspot = document.createElement("div");
    hotspot.id = HOTSPOT_ID;
    const hotspotLeft = document.createElement("div");
    hotspotLeft.id = HOTSPOT_LEFT_ID;
    hotspotLeft.className = "ldd-hotspot-corner";
    const hotspotRight = document.createElement("div");
    hotspotRight.id = HOTSPOT_RIGHT_ID;
    hotspotRight.className = "ldd-hotspot-corner";
    hotspot.append(hotspotLeft, hotspotRight);

    const dockWrap = document.createElement("div");
    dockWrap.id = DOCK_ID;

    const handle = document.createElement("div");
    handle.id = HANDLE_ID;
    handle.innerHTML = '<div class="ldd-wake-pill"></div><div class="ldd-wake-hint">Hover corners or MD Enhancer</div>';

    const dock = document.createElement("div");
    dock.className = "ldd-dock";
    dock.dataset.theme = String(state[DOCK_THEME_KEY] || "glass-light");

    if (LOGO_URL) {
      const logoWrap = document.createElement("div");
      logoWrap.style.display = "flex";
      logoWrap.style.alignItems = "center";
      logoWrap.style.justifyContent = "center";
      logoWrap.style.width = "42px";
      logoWrap.style.height = "42px";
      logoWrap.style.flex = "0 0 42px";
      const logo = document.createElement("img");
      logo.className = "ldd-logo";
      logo.src = LOGO_URL;
      logo.alt = "LDD";
      logoWrap.appendChild(logo);
      dock.appendChild(logoWrap);
    }

    const actions = document.createElement("div");
    actions.className = "ldd-actions";

    const groupedWrap = document.createElement("div");
    groupedWrap.className = "ldd-dock-groups";
    const groupDefs = mini ? DREAMER_DOCK_GROUPS : DOCK_GROUPS;
    const groupedActions = getGroupedActions(mainActions, groupDefs);

    groupedActions.forEach((group, index) => {
      const groupEl = document.createElement("div");
      groupEl.className = "ldd-dock-group";
      groupEl.dataset.groupId = group.id;

      const head = document.createElement("div");
      head.className = "ldd-dock-group-head";
      head.textContent = group.title;

      const groupActions = document.createElement("div");
      groupActions.className = "ldd-dock-group-actions";
      group.items.forEach((item) => groupActions.appendChild(makeIconButton(item.label, item.icon, item.action, item.className || "")));

      groupEl.append(head, groupActions);
      groupedWrap.appendChild(groupEl);

      if (index < groupedActions.length - 1) {
      const divider = document.createElement("div");
      divider.className = "ldd-group-divider";
      divider.textContent = "|";
      groupedWrap.appendChild(divider);
    }
  });

    actions.appendChild(groupedWrap);
    if (!mini) {
      actions.appendChild(makeSettingsBubbleButton());
    }

    if (mini) {
      dock.append(actions);
      dock.classList.add('ldd-mini-dock');
    } else {
      const divider = document.createElement("div");
      divider.className = "ldd-divider";

      const uploadBlock = document.createElement("div");
      uploadBlock.className = "ldd-upload-block";
      const uploadLabel = document.createElement("div");
      uploadLabel.className = "ldd-upload-label";
      uploadLabel.textContent = "Drag & Drop";

      const uploadRow = document.createElement("div");
      uploadRow.className = "ldd-upload-row";

      const toggle = document.createElement("input");
      toggle.type = "checkbox";
      toggle.checked = !!state[MODE_KEY];

      const regularBtn = makeIconButton("Upload Regular", "upload", () => {
        toggle.checked = false;
        setStorage({ [MODE_KEY]: false });
      });

      const toggleWrap = document.createElement("label");
      toggleWrap.className = "ldd-switch";
      const track = document.createElement("span");
      track.className = "ldd-switch-track";
      const thumb = document.createElement("span");
      thumb.className = "ldd-switch-thumb";
      track.appendChild(thumb);
      toggle.addEventListener("change", () => setStorage({ [MODE_KEY]: !!toggle.checked }));
      toggleWrap.append(toggle, track);

      const singleBtn = makeIconButton("Upload All to Single Listing", "files", () => {
        toggle.checked = true;
        setStorage({ [MODE_KEY]: true });
      });

      uploadRow.append(regularBtn, toggleWrap, singleBtn);
      uploadBlock.append(uploadLabel, uploadRow);

      dock.append(actions, divider, uploadBlock);
    }

    dockWrap.append(dock, handle);
    root.append(hotspot, dockWrap);
    document.body.appendChild(root);
    return { root, hotspot, hotspotLeft, hotspotRight, dockWrap, handle };
  }

  function initDockMagnification(dockWrap) {
    const dock = dockWrap?.querySelector?.('.ldd-dock');
    if (!dock) return () => {};

    const buttons = () => Array.from(dock.querySelectorAll('.ldd-icon-btn'));
    const MAX_DIST = 150;
    const MAX_SCALE_BOOST = 0.45;
    const MAX_LIFT = 12;

    function reset() {
      buttons().forEach((button) => {
        button.style.transform = '';
        button.style.marginLeft = '';
        button.style.marginRight = '';
      });
    }

    let animationsEnabled = true;

    areDockAnimationsEnabled().then((enabled) => {
      animationsEnabled = enabled;
      if (!enabled) reset();
    });

    function onMove(e) {
      if (!animationsEnabled) {
        reset();
        return;
      }
      buttons().forEach((button) => {
        const rect = button.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const dist = Math.abs(e.clientX - centerX);
        const t = Math.max(0, 1 - dist / MAX_DIST);
        const eased = 1 - Math.pow(1 - t, 2);
        const scale = 1 + eased * MAX_SCALE_BOOST;
        const lift = eased * MAX_LIFT;
        const spread = eased * 4;
        button.style.transform = `translateY(${-lift}px) scale(${scale})`;
        button.style.marginLeft = `${spread / 2}px`;
        button.style.marginRight = `${spread / 2}px`;
      });
    }

    dock.addEventListener('mousemove', onMove);
    dock.addEventListener('mouseleave', reset);

    const onStorageChange = (changes, area) => {
      if (area !== 'local' || !changes[DOCK_ANIMATIONS_KEY]) return;
      animationsEnabled = changes[DOCK_ANIMATIONS_KEY].newValue !== false;
      if (!animationsEnabled) reset();
    };
    try { chrome.storage.onChanged.addListener(onStorageChange); } catch (e) {}

    return () => {
      dock.removeEventListener('mousemove', onMove);
      dock.removeEventListener('mouseleave', reset);
      try { chrome.storage.onChanged.removeListener(onStorageChange); } catch (e) {}
      reset();
    };
  }

  function initAutoHide(root, hotspot, hotspotLeft, hotspotRight, dockWrap, handle) {
    let hideDelay = getPageType() === "dreamer" ? 60000 : 60000;
    let effectMode = "premium";
    let themeMode = "glass-light";
    let animationsEnabled = true;
    let timer = null;
    let pulseTimer = null;
    let hidden = false;
    let destroyed = false;

    async function refreshSettings() {
      const defaultHideSeconds = 60;
      const stored = await getStorage({ [DOCK_AUTOHIDE_KEY]: defaultHideSeconds, [DOCK_EFFECT_KEY]: "premium", [DOCK_THEME_KEY]: "glass-light", [DOCK_ANIMATIONS_KEY]: true });
      const secs = Number(stored[DOCK_AUTOHIDE_KEY]);
      hideDelay = Number.isFinite(secs) && secs > 0 ? secs * 1000 : 0;
      effectMode = String(stored[DOCK_EFFECT_KEY] || "premium");
      themeMode = String(stored[DOCK_THEME_KEY] || "glass-light");
      animationsEnabled = stored[DOCK_ANIMATIONS_KEY] !== false;
      root.classList.remove("effect-off", "effect-bounce", "effect-premium", "theme-glass-light", "theme-glass-dark", "theme-midnight", "theme-lavender", "theme-sunset", "theme-rainbow", "theme-neon-pink");
      root.classList.add(`effect-${effectMode}`);
      root.classList.add(`theme-${themeMode}`);
      const dockNode = dockWrap.querySelector(".ldd-dock");
      if (dockNode) dockNode.dataset.theme = themeMode;
      applyDockAppearance(root, dockNode, themeMode);
      if (!hidden) scheduleHide();
    }

    function stopPulse() {
      clearTimeout(pulseTimer);
      root.classList.remove("pulsing");
    }

    function startPulse() {
      stopPulse();
      if (effectMode === "off" || !animationsEnabled) return;
      root.classList.add("pulsing");
      pulseTimer = setTimeout(() => {
        root.classList.remove("pulsing");
      }, 5200);
    }

    function show() {
      if (destroyed) return;
      hidden = false;
      stopPulse();
      root.classList.remove("hidden");
      root.classList.add("shown");
      scheduleHide();
    }

    function hide() {
      if (destroyed) return;
      if (hideDelay <= 0) {
        root.classList.remove("hidden");
        root.classList.add("shown");
        return;
      }
      hidden = true;
      root.classList.add("hidden");
      root.classList.remove("shown");
      startPulse();
    }

    function scheduleHide() {
      clearTimeout(timer);
      if (hideDelay <= 0) return;
      timer = setTimeout(() => {
        if (!dockWrap.matches(":hover") && !dockWrap.contains(document.activeElement)) hide();
      }, hideDelay);
    }

    const onHotspotEnter = (event) => { show(); showDockWakeTip(event.currentTarget, "Hover to wake the dock"); };
    const onHandleEnter = () => { show(); showDockWakeTip(handle, "Hover corners or MD Enhancer"); };
    const onHandleClick = () => show();
    const onDockEnter = () => show();
    const onDockLeave = () => scheduleHide();
    const onFocusIn = () => show();
    const onFocusOut = () => scheduleHide();
    const onPointerDown = () => show();
    const onDockActionClicked = (event) => {
      if (event?.detail?.keepDockOpen) {
        show();
        return;
      }
      hide();
    };
    const onEnhancerBubbleEnter = () => show();

    hotspotLeft?.addEventListener("mouseenter", onHotspotEnter);
    hotspotRight?.addEventListener("mouseenter", onHotspotEnter);
    hotspotLeft?.addEventListener("mouseleave", hideDockWakeTip);
    hotspotRight?.addEventListener("mouseleave", hideDockWakeTip);
    handle.addEventListener("mouseenter", onHandleEnter);
    handle.addEventListener("mouseleave", hideDockWakeTip);
    handle.addEventListener("click", onHandleClick);
    dockWrap.addEventListener("mouseenter", onDockEnter);
    dockWrap.addEventListener("mouseleave", onDockLeave);
    dockWrap.addEventListener("focusin", onFocusIn);
    dockWrap.addEventListener("focusout", onFocusOut);
    dockWrap.addEventListener("pointerdown", onPointerDown, true);
    window.addEventListener("ldd-dock-action-clicked", onDockActionClicked);

    const bindEnhancerBubbleHover = () => {
      const bubble = document.getElementById("ldd-sidebar-bubble");
      if (bubble && !bubble.__lddDockWakeBound) {
        bubble.addEventListener("mouseenter", onEnhancerBubbleEnter);
        bubble.__lddDockWakeBound = true;
      }
    };

    const onMouseMove = (e) => {
      const nearBottom = e.clientY >= window.innerHeight - 44;
      const nearLeftCorner = nearBottom && e.clientX <= 92;
      const nearRightCorner = nearBottom && e.clientX >= window.innerWidth - 92;
      if (nearLeftCorner || nearRightCorner) show();
      bindEnhancerBubbleHover();
    };
    const onStorageChange = (changes, area) => {
      if (area !== "local") return;
      if (changes[DOCK_DISABLED_KEY]) {
        if (changes[DOCK_DISABLED_KEY].newValue) {
          nuke();
          try { delete window.__LDD_CLEAN_DOCK_INSTANCE__; } catch (e) {}
        } else {
          window.location.reload();
        }
        return;
      }
      if (changes[DOCK_AUTOHIDE_KEY] || changes[DOCK_EFFECT_KEY] || changes[DOCK_THEME_KEY]) refreshSettings();
    };
    window.addEventListener("mousemove", onMouseMove, { passive: true });
    try { chrome.storage.onChanged.addListener(onStorageChange); } catch (e) {}

    const themeObserver = new MutationObserver(() => {
      const dockNode = dockWrap.querySelector(".ldd-dock");
      if (!dockNode) return;
      applyDockAppearance(root, dockNode, themeMode);
    });
    themeObserver.observe(document.documentElement, { attributes: true, attributeFilter: ["class", "data-theme", "data-color-mode"] });
    if (document.body) themeObserver.observe(document.body, { attributes: true, attributeFilter: ["class", "data-theme", "data-color-mode"] });

    refreshSettings().then(show);

    return () => {
      destroyed = true;
      clearTimeout(timer);
      stopPulse();
      hotspotLeft?.removeEventListener("mouseenter", onHotspotEnter);
      hotspotRight?.removeEventListener("mouseenter", onHotspotEnter);
      hotspotLeft?.removeEventListener("mouseleave", hideDockWakeTip);
      hotspotRight?.removeEventListener("mouseleave", hideDockWakeTip);
      handle.removeEventListener("mouseenter", onHandleEnter);
      handle.removeEventListener("mouseleave", hideDockWakeTip);
      handle.removeEventListener("click", onHandleClick);
      dockWrap.removeEventListener("mouseenter", onDockEnter);
      dockWrap.removeEventListener("mouseleave", onDockLeave);
      dockWrap.removeEventListener("focusin", onFocusIn);
      dockWrap.removeEventListener("focusout", onFocusOut);
      dockWrap.removeEventListener("pointerdown", onPointerDown, true);
      window.removeEventListener("ldd-dock-action-clicked", onDockActionClicked);
      window.removeEventListener("mousemove", onMouseMove, { passive: true });
      const bubble = document.getElementById("ldd-sidebar-bubble");
      if (bubble && bubble.__lddDockWakeBound) {
        bubble.removeEventListener("mouseenter", onEnhancerBubbleEnter);
        delete bubble.__lddDockWakeBound;
      }
      try { chrome.storage.onChanged.removeListener(onStorageChange); } catch (e) {}
      try { themeObserver.disconnect(); } catch (e) {}
    };
  }

  function suppressLegacyTopBar() {
    document.getElementById("ldd-listings-toolbar-center-fixed")?.remove();
    document.getElementById("lddDndModeTool")?.remove();
    document.getElementById("lddHeaderUploadRow")?.remove();
  }

  function initDreamerPromptButton() {
    nuke();
    installDreamerLauncherCapture();
    const BTN_ID = "ldd-dreamer-prompt-manager-btn";
    const existing = document.getElementById(BTN_ID);
    if (existing) existing.remove();

    const style = document.getElementById(STYLE_ID) || document.createElement("style");
    style.id = STYLE_ID;
    const extraCss = `
      #${BTN_ID}{
        display:inline-flex;
        align-items:center;
        justify-content:center;
        gap:6px;
        height:32px;
        padding:0 10px;
        border-radius:10px;
        border:1px solid rgba(15,23,42,.08);
        background:#ffffff;
        color:#334155;
        font-size:12px;
        font-weight:800;
        box-shadow:0 6px 16px rgba(15,23,42,.06);
        cursor:pointer;
        white-space:nowrap;
        pointer-events:auto;
        user-select:none;
      }
      #${BTN_ID}:hover{background:#f8fafc;color:#0f172a;}
      #${BTN_ID}:focus,
      #${BTN_ID}:focus-visible,
      #${BTN_ID}:active{
        outline:none;
        transform:none;
      }
      #${BTN_ID} img{width:14px;height:14px;border-radius:999px;object-fit:cover;}
    `;
    if (!style.textContent.includes(`#${BTN_ID}`)) {
      style.textContent = `${style.textContent || ""}\n${extraCss}`;
      document.head.appendChild(style);
    }

    const tryMount = () => {
      const headerBar = Array.from(document.querySelectorAll('div')).find((el) => {
        const cls = el.className || '';
        const text = el.textContent || '';
        return typeof cls === 'string' && cls.includes('border-b') && text.includes('Dreamer');
      });
      const headerActions = headerBar?.querySelector('.ms-auto.flex.items-center');
      if (!headerActions) return false;
      const existingBtn = document.getElementById(BTN_ID);
      if (existingBtn) existingBtn.remove();
      const btn = document.createElement("div");
      btn.id = BTN_ID;
      btn.setAttribute('role', 'button');
      btn.setAttribute('tabindex', '0');
      btn.innerHTML = `${LOGO_URL ? `<img src="${LOGO_URL}" alt="LDD" />` : ""}<span>Prompt Manager</span>`;
      btn.addEventListener("keydown", (event) => {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          openDreamerTestModal();
        }
      }, true);
      btn.style.marginRight = '12px';
      headerActions.insertBefore(btn, headerActions.firstChild || null);
      return true;
    };

    if (tryMount()) return;
    let tries = 0;
    const timer = setInterval(() => {
      tries += 1;
      if (tryMount() || tries > 30) clearInterval(timer);
    }, 500);
  }

  let cleanupHide = null;
  let cleanupMagnification = null;
  let observer = null;
  let lastRouteKey = `${window.location.origin}${window.location.pathname}`;
  let lastPageType = null;
  let syncScheduled = false;
  let suppressGlobalSyncUntil = 0;
  let dreamerLauncherCaptureInstalled = false;

  function suppressGlobalSyncFor(ms = 180) {
    suppressGlobalSyncUntil = Date.now() + ms;
  }

  function installDreamerLauncherCapture() {
    if (dreamerLauncherCaptureInstalled) return;
    dreamerLauncherCaptureInstalled = true;
    const handler = (event) => {
      const target = event.target;
      if (!(target instanceof Element)) return;
      const launcher = target.closest('#ldd-dreamer-prompt-manager-btn');
      if (!launcher) return;
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation?.();
      window.setTimeout(() => {
        openDreamerTestModal();
      }, 0);
    };
    document.addEventListener('click', handler, true);
    document.addEventListener('pointerdown', handler, true);
  }

  function cleanupMountedUI() {
    suppressGlobalSyncFor();
    cleanupMagnification?.();
    cleanupMagnification = null;
    cleanupHide?.();
    cleanupHide = null;
    observer?.disconnect?.();
    observer = null;
    closeDockDisableConfirm();
    closeDreamerTestModal();
    closeDockPromptModal();
    closeDockThemeModal();
    closeDockSettingsBubble();
    nuke();
  }

  async function syncUIForCurrentPage(force = false) {
    const nextRouteKey = `${window.location.origin}${window.location.pathname}`;
    const pageType = getPageType();
    if (!force && nextRouteKey === lastRouteKey && pageType === lastPageType) return;
    lastRouteKey = nextRouteKey;
    lastPageType = pageType;

    cleanupMountedUI();

    if (pageType === "dreamer") {
      injectStyle();
      const { root, hotspot, hotspotLeft, hotspotRight, dockWrap, handle } = await buildRoot({ mini: true, actionsList: DREAMER_ACTION_ITEMS });
      cleanupMagnification = initDockMagnification(dockWrap);
      cleanupHide = initAutoHide(root, hotspot, hotspotLeft, hotspotRight, dockWrap, handle);
      root.classList.add("shown");
      return;
    }

    if (pageType !== "listings") return;

    const { [DOCK_DISABLED_KEY]: dockDisabled } = await getStorage({ [DOCK_DISABLED_KEY]: false });
    if (dockDisabled) return;

    injectStyle();
    suppressLegacyTopBar();
    const { root, hotspot, hotspotLeft, hotspotRight, dockWrap, handle } = await buildRoot();
    cleanupMagnification = initDockMagnification(dockWrap);
    cleanupHide = initAutoHide(root, hotspot, hotspotLeft, hotspotRight, dockWrap, handle);
    root.classList.add("shown");
    observer = new MutationObserver(() => suppressLegacyTopBar());
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }

  function scheduleSync(force = false) {
    if (!force && Date.now() < suppressGlobalSyncUntil) return;
    if (syncScheduled && !force) return;
    syncScheduled = true;
    setTimeout(() => {
      syncScheduled = false;
      syncUIForCurrentPage(force);
    }, 0);
  }

  function installRouteWatcher() {
    if (window.__LDD_DOCK_ROUTE_WATCHER_INSTALLED__) return;
    window.__LDD_DOCK_ROUTE_WATCHER_INSTALLED__ = true;

    const wrapHistory = (method) => {
      const original = history[method];
      if (typeof original !== "function") return;
      history[method] = function (...args) {
        const result = original.apply(this, args);
        scheduleSync(true);
        return result;
      };
    };

    wrapHistory("pushState");
    wrapHistory("replaceState");
    window.addEventListener("popstate", () => scheduleSync(true));
    window.addEventListener("hashchange", () => scheduleSync(true));
    const bodyObserver = new MutationObserver(() => {
      if (Date.now() < suppressGlobalSyncUntil) return;
      scheduleSync(false);
    });
    if (document.documentElement) {
      bodyObserver.observe(document.documentElement, { childList: true, subtree: true });
    }
  }

  function destroy() {
    cleanupMountedUI();
  }

  window.__LDD_CLEAN_DOCK_INSTANCE__ = { destroy };
  installRouteWatcher();

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => scheduleSync(true), { once: true });
  } else {
    scheduleSync(true);
  }
})();
