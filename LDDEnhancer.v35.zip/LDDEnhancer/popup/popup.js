const DOCK_DISABLED_KEY = "lddDockDisabled";
const DND_RENAME_KEY = "lddDndRenameEnabled";

async function getActiveTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs[0] || null;
}

function setStatus(text, ok) {
  const el = document.getElementById("siteStatus");
  if (!el) return;
  el.textContent = text;
  el.classList.toggle("ok", Boolean(ok));
}

function notify(message, level) {
  const el = document.getElementById("statusMessage");
  if (!el) return;
  el.textContent = message;
  el.className = "status-message" + (level ? " " + level : "");
}

async function refreshSiteStatus() {
  const tab = await getActiveTab();
  const ready = Boolean(tab?.url?.startsWith("https://mydesigns.io/"));
  setStatus(ready ? "MD tab ready" : "Open an MD tab", ready);
}

async function loadToggles() {
  const stored = await chrome.storage.local.get({
    enhancerEnabled: true,
    dropperEnabled: true,
    [DOCK_DISABLED_KEY]: false,
    [DND_RENAME_KEY]: true
  });

  document.getElementById("enhancerEnabled").checked = Boolean(stored.enhancerEnabled);
  document.getElementById("dropperEnabled").checked = Boolean(stored.dropperEnabled);
  document.getElementById("dockEnabled").checked = !Boolean(stored[DOCK_DISABLED_KEY]);
  document.getElementById("dndRenameEnabled").checked = Boolean(stored[DND_RENAME_KEY]);
}

async function setAndRefresh(next, message) {
  await chrome.storage.local.set(next);
  await loadToggles();
  if (message) notify(message);
}

async function initialize() {
  await loadToggles();
  await refreshSiteStatus();

  document.getElementById("enhancerEnabled").addEventListener("change", async (e) => {
    const enabled = Boolean(e.target.checked);
    await setAndRefresh({ enhancerEnabled: enabled }, enabled ? "MD Enhancer enabled." : "MD Enhancer disabled.");
  });

  document.getElementById("dockEnabled").addEventListener("change", async (e) => {
    const enabled = Boolean(e.target.checked);
    await setAndRefresh({ [DOCK_DISABLED_KEY]: !enabled }, enabled ? "Dock enabled." : "Dock disabled.");
  });

  document.getElementById("dropperEnabled").addEventListener("change", async (e) => {
    const enabled = Boolean(e.target.checked);
    await setAndRefresh({ dropperEnabled: enabled }, enabled ? "Drag & Drop enabled." : "Drag & Drop disabled.");
  });

  document.getElementById("dndRenameEnabled").addEventListener("change", async (e) => {
    const enabled = Boolean(e.target.checked);
    await setAndRefresh({ [DND_RENAME_KEY]: enabled }, enabled ? "Auto Rename enabled." : "Auto Rename disabled.");
  });

  document.getElementById("fullEnable").addEventListener("click", async () => {
    await setAndRefresh(
      { enhancerEnabled: true, dropperEnabled: true, [DOCK_DISABLED_KEY]: false, [DND_RENAME_KEY]: true },
      "All tools enabled."
    );
  });

  document.getElementById("fullDisable").addEventListener("click", async () => {
    await setAndRefresh(
      { enhancerEnabled: false, dropperEnabled: false, [DOCK_DISABLED_KEY]: true, [DND_RENAME_KEY]: false },
      "All tools disabled."
    );
  });
}

initialize();
