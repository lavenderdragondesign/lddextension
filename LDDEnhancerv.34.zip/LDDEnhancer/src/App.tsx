import React, { useState } from "react";

const tabs = ["Text", "Image", "Style", "Social", "Export"] as const;
type Tab = typeof tabs[number];

const TabBox = ({ label, active, onClick }: { label: Tab; active: boolean; onClick: () => void; }) => (
  <button
    onClick={onClick}
    className={`aspect-square rounded-xl border text-sm font-semibold flex items-center justify-center transition
      ${active ? "bg-slate-900 text-white border-slate-900" : "bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100"}
    `}
  >
    {label}
  </button>
);

const OptionCard = ({ label, children, full }: any) => (
  <div className={`rounded-xl border border-slate-200 bg-white p-3 flex flex-col gap-2 ${full ? "col-span-2" : ""}`}>
    <div className="text-sm font-medium text-slate-700">{label}</div>
    {children}
  </div>
);

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>("Text");

  return (
    <div className="h-screen flex bg-slate-100">

      <aside className="w-[500px] h-full flex flex-col border-r bg-white">

        <div className="grid grid-cols-5 gap-2 p-3 border-b">
          {tabs.map((t) => (
            <TabBox key={t} label={t} active={activeTab === t} onClick={() => setActiveTab(t)} />
          ))}
        </div>

        <div className="flex-1 overflow-y-auto p-3 flex flex-col gap-3">

          {activeTab === "Text" && (
            <div className="grid grid-cols-2 gap-3">
              <OptionCard label="Font">
                <select className="w-full border rounded px-2 py-1 text-sm">
                  <option>Arial</option>
                </select>
              </OptionCard>

              <OptionCard label="Size">
                <input type="number" className="w-full border rounded px-2 py-1 text-sm" />
              </OptionCard>

              <OptionCard label="Color">
                <input type="color" className="w-full h-8" />
              </OptionCard>

              <OptionCard label="Align">
                <div className="flex gap-2">
                  <button className="flex-1 border rounded py-1">L</button>
                  <button className="flex-1 border rounded py-1">C</button>
                  <button className="flex-1 border rounded py-1">R</button>
                </div>
              </OptionCard>

              <OptionCard label="Opacity" full>
                <input type="range" className="w-full" />
              </OptionCard>
            </div>
          )}

        </div>

        <div className="grid grid-cols-2 gap-2 p-3 border-t">
          <button className="py-2 border rounded text-sm">Preview</button>
          <button className="py-2 bg-indigo-600 text-white rounded text-sm">Export</button>
        </div>

      </aside>

      <main className="flex-1 flex items-center justify-center">
        <div className="w-[600px] h-[800px] bg-white border rounded shadow flex items-center justify-center text-slate-400">
          Canvas Preview
        </div>
      </main>

    </div>
  );
};

export default App;
