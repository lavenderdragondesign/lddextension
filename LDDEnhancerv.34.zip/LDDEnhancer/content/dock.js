(() => {
  const PATH_OK = (() => {
    const origin = window.location.origin || "";
    const path = (window.location.pathname || "").replace(/\/+$/, "");
    return origin === "https://mydesigns.io" && path === "/app/listings";
  })();

  const ROOT_ID = "ldd-clean-dock-root";
  const DOCK_ID = "ldd-clean-dock";
  const STYLE_ID = "ldd-clean-dock-style";
  const HOTSPOT_ID = "ldd-clean-dock-hotspot";
  const HOTSPOT_LEFT_ID = "ldd-clean-dock-hotspot-left";
  const HOTSPOT_RIGHT_ID = "ldd-clean-dock-hotspot-right";
  const HANDLE_ID = "ldd-clean-dock-handle";
  const TIP_ID = "ldd-clean-dock-tip";
  const MODE_KEY = "lddDropSingleListing";
  const DOCK_AUTOHIDE_KEY = "lddDockAutohideSeconds";
  const DOCK_EFFECT_KEY = "lddDockChevronEffect";
  const DOCK_THEME_KEY = "lddDockTheme";

  function nuke() {
    document.getElementById(ROOT_ID)?.remove();
    document.getElementById(STYLE_ID)?.remove();
    document.getElementById(TIP_ID)?.remove();
  }

  if (!PATH_OK) {
    nuke();
    try { delete window.__LDD_CLEAN_DOCK_INSTANCE__; } catch (e) {}
    return;
  }

  if (window.__LDD_CLEAN_DOCK_INSTANCE__?.destroy) {
    try { window.__LDD_CLEAN_DOCK_INSTANCE__.destroy(); } catch (e) {}
  }

  const LOGO_URL = (() => {
    try { return chrome.runtime.getURL("assets/logo.png"); } catch (e) { return ""; }
  })();

  const ACTIONS = [
    ["Image Mockups", "image", () => triggerMenuAction("Image Mockups")],
    ["Video Mockups", "video", () => triggerMenuAction("Video Mockups")],
    ["Vision AI", "sparkles", () => triggerMenuAction("Vision AI")],
    ["Remove Background", "erase", () => triggerMenuAction("Remove Background")],
    ["Upscale", "upscale", () => triggerMenuAction("Upscale Image")],
    ["Vectorize", "shapes", () => triggerMenuAction("Vectorize Image")],
    ["Canvas", "palette", () => triggerMenuAction("Canvas")],
    ["Dream AI", "wand", () => { window.location.href = "https://mydesigns.io/app/dreamer"; }],
    ["Color Overlay", "droplets", () => triggerMenuAction("Color Overlay")],
    ["Pattern Overlay", "pattern", () => triggerMenuAction("Pattern Overlay")],
    ["Edit in Bulk", "layers", () => triggerMenuAction("Edit in Bulk")],
    ["Compressor", "compressor", () => window.LDDCompressor?.toggle?.()],
    ["Resizer", "resizer", () => window.LDDResizer?.toggle?.()],
    ["Download Files", "download", () => triggerMenuAction("Download")],
    ["Move to Collection", "foldermove", () => triggerMenuAction(["Move to Collection", "Move to collection"])],
    ["Duplicate Listings", "copy", () => triggerMenuAction(["Duplicate Listing", "Duplicate Listings"])],
    ["Change File Slot", "swap", () => triggerMenuAction(["Change file slot", "Change File Slot"])],
    ["Delete Listings", "trash", () => triggerMenuAction(["Delete Listing", "Delete Listings"]), "ldd-danger-btn"],
  ];

  function icon(name) {
    const map = {
      image:'<svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><path d="m21 15-5-5L5 21"></path></svg>',
      video:'<svg viewBox="0 0 24 24"><path d="m22 8-6 4 6 4V8Z"></path><rect x="2" y="6" width="14" height="12" rx="2"></rect></svg>',
      sparkles:'<svg viewBox="0 0 24 24"><path d="M9.937 15.5A2 2 0 0 0 8.5 14.063L6 13.5l2.5-.563A2 2 0 0 0 9.937 11.5L10.5 9l.563 2.5A2 2 0 0 0 12.5 12.937L15 13.5l-2.5.563A2 2 0 0 0 11.063 15.5L10.5 18l-.563-2.5Z"></path><path d="M20 3v4"></path><path d="M22 5h-4"></path><path d="M4 17v2"></path><path d="M5 18H3"></path></svg>',
      erase:'<svg viewBox="0 0 24 24"><path d="m7 21 9.586-9.586a2 2 0 0 0 0-2.828l-3.172-3.172a2 2 0 0 0-2.828 0L2 14v3a4 4 0 0 0 4 4Z"></path><path d="M22 21H7"></path><path d="m5 11 8 8"></path></svg>',
      upscale:'<svg viewBox="0 0 24 24"><path d="M16 3h5v5"></path><path d="m21 3-7 7"></path><path d="M8 21H3v-5"></path><path d="m3 21 7-7"></path></svg>',
      shapes:'<svg viewBox="0 0 24 24"><path d="M14.5 4.5 18 8l-3.5 3.5L11 8l3.5-3.5Z"></path><path d="M6 5h4v4H6z"></path><circle cx="7.5" cy="16.5" r="2.5"></circle><path d="M16 14h5v5h-5z"></path></svg>',
      palette:'<svg viewBox="0 0 24 24"><path d="M12 22a1 1 0 0 0 1-1v-1a2 2 0 0 1 2-2h1a4 4 0 0 0 0-8 8 8 0 1 0-8 8h1a2 2 0 0 1 2 2v1a1 1 0 0 0 1 1Z"></path><circle cx="6" cy="11" r="1"></circle><circle cx="8.5" cy="7.5" r="1"></circle><circle cx="13.5" cy="7.5" r="1"></circle><circle cx="16" cy="11" r="1"></circle></svg>',
      settings:'<svg viewBox="0 0 24 24"><path d="M12 3a2 2 0 0 1 2 2v.28a7.75 7.75 0 0 1 1.88.78l.2-.2a2 2 0 1 1 2.83 2.83l-.2.2c.34.6.61 1.24.78 1.88H19a2 2 0 1 1 0 4h-.28a7.75 7.75 0 0 1-.78 1.88l.2.2a2 2 0 1 1-2.83 2.83l-.2-.2a7.75 7.75 0 0 1-1.88.78V19a2 2 0 1 1-4 0v-.28a7.75 7.75 0 0 1-1.88-.78l-.2.2a2 2 0 1 1-2.83-2.83l.2-.2A7.75 7.75 0 0 1 5.28 13H5a2 2 0 1 1 0-4h.28c.17-.64.44-1.28.78-1.88l-.2-.2A2 2 0 1 1 8.69 4.1l.2.2c.6-.34 1.24-.61 1.88-.78V5a2 2 0 0 1 2-2Z"></path><circle cx="12" cy="12" r="3"></circle></svg>',
      upload:'<svg viewBox="0 0 24 24"><path d="M12 3v12"></path><path d="m7 8 5-5 5 5"></path><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path></svg>',
      files:'<svg viewBox="0 0 24 24"><path d="M20 7h-7a2 2 0 0 1-2-2V2"></path><path d="M9 18a2 2 0 0 0 2 2h9V7l-5-5H5a2 2 0 0 0-2 2v7"></path><path d="M3 15h6"></path><path d="M6 12v6"></path></svg>',
      wand:'<svg viewBox="0 0 24 24"><path d="M15 4V2"></path><path d="M15 16v-2"></path><path d="M8 9h2"></path><path d="M20 9h2"></path><path d="M17.8 11.8 19 13"></path><path d="M15 9h0"></path><path d="M17.8 6.2 19 5"></path><path d="m3 21-9-9"></path><path d="M12.2 6.2 11 5"></path></svg>',
      droplets:'<svg viewBox="0 0 24 24"><path d="M7 16a5 5 0 0 0 10 0c0-2.5-2.5-5.5-5-9-2.5 3.5-5 6.5-5 9Z"></path><path d="M12 2v2"></path></svg>',
      pattern:'<svg viewBox="0 0 24 24"><circle cx="7" cy="7" r="2"></circle><circle cx="17" cy="7" r="2"></circle><circle cx="7" cy="17" r="2"></circle><circle cx="17" cy="17" r="2"></circle><path d="M9 7h6"></path><path d="M7 9v6"></path><path d="M15 17h2"></path><path d="M17 15v2"></path></svg>',
      layers:'<svg viewBox="0 0 24 24"><path d="m12 3 9 4.5-9 4.5-9-4.5L12 3Z"></path><path d="m3 12 9 4.5 9-4.5"></path><path d="m3 16.5 9 4.5 9-4.5"></path></svg>',
      compressor:'<svg viewBox="0 0 24 24"><path d="M4 8h16"></path><path d="M4 16h16"></path><path d="M8 4v4"></path><path d="M16 16v4"></path><path d="M12 9v6"></path></svg>',
      resizer:'<svg viewBox="0 0 24 24"><path d="M21 3h-6"></path><path d="M21 9V3"></path><path d="m14 10 7-7"></path><path d="M3 15h6"></path><path d="M3 21v-6"></path><path d="m10 14-7 7"></path></svg>',
      download:'<svg viewBox="0 0 24 24"><path d="M12 3v12"></path><path d="m7 10 5 5 5-5"></path><path d="M5 21h14"></path></svg>',
      foldermove:'<svg viewBox="0 0 24 24"><path d="M3 7a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7z"></path><path d="M8 12h8"></path><path d="m13 9 3 3-3 3"></path></svg>',
      copy:'<svg viewBox="0 0 24 24"><rect x="9" y="9" width="13" height="13" rx="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>',
      swap:'<svg viewBox="0 0 24 24"><path d="M7 7h11"></path><path d="m13 3 5 4-5 4"></path><path d="M17 17H6"></path><path d="m11 21-5-4 5-4"></path></svg>',
      trash:'<svg viewBox="0 0 24 24"><path d="M3 6h18"></path><path d="M8 6V4h8v2"></path><path d="m19 6-1 14H6L5 6"></path><path d="M10 11v6"></path><path d="M14 11v6"></path></svg>'
    };
    return map[name] || map.image;
  }

  function norm(value) {
    return (value || "").replace(/\s+/g, " ").trim().toLowerCase();
  }

  function getStorage(defaults) {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get(defaults, (result) => resolve(result || defaults));
      } catch (e) {
        resolve(defaults);
      }
    });
  }

  function setStorage(obj) {
    try { chrome.storage.local.set(obj); } catch (e) {}
  }

  function findChooseButton() {
    return Array.from(document.querySelectorAll("button")).find((button) => {
      const text = norm(button.innerText || button.textContent || "");
      return text === "choose action" || text.includes("choose action");
    }) || null;
  }

  function openChooseActionMenu() {
    const chooseButton = findChooseButton();
    if (!chooseButton) return false;
    chooseButton.click();
    return true;
  }

  function getActionButtons() {
    const labels = [
      "image mockups",
      "video mockups",
      "vision ai",
      "edit in bulk",
      "color overlay",
      "pattern overlay",
      "remove background",
      "upscale image",
      "vectorize image",
      "canvas",
      "delete listing",
      "delete listings",
      "move to collection",
      "duplicate listing",
      "duplicate listings",
      "change file slot",
      "download"
    ];

    return Array.from(document.querySelectorAll("button")).filter((button) => {
      const text = norm(button.innerText || button.textContent || "");
      if (!text || text.includes("choose action")) return false;

      const looksLikeDropdownAction =
        button.className.includes("min-w-[230px]") ||
        button.closest("li.min-w-32") ||
        button.closest("div.absolute") ||
        button.closest('div[style*="position: absolute"]');

      return looksLikeDropdownAction && labels.some((label) => text.includes(label));
    });
  }

  function clickActionButton(labels) {
    const wanted = (Array.isArray(labels) ? labels : [labels]).map((label) => norm(label));
    const buttons = getActionButtons();

    for (const button of buttons) {
      const spans = Array.from(button.querySelectorAll("span"));
      for (const span of spans) {
        if (wanted.includes(norm(span.textContent || ""))) {
          button.click();
          return true;
        }
      }
    }

    for (const button of buttons) {
      const text = norm(button.innerText || button.textContent || "");
      if (wanted.includes(text)) {
        button.click();
        return true;
      }
    }

    for (const button of buttons) {
      const text = norm(button.innerText || button.textContent || "");
      if (wanted.some((wantedLabel) => text.includes(wantedLabel))) {
        button.click();
        return true;
      }
    }

    return false;
  }

  function triggerMenuAction(labels) {
    if (!openChooseActionMenu()) return;

    let tries = 0;
    const timerId = window.setInterval(() => {
      tries += 1;
      const clicked = clickActionButton(labels);
      if (clicked || tries > 30) {
        window.clearInterval(timerId);
      }
    }, 160);
  }

  function openEnhancerSettings() {
    const enhancer = window.LDDEnhancer;
    enhancer?.enable?.();
    enhancer?.open?.();
    window.dispatchEvent(new CustomEvent("ldd-enhancer-toggle"));
    setTimeout(() => {
      const settingsTab = document.querySelector('[data-tab="settings"]');
      settingsTab?.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));
    }, 220);
  }

  function injectStyle() {
    document.getElementById(STYLE_ID)?.remove();
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      #${ROOT_ID}{
        position:fixed;
        left:0;
        right:0;
        bottom:0;
        z-index:999999;
        pointer-events:none;
        font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,sans-serif;
      }
      #${HOTSPOT_ID}{
        position:fixed;
        left:0;
        right:0;
        bottom:0;
        height:44px;
        z-index:999999;
        pointer-events:none;
        background:transparent;
      }
      #${HOTSPOT_ID} .ldd-hotspot-corner{
        position:absolute;
        bottom:0;
        width:92px;
        height:44px;
        pointer-events:auto;
        background:transparent;
      }
      #${HOTSPOT_LEFT_ID}{left:0;}
      #${HOTSPOT_RIGHT_ID}{right:0;}
      #${HANDLE_ID}{
        position:absolute;
        left:50%;
        bottom:-12px;
        transform:translateX(-50%);
        z-index:1000003;
        width:74px;
        height:26px;
        border-radius:999px;
        background:rgba(15,23,42,.94);
        border:1px solid rgba(255,255,255,.16);
        box-shadow:0 10px 26px rgba(15,23,42,.30), 0 0 0 1px rgba(255,255,255,.05) inset;
        display:flex;
        align-items:center;
        justify-content:center;
        pointer-events:none;
        opacity:0;
        transition:opacity .18s ease, transform .18s ease, box-shadow .18s ease, background .18s ease;
      }
      #${HANDLE_ID} .ldd-wake-pill{
        width:34px;
        height:5px;
        border-radius:999px;
        background:rgba(255,255,255,.92);
        box-shadow:0 0 14px rgba(255,255,255,.26);
      }

#${HANDLE_ID} .ldd-wake-hint{
  position:absolute;
  bottom:100%;
  left:50%;
  transform:translate(-50%, -6px);
  padding:6px 10px;
  border-radius:999px;
  background:rgba(15,23,42,.92);
  color:#f8fafc;
  font-size:10px;
  font-weight:700;
  letter-spacing:.01em;
  white-space:nowrap;
  box-shadow:0 10px 24px rgba(15,23,42,.24);
  opacity:0;
  pointer-events:none;
  transition:opacity .18s ease, transform .18s ease;
}
#${ROOT_ID}.hidden #${HANDLE_ID}:hover .ldd-wake-hint,
#${ROOT_ID}.hidden #${HOTSPOT_LEFT_ID}:hover ~ #${DOCK_ID} #${HANDLE_ID} .ldd-wake-hint,
#${ROOT_ID}.hidden #${HOTSPOT_RIGHT_ID}:hover ~ #${DOCK_ID} #${HANDLE_ID} .ldd-wake-hint{
  opacity:1;
  transform:translate(-50%, -10px);
}
      #${ROOT_ID}.theme-clean #${HANDLE_ID}{background:rgba(15,23,42,.92);}
      #${ROOT_ID}.theme-midnight #${HANDLE_ID}{background:rgba(2,6,23,.96);}
      #${ROOT_ID}.theme-lavender #${HANDLE_ID}{background:rgba(76,29,149,.94);}
      #${ROOT_ID}.theme-neon #${HANDLE_ID}{background:rgba(8,12,24,.96); border-color:rgba(56,189,248,.28);}
      #${DOCK_ID}{
        position:fixed;
        left:50vw !important;
        right:auto !important;
        bottom:10px;
        width:max-content;
        max-width:calc(100vw - 24px);
        margin:0 !important;
        transform:translate3d(-50%,0,0);
        transition:opacity .22s ease, box-shadow .18s ease, transform .22s ease;
        opacity:.98;
        pointer-events:auto;
        z-index:1000002;
      }
      #${ROOT_ID}.hidden #${DOCK_ID}{
        opacity:.92;
        transform:translate3d(-50%,66px,0);
      }
      #${ROOT_ID}.hidden #${HANDLE_ID}{
        opacity:1;
        pointer-events:auto;
      }
      #${ROOT_ID}.hidden.pulsing.effect-bounce #${HANDLE_ID}{
        animation:lddDockBounce 1.1s cubic-bezier(.22,1,.36,1) 5;
      }
      #${ROOT_ID}.hidden.pulsing.effect-premium #${HANDLE_ID}{
        animation:lddDockBounceGlow 1.15s cubic-bezier(.22,1,.36,1) 5;
      }
      #${ROOT_ID}.hidden.effect-premium #${HANDLE_ID}{
        overflow:visible;
      }
      #${ROOT_ID}.hidden.effect-premium #${HANDLE_ID}::after{
        content:"";
        position:absolute;
        inset:auto 6px -6px;
        height:12px;
        border-radius:999px;
        background:radial-gradient(ellipse at center, rgba(99,102,241,.30) 0%, rgba(99,102,241,.16) 45%, rgba(99,102,241,0) 82%);
        opacity:0;
        filter:blur(4px);
        transform:translateY(0) scale(.75);
        pointer-events:none;
      }
      #${ROOT_ID}.hidden.pulsing.effect-premium #${HANDLE_ID}::after{
        animation:lddDockGlowTrail 1.15s cubic-bezier(.22,1,.36,1) 5;
      }
      @keyframes lddDockBounce{
        0%,100%{transform:translateX(-50%) translateY(0) scale(1); box-shadow:0 8px 20px rgba(15,23,42,.16);}
        35%{transform:translateX(-50%) translateY(-8px) scale(1.06); box-shadow:0 14px 24px rgba(15,23,42,.2);}
        65%{transform:translateX(-50%) translateY(0) scale(.98); box-shadow:0 8px 18px rgba(15,23,42,.14);}
      }
      @keyframes lddDockBounceGlow{
        0%,100%{transform:translateX(-50%) translateY(0) scale(1); box-shadow:0 8px 20px rgba(15,23,42,.16), 0 0 0 rgba(99,102,241,0);}
        35%{transform:translateX(-50%) translateY(-9px) scale(1.08); box-shadow:0 16px 28px rgba(15,23,42,.22), 0 0 22px rgba(99,102,241,.18);}
        65%{transform:translateX(-50%) translateY(0) scale(.985); box-shadow:0 8px 18px rgba(15,23,42,.14), 0 0 10px rgba(99,102,241,.10);}
      }
      @keyframes lddDockGlowTrail{
        0%,100%{opacity:0; transform:translateY(0) scale(.75);}
        30%{opacity:.9; transform:translateY(1px) scale(1.15);}
        65%{opacity:.35; transform:translateY(0) scale(.92);}
      }
      #${DOCK_ID} .ldd-dock{
        display:flex;
        align-items:center;
        gap:12px;
        padding:10px 14px;
        border-radius:999px;
        background:rgba(255,255,255,.97);
        border:1px solid rgba(15,23,42,.08);
        box-shadow:0 12px 30px rgba(15,23,42,.18),0 2px 8px rgba(15,23,42,.06);
        backdrop-filter:blur(10px);
      }
      #${ROOT_ID}.theme-glass #${DOCK_ID} .ldd-dock{
        background:linear-gradient(180deg, rgba(255,255,255,.92), rgba(248,250,252,.86));
        border:1px solid rgba(255,255,255,.92);
        box-shadow:0 18px 40px rgba(15,23,42,.16), inset 0 1px 0 rgba(255,255,255,.84);
        backdrop-filter:blur(16px) saturate(145%);
      }
      #${ROOT_ID}.theme-neon #${DOCK_ID} .ldd-dock{
        background:linear-gradient(180deg, rgba(10,14,28,.96), rgba(15,23,42,.92));
        border:1px solid rgba(56,189,248,.34);
        box-shadow:0 18px 44px rgba(2,6,23,.44), 0 0 0 1px rgba(56,189,248,.10) inset, 0 0 24px rgba(168,85,247,.14);
        backdrop-filter:blur(12px) saturate(150%);
      }
      #${ROOT_ID}.theme-neon #${DOCK_ID} .ldd-btn,
      #${ROOT_ID}.theme-neon #${DOCK_ID} .ldd-upload-label,
      #${ROOT_ID}.theme-neon #${DOCK_ID} .ldd-switch{color:#e2e8f0;}
      #${ROOT_ID}.theme-neon #${DOCK_ID} .ldd-btn svg{stroke:#f8fafc;}
      #${ROOT_ID}.theme-neon #${DOCK_ID} .ldd-divider{background:rgba(56,189,248,.22);}
      #${ROOT_ID}.theme-neon #${DOCK_ID} .ldd-icon-btn:hover{background:rgba(56,189,248,.10);box-shadow:0 8px 18px rgba(56,189,248,.14), 0 0 18px rgba(168,85,247,.10);}
      #${ROOT_ID}.theme-midnight #${DOCK_ID} .ldd-dock{
        background:linear-gradient(180deg, rgba(15,23,42,.96), rgba(15,23,42,.88));
        border:1px solid rgba(99,102,241,.26);
        box-shadow:0 18px 44px rgba(2,6,23,.42), 0 0 0 1px rgba(99,102,241,.08) inset;
        backdrop-filter:blur(10px);
      }
      #${ROOT_ID}.theme-midnight #${DOCK_ID} .ldd-btn,
      #${ROOT_ID}.theme-midnight #${DOCK_ID} .ldd-upload-label,
      #${ROOT_ID}.theme-midnight #${DOCK_ID} .ldd-switch{color:#e5e7eb;}
      #${ROOT_ID}.theme-midnight #${DOCK_ID} .ldd-btn svg{stroke:#f8fafc;}
      #${ROOT_ID}.theme-midnight #${DOCK_ID} .ldd-divider{background:rgba(148,163,184,.28);}
      #${ROOT_ID}.theme-clean #${DOCK_ID} .ldd-dock{
        background:#ffffff;
        border:1px solid rgba(15,23,42,.08);
        box-shadow:0 10px 24px rgba(15,23,42,.10), 0 1px 2px rgba(15,23,42,.04);
        backdrop-filter:none;
      }
      #${ROOT_ID}.theme-lavender #${DOCK_ID} .ldd-dock{
        background:linear-gradient(180deg, rgba(124,58,237,.16), rgba(255,255,255,.92));
        border:1px solid rgba(124,58,237,.20);
        box-shadow:0 18px 40px rgba(91,33,182,.16), inset 0 1px 0 rgba(255,255,255,.28);
        backdrop-filter:blur(12px) saturate(130%);
      }
      #${ROOT_ID}.theme-lavender #${DOCK_ID} .ldd-btn:hover{box-shadow:0 8px 20px rgba(124,58,237,.16);}
      
#${ROOT_ID}.theme-sunset #${HANDLE_ID}{
  background:rgba(124,45,18,.94);
  border-color:rgba(251,191,36,.26);
}
#${ROOT_ID}.theme-obsidian #${HANDLE_ID}{
  background:rgba(3,7,18,.96);
  border-color:rgba(148,163,184,.22);
}
#${ROOT_ID}.theme-rose #${HANDLE_ID}{
  background:rgba(136,19,55,.94);
  border-color:rgba(244,114,182,.26);
}
#${ROOT_ID}.theme-sunset #${DOCK_ID} .ldd-dock{
  background:linear-gradient(180deg, rgba(255,247,237,.96), rgba(254,215,170,.88));
  border:1px solid rgba(251,146,60,.28);
  box-shadow:0 18px 40px rgba(154,52,18,.18), inset 0 1px 0 rgba(255,255,255,.72);
  backdrop-filter:blur(10px) saturate(125%);
}
#${ROOT_ID}.theme-sunset #${DOCK_ID} .ldd-icon-btn:hover{
  background:rgba(251,146,60,.12);
  box-shadow:0 8px 18px rgba(249,115,22,.18);
}
#${ROOT_ID}.theme-obsidian #${DOCK_ID} .ldd-dock{
  background:linear-gradient(180deg, rgba(2,6,23,.97), rgba(15,23,42,.92));
  border:1px solid rgba(148,163,184,.18);
  box-shadow:0 18px 44px rgba(2,6,23,.48), inset 0 1px 0 rgba(255,255,255,.04);
  backdrop-filter:blur(10px) saturate(110%);
}
#${ROOT_ID}.theme-obsidian #${DOCK_ID} .ldd-btn,
#${ROOT_ID}.theme-obsidian #${DOCK_ID} .ldd-upload-label,
#${ROOT_ID}.theme-obsidian #${DOCK_ID} .ldd-switch{color:#e5e7eb;}
#${ROOT_ID}.theme-obsidian #${DOCK_ID} .ldd-btn svg{stroke:#f8fafc;}
#${ROOT_ID}.theme-obsidian #${DOCK_ID} .ldd-divider{background:rgba(148,163,184,.22);}
#${ROOT_ID}.theme-obsidian #${DOCK_ID} .ldd-icon-btn:hover{
  background:rgba(148,163,184,.10);
  box-shadow:0 8px 18px rgba(15,23,42,.24);
}
#${ROOT_ID}.theme-rose #${DOCK_ID} .ldd-dock{
  background:linear-gradient(180deg, rgba(255,241,242,.98), rgba(251,207,232,.9));
  border:1px solid rgba(244,114,182,.24);
  box-shadow:0 18px 40px rgba(157,23,77,.16), inset 0 1px 0 rgba(255,255,255,.76);
  backdrop-filter:blur(12px) saturate(130%);
}
#${ROOT_ID}.theme-rose #${DOCK_ID} .ldd-icon-btn:hover{
  background:rgba(244,114,182,.12);
  box-shadow:0 8px 18px rgba(244,114,182,.18);
}
#${DOCK_ID} .ldd-logo{
        width:32px;height:32px;border-radius:999px;object-fit:cover;display:block;background:#fff;
        border:1px solid rgba(15,23,42,.08);box-shadow:0 4px 10px rgba(15,23,42,.08);
      }
      #${DOCK_ID} .ldd-actions,#${DOCK_ID} .ldd-upload-row{display:flex;align-items:center;gap:6px;}
      #${DOCK_ID} .ldd-icon-btn{
        width:42px;height:42px;border:0;border-radius:12px;background:transparent;color:#334155;
        display:inline-flex;align-items:center;justify-content:center;cursor:pointer;padding:0;
        transition:transform .16s ease, background .16s ease, color .16s ease, box-shadow .16s ease;
      }
      #${DOCK_ID} .ldd-icon-btn:hover{
        background:#f8fafc;color:#111827;transform:translateY(-4px) scale(1.08);box-shadow:0 6px 16px rgba(15,23,42,.12);
      }
      #${DOCK_ID} .ldd-icon-btn svg{width:20px;height:20px;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;}
      #${DOCK_ID} .ldd-divider{width:1px;height:38px;background:rgba(15,23,42,.08);margin:0 2px;}
      #${DOCK_ID} .ldd-upload-block{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;min-height:42px;padding-right:2px;}
      #${DOCK_ID} .ldd-upload-label{font-size:10px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;color:#94a3b8;line-height:1;white-space:nowrap;text-align:center;width:100%;}
      #${DOCK_ID} .ldd-switch{position:relative;width:42px;height:22px;display:inline-flex;align-items:center;justify-content:center;}
      #${DOCK_ID} .ldd-switch input{position:absolute;inset:0;opacity:0;cursor:pointer;margin:0;}
      #${DOCK_ID} .ldd-switch-track{position:absolute;inset:0;border-radius:999px;background:#dbeafe;transition:background .16s ease;}
      #${DOCK_ID} .ldd-switch-thumb{position:absolute;top:2px;left:2px;width:18px;height:18px;border-radius:999px;background:#fff;box-shadow:0 1px 4px rgba(15,23,42,.18);transition:transform .16s ease;}
      #${DOCK_ID} .ldd-switch input:checked + .ldd-switch-track{background:#c7d2fe;}
      #${DOCK_ID} .ldd-switch input:checked + .ldd-switch-track .ldd-switch-thumb{transform:translateX(20px);}
      #${DOCK_ID} .ldd-settings-btn{background:#f8fafc;color:#475569;}
      #${DOCK_ID} .ldd-settings-btn:hover{background:#eef2ff;color:#312e81;}
      #${DOCK_ID} .ldd-danger-btn{color:#dc2626;}
      #${DOCK_ID} .ldd-danger-btn:hover{background:#fef2f2;color:#b91c1c;box-shadow:0 6px 16px rgba(220,38,38,.16);}
      #${TIP_ID}{
        position:fixed;z-index:1000004;pointer-events:none;opacity:0;transform:translateY(4px);
        transition:opacity .14s ease,transform .14s ease;background:#fff;border:1px solid rgba(15,23,42,.08);
        box-shadow:0 10px 28px rgba(15,23,42,.14);border-radius:12px;padding:8px 10px;font-size:12px;font-weight:600;color:#334155;white-space:nowrap;
      }
      #${TIP_ID}.show{opacity:1;transform:translateY(0);}
    `;
    document.head.appendChild(style);
  }

  function getTipEl() {
    let tip = document.getElementById(TIP_ID);
    if (!tip) {
      tip = document.createElement("div");
      tip.id = TIP_ID;
      document.documentElement.appendChild(tip);
    }
    return tip;
  }

  function attachTip(el, text) {
    let showTimer = null;
    let hideTimer = null;
    el.addEventListener("mouseenter", () => {
      clearTimeout(hideTimer);
      showTimer = setTimeout(() => {
        const tip = getTipEl();
        tip.textContent = text;
        const rect = el.getBoundingClientRect();
        tip.style.left = `${rect.left + rect.width / 2}px`;
        tip.style.top = `${rect.top - 10}px`;
        tip.style.transform = "translate(-50%, -100%)";
        tip.classList.add("show");
      }, 100);
    });
    el.addEventListener("mouseleave", () => {
      clearTimeout(showTimer);
      hideTimer = setTimeout(() => getTipEl().classList.remove("show"), 40);
    });
  }

  function makeIconButton(tipText, svgName, onClick, className = "") {
    const b = document.createElement("button");
    b.className = `ldd-icon-btn ${className}`.trim();
    b.type = "button";
    b.innerHTML = icon(svgName);
    b.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      onClick();
      window.dispatchEvent(new CustomEvent("ldd-dock-action-clicked", { detail: { tipText, svgName } }));
    });
    attachTip(b, tipText);
    return b;
  }

  async function buildRoot() {
    const state = await getStorage({ [MODE_KEY]: true, [DOCK_AUTOHIDE_KEY]: 10, [DOCK_EFFECT_KEY]: "premium", [DOCK_THEME_KEY]: "glass" });
    const root = document.createElement("div");
    root.id = ROOT_ID;

    const hotspot = document.createElement("div");
    hotspot.id = HOTSPOT_ID;
    const hotspotLeft = document.createElement("div");
    hotspotLeft.id = HOTSPOT_LEFT_ID;
    hotspotLeft.className = "ldd-hotspot-corner";
    const hotspotRight = document.createElement("div");
    hotspotRight.id = HOTSPOT_RIGHT_ID;
    hotspotRight.className = "ldd-hotspot-corner";
    hotspot.append(hotspotLeft, hotspotRight);

    const dockWrap = document.createElement("div");
    dockWrap.id = DOCK_ID;

    const handle = document.createElement("div");
    handle.id = HANDLE_ID;
    handle.innerHTML = '<div class="ldd-wake-pill"></div><div class="ldd-wake-hint">Hover corners or MD Enhancer</div>';

    const dock = document.createElement("div");
    dock.className = "ldd-dock";
    dock.dataset.theme = String(state[DOCK_THEME_KEY] || "glass");

    if (LOGO_URL) {
      const logoWrap = document.createElement("div");
      logoWrap.style.display = "flex";
      logoWrap.style.alignItems = "center";
      logoWrap.style.justifyContent = "center";
      logoWrap.style.width = "42px";
      logoWrap.style.height = "42px";
      logoWrap.style.flex = "0 0 42px";
      const logo = document.createElement("img");
      logo.className = "ldd-logo";
      logo.src = LOGO_URL;
      logo.alt = "LDD";
      logoWrap.appendChild(logo);
      dock.appendChild(logoWrap);
    }

    const actions = document.createElement("div");
    actions.className = "ldd-actions";
    ACTIONS.forEach(([tip, svg, fn, className = ""]) => actions.appendChild(makeIconButton(tip, svg, fn, className)));
    actions.appendChild(makeIconButton("Settings", "settings", openEnhancerSettings, "ldd-settings-btn"));

    const divider = document.createElement("div");
    divider.className = "ldd-divider";

    const uploadBlock = document.createElement("div");
    uploadBlock.className = "ldd-upload-block";
    const uploadLabel = document.createElement("div");
    uploadLabel.className = "ldd-upload-label";
    uploadLabel.textContent = "Drag & Drop";

    const uploadRow = document.createElement("div");
    uploadRow.className = "ldd-upload-row";

    const toggle = document.createElement("input");
    toggle.type = "checkbox";
    toggle.checked = !!state[MODE_KEY];

    const regularBtn = makeIconButton("Upload Regular", "upload", () => {
      toggle.checked = false;
      setStorage({ [MODE_KEY]: false });
    });

    const toggleWrap = document.createElement("label");
    toggleWrap.className = "ldd-switch";
    const track = document.createElement("span");
    track.className = "ldd-switch-track";
    const thumb = document.createElement("span");
    thumb.className = "ldd-switch-thumb";
    track.appendChild(thumb);
    toggle.addEventListener("change", () => setStorage({ [MODE_KEY]: !!toggle.checked }));
    toggleWrap.append(toggle, track);

    const singleBtn = makeIconButton("Upload to Single Listing", "files", () => {
      toggle.checked = true;
      setStorage({ [MODE_KEY]: true });
    });

    uploadRow.append(regularBtn, toggleWrap, singleBtn);
    uploadBlock.append(uploadLabel, uploadRow);

    dock.append(actions, divider, uploadBlock);
    dockWrap.append(dock, handle);
    root.append(hotspot, dockWrap);
    document.body.appendChild(root);
    return { root, hotspot, hotspotLeft, hotspotRight, dockWrap, handle };
  }

  function initAutoHide(root, hotspot, hotspotLeft, hotspotRight, dockWrap, handle) {
    let hideDelay = 20000;
    let effectMode = "premium";
    let themeMode = "glass";
    let timer = null;
    let pulseTimer = null;
    let hidden = false;
    let destroyed = false;

    async function refreshSettings() {
      const stored = await getStorage({ [DOCK_AUTOHIDE_KEY]: 10, [DOCK_EFFECT_KEY]: "premium", [DOCK_THEME_KEY]: "glass" });
      const secs = Number(stored[DOCK_AUTOHIDE_KEY]);
      hideDelay = Number.isFinite(secs) && secs > 0 ? secs * 1000 : 0;
      effectMode = String(stored[DOCK_EFFECT_KEY] || "premium");
      themeMode = String(stored[DOCK_THEME_KEY] || "glass");
      root.classList.remove("effect-off", "effect-bounce", "effect-premium", "theme-glass", "theme-midnight", "theme-clean", "theme-lavender", "theme-neon", "theme-sunset", "theme-obsidian", "theme-rose");
      root.classList.add(`effect-${effectMode}`);
      root.classList.add(`theme-${themeMode}`);
      const dockNode = dockWrap.querySelector(".ldd-dock");
      if (dockNode) dockNode.dataset.theme = themeMode;
      if (!hidden) scheduleHide();
    }

    function stopPulse() {
      clearTimeout(pulseTimer);
      root.classList.remove("pulsing");
    }

    function startPulse() {
      stopPulse();
      if (effectMode === "off") return;
      root.classList.add("pulsing");
      pulseTimer = setTimeout(() => {
        root.classList.remove("pulsing");
      }, 5200);
    }

    function show() {
      if (destroyed) return;
      hidden = false;
      stopPulse();
      root.classList.remove("hidden");
      root.classList.add("shown");
      scheduleHide();
    }

    function hide() {
      if (destroyed) return;
      if (hideDelay <= 0) {
        root.classList.remove("hidden");
        root.classList.add("shown");
        return;
      }
      hidden = true;
      root.classList.add("hidden");
      root.classList.remove("shown");
      startPulse();
    }

    function scheduleHide() {
      clearTimeout(timer);
      if (hideDelay <= 0) return;
      timer = setTimeout(() => {
        if (!dockWrap.matches(":hover") && !dockWrap.contains(document.activeElement)) hide();
      }, hideDelay);
    }

    const onHotspotEnter = () => show();
    const onHandleEnter = () => show();
    const onHandleClick = () => show();
    const onDockEnter = () => show();
    const onDockLeave = () => scheduleHide();
    const onFocusIn = () => show();
    const onFocusOut = () => scheduleHide();
    const onPointerDown = () => show();
    const onDockActionClicked = () => hide();
    const onEnhancerBubbleEnter = () => show();

    hotspotLeft?.addEventListener("mouseenter", onHotspotEnter);
    hotspotRight?.addEventListener("mouseenter", onHotspotEnter);
    handle.addEventListener("mouseenter", onHandleEnter);
    handle.addEventListener("click", onHandleClick);
    dockWrap.addEventListener("mouseenter", onDockEnter);
    dockWrap.addEventListener("mouseleave", onDockLeave);
    dockWrap.addEventListener("focusin", onFocusIn);
    dockWrap.addEventListener("focusout", onFocusOut);
    dockWrap.addEventListener("pointerdown", onPointerDown, true);
    window.addEventListener("ldd-dock-action-clicked", onDockActionClicked);

    const bindEnhancerBubbleHover = () => {
      const bubble = document.getElementById("ldd-sidebar-bubble");
      if (bubble && !bubble.__lddDockWakeBound) {
        bubble.addEventListener("mouseenter", onEnhancerBubbleEnter);
        bubble.__lddDockWakeBound = true;
      }
    };

    const onMouseMove = (e) => {
      const nearBottom = e.clientY >= window.innerHeight - 44;
      const nearLeftCorner = nearBottom && e.clientX <= 92;
      const nearRightCorner = nearBottom && e.clientX >= window.innerWidth - 92;
      if (nearLeftCorner || nearRightCorner) show();
      bindEnhancerBubbleHover();
    };
    const onStorageChange = (changes, area) => {
      if (area !== "local") return;
      if (changes[DOCK_AUTOHIDE_KEY] || changes[DOCK_EFFECT_KEY] || changes[DOCK_THEME_KEY]) refreshSettings();
    };
    window.addEventListener("mousemove", onMouseMove, { passive: true });
    try { chrome.storage.onChanged.addListener(onStorageChange); } catch (e) {}

    refreshSettings().then(show);

    return () => {
      destroyed = true;
      clearTimeout(timer);
      stopPulse();
      hotspotLeft?.removeEventListener("mouseenter", onHotspotEnter);
      hotspotRight?.removeEventListener("mouseenter", onHotspotEnter);
      handle.removeEventListener("mouseenter", onHandleEnter);
      handle.removeEventListener("click", onHandleClick);
      dockWrap.removeEventListener("mouseenter", onDockEnter);
      dockWrap.removeEventListener("mouseleave", onDockLeave);
      dockWrap.removeEventListener("focusin", onFocusIn);
      dockWrap.removeEventListener("focusout", onFocusOut);
      dockWrap.removeEventListener("pointerdown", onPointerDown, true);
      window.removeEventListener("ldd-dock-action-clicked", onDockActionClicked);
      window.removeEventListener("mousemove", onMouseMove, { passive: true });
      const bubble = document.getElementById("ldd-sidebar-bubble");
      if (bubble && bubble.__lddDockWakeBound) {
        bubble.removeEventListener("mouseenter", onEnhancerBubbleEnter);
        delete bubble.__lddDockWakeBound;
      }
      try { chrome.storage.onChanged.removeListener(onStorageChange); } catch (e) {}
    };
  }

  function suppressLegacyTopBar() {
    document.getElementById("ldd-listings-toolbar-center-fixed")?.remove();
    document.getElementById("lddDndModeTool")?.remove();
    document.getElementById("lddHeaderUploadRow")?.remove();
  }

  let cleanupHide = null;
  let observer = null;

  async function init() {
    nuke();
    injectStyle();
    suppressLegacyTopBar();
    const { root, hotspot, hotspotLeft, hotspotRight, dockWrap, handle } = await buildRoot();
    cleanupHide = initAutoHide(root, hotspot, hotspotLeft, hotspotRight, dockWrap, handle);
    root.classList.add("shown");
    observer = new MutationObserver(() => suppressLegacyTopBar());
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }

  function destroy() {
    cleanupHide?.();
    observer?.disconnect();
    nuke();
  }

  window.__LDD_CLEAN_DOCK_INSTANCE__ = { destroy };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init, { once: true });
  } else {
    init();
  }
})();
