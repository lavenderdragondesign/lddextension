(function(){
  const VERSION = "v34";
  const VERSION_KEY = "lddWhatsNewSeenVersion";
  const HIDE_KEY = "lddWhatsNewNeverShow";

  const backdrop = document.getElementById("ldd-whats-new-backdrop");
  const closeBtn = document.getElementById("ldd-whats-new-close");
  const dontShow = document.getElementById("ldd-whats-new-dont-show");

  function shouldShow() {
    try {
      const neverShow = localStorage.getItem(HIDE_KEY) === "true";
      const seenVersion = localStorage.getItem(VERSION_KEY) || "";
      return !neverShow && seenVersion !== VERSION;
    } catch (e) {
      return true;
    }
  }

  function saveAndClose() {
    try {
      localStorage.setItem(VERSION_KEY, VERSION);
      if (dontShow && dontShow.checked) {
        localStorage.setItem(HIDE_KEY, "true");
      }
    } catch (e) {}
    if (backdrop) backdrop.style.display = "none";
  }

  if (shouldShow() && backdrop) {
    window.addEventListener("load", function(){
      setTimeout(function () {
        backdrop.style.display = "flex";
      }, 240);
    });
  }

  if (closeBtn) closeBtn.addEventListener("click", saveAndClose);
  if (backdrop) {
    backdrop.addEventListener("click", function(e){
      if (e.target === backdrop) saveAndClose();
    });
  }
})();