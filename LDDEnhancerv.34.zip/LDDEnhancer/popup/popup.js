const DOCK_DISABLED_KEY = "lddDockDisabled";

async function getActiveTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs[0] || null;
}

function setStatus(text, ok) {
  const el = document.getElementById("siteStatus");
  if (!el) return;
  el.textContent = text;
  el.classList.toggle("ok", Boolean(ok));
}

function notify(message, level) {
  const el = document.getElementById("statusMessage");
  if (!el) return;
  el.textContent = message;
  el.className = "status-message" + (level ? " " + level : "");
}

async function refreshSiteStatus() {
  const tab = await getActiveTab();
  const ready = Boolean(tab?.url?.startsWith("https://mydesigns.io/"));
  setStatus(ready ? "MD tab ready" : "Open an MD tab", ready);
}

async function loadToggles() {
  const stored = await chrome.storage.local.get({
    enhancerEnabled: true,
    dropperEnabled: true,
    [DOCK_DISABLED_KEY]: false
  });

  document.getElementById("enhancerEnabled").checked = Boolean(stored.enhancerEnabled);
  document.getElementById("dropperEnabled").checked = Boolean(stored.dropperEnabled);
  document.getElementById("dockEnabled").checked = !Boolean(stored[DOCK_DISABLED_KEY]);
}

async function setAndRefresh(next, message) {
  await chrome.storage.local.set(next);
  await loadToggles();
  if (message) notify(message);
}

async function initialize() {
  await loadToggles();
  await refreshSiteStatus();

  document.getElementById("enhancerEnabled").addEventListener("change", async (e) => {
    await setAndRefresh(
      { enhancerEnabled: e.target.checked },
      e.target.checked ? "MD Enhancer enabled." : "MD Enhancer disabled."
    );
  });

  document.getElementById("dockEnabled").addEventListener("change", async (e) => {
    const enabled = Boolean(e.target.checked);
    await setAndRefresh(
      { [DOCK_DISABLED_KEY]: !enabled },
      enabled ? "Dock enabled." : "Dock disabled."
    );
  });

  document.getElementById("dropperEnabled").addEventListener("change", async (e) => {
    await setAndRefresh(
      { dropperEnabled: e.target.checked },
      e.target.checked ? "Drag & Drop enabled." : "Drag & Drop disabled."
    );
  });

  document.getElementById("fullEnable").addEventListener("click", async () => {
    await setAndRefresh(
      { enhancerEnabled: true, dropperEnabled: true, [DOCK_DISABLED_KEY]: false },
      "All tools enabled."
    );
  });

  document.getElementById("fullDisable").addEventListener("click", async () => {
    await setAndRefresh(
      { enhancerEnabled: false, dropperEnabled: false, [DOCK_DISABLED_KEY]: true },
      "All tools disabled."
    );
  });
}

initialize();
