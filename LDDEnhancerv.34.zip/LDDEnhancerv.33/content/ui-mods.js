(() => {
  const STYLE_ID = "ldd-listings-toolbar-style-fixed";
  const CENTER_ID = "ldd-listings-toolbar-center-fixed";
  const VISION_AI_OTHER_LABEL = "other (please specify)";
  const VISION_AI_PRESET_TYPES = ["PNG", "SVG", "TUMBLER WRAP", "MUG WRAP"];
  const VISION_AI_PRESET_BLOCK_ID = "ldd-vision-ai-preset-block";
  const VISION_AI_PRESET_LIST_ITEM_ID = "ldd-vision-ai-preset-list-item";
  const LDD_LOGO_URL = chrome.runtime.getURL("assets/logo.png");
  let visionAiPresetSyncInProgress = false;

  function norm(value) {
    return (value || "").replace(/\s+/g, " ").trim().toLowerCase();
  }

  const sleep = (ms) => new Promise((resolve) => window.setTimeout(resolve, ms));

  function isVisible(element) {
    if (!element) return false;
    const style = window.getComputedStyle(element);
    return (
      style.display !== "none" &&
      style.visibility !== "hidden" &&
      (element.offsetParent !== null || element.getClientRects().length > 0)
    );
  }

  function hardClick(element) {
    if (!element) return;
    ["pointerdown", "mousedown", "pointerup", "mouseup", "click"].forEach((type) => {
      element.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true }));
    });
    if (typeof element.click === "function") {
      element.click();
    }
  }

  function setInputValue(input, value) {
    const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")?.set;
    if (nativeSetter) {
      nativeSetter.call(input, value);
    } else {
      input.value = value;
    }
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  async function waitFor(getter, timeout = 2200, step = 100) {
    const startedAt = Date.now();
    while (Date.now() - startedAt < timeout) {
      const value = getter();
      if (value) return value;
      await sleep(step);
    }
    return null;
  }

  function isListingsPage() {
    const origin = window.location.origin || "";
    const path = (window.location.pathname || "").replace(/\/+$/, "");
    return origin === "https://mydesigns.io" && path === "/app/listings";
  }

  function injectStyle() {
    if (document.getElementById(STYLE_ID)) return;

    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      #${CENTER_ID} {
        position: static;
        display: block;
        margin: 2px 0 0;
        z-index: 1;
        pointer-events: auto;
        width: 100%;
        max-width: 100%;
        box-sizing: border-box;
        flex-basis: 100%;
      }

      .ldd-quick-row {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        flex-wrap: nowrap;
        justify-content: flex-start;
        max-width: 100%;
        overflow-x: hidden;
        overflow-y: hidden;
        scrollbar-width: none;
      }

      .ldd-quick-row::-webkit-scrollbar {
        display: none;
      }

      .ldd-no-h-scroll {
        overflow-x: hidden !important;
        scrollbar-width: none !important;
      }

      .ldd-no-h-scroll::-webkit-scrollbar {
        display: none !important;
        height: 0 !important;
      }

      .ldd-tool {
        height: 26px;
        padding: 0 8px;
        border: 1px solid #d7dce5;
        border-radius: 7px;
        background: #f8fafc;
        color: #334155;
        font-size: 11px;
        font-weight: 600;
        cursor: pointer;
        white-space: nowrap;
        line-height: 1;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        box-sizing: border-box;
      }

      .ldd-tool:hover {
        background: #eef2f7;
        color: #1f2937;
      }

      .ldd-tool:active {
        transform: scale(0.98);
      }

      .ldd-qa-logo {
        min-width: 34px;
        width: 34px;
        height: 26px;
        padding: 0;
        border: 1px solid #d7dce5;
        border-radius: 7px;
        background: #f8fafc;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        box-sizing: border-box;
        pointer-events: none;
        user-select: none;
      }

      .ldd-qa-logo img {
        width: 18px;
        height: 18px;
        border-radius: 4px;
        object-fit: cover;
      }

      .ldd-enhancer-toggle-btn {
        height: 30px;
        padding: 0 12px;
        border-color: #15803d;
        background: #16a34a;
        color: #ffffff;
        font-size: 12px;
        font-weight: 700;
      }

      .ldd-enhancer-toggle-btn:hover {
        background: #15803d;
        color: #ffffff;
      }

      .ldd-enhancer-toggle-btn.active {
        border-color: #166534;
        background: #166534;
        color: #ffffff;
      }

      .ldd-search-compact-wrap {
        flex: 0 0 auto !important;
        width: 520px !important;
        max-width: calc(100% - 12px) !important;
        min-width: 240px !important;
        margin-left: 0 !important;
        align-self: flex-start !important;
      }

      .ldd-search-compact-input {
        width: 100% !important;
        max-width: none !important;
      }

      .ldd-moved-publish-actions {
        margin-right: 14px !important;
      }

      .ldd-vision-ai-preset-block {
        display: flex;
        flex-direction: column;
        gap: 4px;
        margin: 0 0 4px;
        border: 1px solid #d7dce5;
        border-radius: 10px;
        background: #f8fafc;
        padding: 8px;
        list-style: none;
      }

      .ldd-vision-ai-preset-head {
        display: flex;
        align-items: center;
        gap: 6px;
        font-size: 11px;
        font-weight: 700;
        color: #334155;
        margin-bottom: 2px;
      }

      .ldd-vision-ai-preset-logo {
        width: 14px;
        height: 14px;
        border-radius: 4px;
        object-fit: cover;
        flex-shrink: 0;
      }

      .ldd-vision-ai-preset-row {
        display: flex;
        align-items: center;
        gap: 8px;
        min-height: 28px;
        border-radius: 8px;
        padding: 4px 6px;
        color: #1f2937;
        cursor: pointer;
        user-select: none;
      }

      .ldd-vision-ai-preset-row:hover {
        background: #eef2f7;
      }

      .ldd-vision-ai-preset-row input[type="checkbox"] {
        width: 16px;
        height: 16px;
        margin: 0;
        flex-shrink: 0;
      }

      .ldd-vision-ai-preset-text {
        font-size: 13px;
        font-weight: 500;
        line-height: 1.2;
      }

      .ldd-vision-ai-preset-list-item {
        list-style: none;
        padding: 0 !important;
        margin: 0 !important;
        background: transparent !important;
        cursor: default !important;
      }
    `;

    document.head.appendChild(style);
  }

  function removeStyle() {
    document.getElementById(STYLE_ID)?.remove();
  }

  function findChooseButton() {
    return Array.from(document.querySelectorAll("button")).find((button) =>
      norm(button.textContent).includes("choose action")
    );
  }

  function findListingsToolbar() {
    const chooseButton = findChooseButton();
    if (!chooseButton) return null;

    let node = chooseButton;
    for (let i = 0; i < 10 && node; i += 1) {
      const parent = node.parentElement;
      if (!parent) break;

      const text = norm(parent.innerText || "");
      if (text.includes("choose action") && text.includes("collections")) {
        return parent;
      }

      node = parent;
    }

    return null;
  }

  function findDirectToolbarChild(toolbar, matcher) {
    return Array.from(toolbar.children).find((child) => matcher(norm(child.innerText || child.textContent || "")));
  }

  function findSearchBlock(toolbar) {
    return Array.from(toolbar.children).find(
      (el) => Boolean(el.querySelector?.('input[placeholder*="Search through collection"]'))
    );
  }

  function hideHorizontalScrollbar(element) {
    if (!element) return;
    element.classList?.add("ldd-no-h-scroll");
    element.style.overflowX = "hidden";
  }

  function openChooseActionMenu() {
    const chooseButton = findChooseButton();
    if (!chooseButton) return false;
    chooseButton.click();
    return true;
  }

  function getActionButtons() {
    const labels = [
      "image mockups",
      "video mockups",
      "vision ai",
      "edit in bulk",
      "color overlay",
      "remove background",
      "upscale image",
      "vectorize image",
      "canvas",
      "delete listing",
      "delete listings"
    ];

    return Array.from(document.querySelectorAll("button")).filter((button) => {
      const text = norm(button.innerText || button.textContent || "");
      if (!text || text.includes("choose action")) return false;

      const looksLikeDropdownAction =
        button.className.includes("min-w-[230px]") ||
        button.closest("li.min-w-32") ||
        button.closest("div.absolute") ||
        button.closest('div[style*="position: absolute"]');

      return looksLikeDropdownAction && labels.some((label) => text.includes(label));
    });
  }

  function clickActionButton(labels) {
    const wanted = (Array.isArray(labels) ? labels : [labels]).map((label) => norm(label));
    const buttons = getActionButtons();

    for (const button of buttons) {
      const spans = Array.from(button.querySelectorAll("span"));
      for (const span of spans) {
        if (wanted.includes(norm(span.textContent || ""))) {
          button.click();
          return true;
        }
      }
    }

    for (const button of buttons) {
      const text = norm(button.innerText || button.textContent || "");
      if (wanted.includes(text)) {
        button.click();
        return true;
      }
    }

    for (const button of buttons) {
      const text = norm(button.innerText || button.textContent || "");
      if (wanted.some((wantedLabel) => text.includes(wantedLabel))) {
        button.click();
        return true;
      }
    }

    return false;
  }

  function triggerMenuAction(labels) {
    if (!openChooseActionMenu()) return;

    let tries = 0;
    const timerId = window.setInterval(() => {
      tries += 1;
      const clicked = clickActionButton(labels);
      if (clicked || tries > 30) {
        window.clearInterval(timerId);
      }
    }, 160);
  }

  function makeTool(label, actionLabels) {
    const button = document.createElement("button");
    button.className = "ldd-tool";
    button.type = "button";
    button.textContent = label;
    button.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      triggerMenuAction(actionLabels);
    });
    return button;
  }

  function makeHrefTool(label, href) {
    const button = document.createElement("button");
    button.className = "ldd-tool";
    button.type = "button";
    button.textContent = label;
    button.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      window.location.href = href;
    });
    return button;
  }

  function makeStaticLogo() {
    const logoWrap = document.createElement("span");
    logoWrap.className = "ldd-qa-logo";
    logoWrap.setAttribute("aria-hidden", "true");

    const logo = document.createElement("img");
    logo.src = chrome.runtime.getURL("assets/logo.png");
    logo.alt = "";
    logoWrap.appendChild(logo);

    return logoWrap;
  }

  function makeEnhancerToggleTool() {
    const button = document.createElement("button");
    button.id = "lddEnhancerToggle";
    button.className = "ldd-tool ldd-enhancer-toggle-btn";
    button.type = "button";

    button.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      const enhancer = window.LDDEnhancer;
      if (!enhancer) {
        window.dispatchEvent(new CustomEvent("ldd-enhancer-toggle"));
        return;
      }

      const isOpen = typeof enhancer.isOpen === "function" ? Boolean(enhancer.isOpen()) : button.classList.contains("active");
      if (isOpen) {
        enhancer.close?.();
        return;
      }

      enhancer.enable?.();
      enhancer.open?.();
    });

    const syncState = (open) => {
      const isOpen = Boolean(open);
      button.classList.toggle("active", isOpen);
      button.textContent = isOpen ? "Close" : "Open MD Enhancer";
      button.title = isOpen ? "Close MD Enhancer" : "Open MD Enhancer";
    };

    window.addEventListener("ldd-enhancer-state", (event) => {
      syncState(Boolean(event.detail?.open));
    });

    syncState(false);

    window.setTimeout(() => {
      window.dispatchEvent(new CustomEvent("ldd-enhancer-request-state"));
    }, 120);

    return button;
  }

  function makePdfGenTool() {
    const button = document.createElement("button");
    button.className = "ldd-tool";
    button.type = "button";
    button.title = "Open PDF Generator";
    button.textContent = "PDF Gen";
    button.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      chrome.runtime.sendMessage({ type: "ldd/openPdfGen" });
    });
    return button;
  }

  function makeCompressorTool() {
    const button = document.createElement("button");
    button.className = "ldd-tool";
    button.type = "button";
    button.title = "Open Image Compressor";
    button.textContent = "Compressor";
    button.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      window.LDDCompressor?.toggle();
    });
    return button;
  }

  function makeResizerTool() {
    const button = document.createElement("button");
    button.className = "ldd-tool";
    button.type = "button";
    button.title = "Open Quick Resizer";
    button.textContent = "Resizer";
    button.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      window.LDDResizer?.toggle();
    });
    return button;
  }

  function makeLddDivider() {
    const wrap = document.createElement("span");
    wrap.style.cssText = "display:inline-flex;align-items:center;gap:6px;flex-shrink:0;";

    const pipe = document.createElement("span");
    pipe.textContent = "|";
    pipe.style.cssText = "color:rgba(255,255,255,.25);font-size:14px;line-height:1;";

    const logo = document.createElement("img");
    logo.src = chrome.runtime.getURL("assets/logo.png");
    logo.alt = "";
    logo.style.cssText = "width:16px;height:16px;border-radius:4px;object-fit:cover;flex-shrink:0;";

    wrap.appendChild(pipe);
    wrap.appendChild(logo);
    return wrap;
  }

  function buildCenterGroup() {
    let group = document.getElementById(CENTER_ID);
    if (!group) {
      group = document.createElement("div");
      group.id = CENTER_ID;
    }

    if (!group.dataset.ready) {
      const row = document.createElement("div");
      row.className = "ldd-quick-row";
      row.appendChild(makeStaticLogo());
      row.appendChild(makeTool("Image Mockups", "Image Mockups"));
      row.appendChild(makeTool("Video Mockups", "Video Mockups"));
      row.appendChild(makeTool("Vision AI", "Vision AI"));
      row.appendChild(makeTool("Remove BG", "Remove Background"));
      row.appendChild(makeTool("Upscale", "Upscale Image"));
      row.appendChild(makeTool("Vectorize", "Vectorize Image"));
      row.appendChild(makeTool("Canvas", "Canvas"));
      row.appendChild(makeHrefTool("Dream AI", "/app/dreamer"));
      row.appendChild(makeTool("Color Overlay", "Color Overlay"));
      row.appendChild(makeTool("Edit in Bulk", "Edit in Bulk"));
      row.appendChild(makeLddDivider());
      row.appendChild(makeCompressorTool());
      row.appendChild(makeResizerTool());
      row.appendChild(makeEnhancerToggleTool());
      group.appendChild(row);
      group.dataset.ready = "1";
    }

    return group;
  }

  function findPublishActionGroup() {
    const publishButton = Array.from(document.querySelectorAll("button")).find((button) => norm(button.textContent) === "publish");
    if (!publishButton) return null;

    let node = publishButton;
    for (let i = 0; i < 10 && node; i += 1) {
      const parent = node.parentElement;
      if (!parent) break;

      const text = norm(parent.innerText || "");
      if (text.includes("publications") && text.includes("template") && text.includes("upload") && text.includes("publish")) {
        return parent;
      }

      node = parent;
    }

    return null;
  }

  function findHeaderRightArea() {
    return (
      Array.from(document.querySelectorAll("div.ms-auto.flex.items-center")).find((element) => {
        const text = norm(element.innerText || "");
        return text.includes("publish") || text.includes("andrea kessler");
      }) || null
    );
  }

  function findVisionAiForm() {
    return (
      Array.from(document.querySelectorAll("form")).find((form) => {
        const text = norm(form.textContent || "");
        return (
          (text.includes("generate listing data based on your design") && text.includes("select product type")) ||
          (text.includes("vision ai") && text.includes("select product type"))
        );
      }) || null
    );
  }

  function findVisionAiRoot(seed) {
    if (seed) {
      let node = seed;
      for (let i = 0; i < 10 && node; i += 1) {
        const text = norm(node.textContent || "");
        if (
          text.includes("generate listing data based on your design") ||
          (text.includes("vision ai") && text.includes("select product type"))
        ) {
          return node;
        }
        node = node.parentElement;
      }
    }

    const form = findVisionAiForm();
    if (form) return form;

    return (
      Array.from(document.querySelectorAll("div[role='dialog'],div")).find((node) => {
        const text = norm(node.textContent || "");
        return text.includes("vision ai") && text.includes("select product type");
      }) || document
    );
  }

  function findButtonByLabel(root, labelText) {
    const target = norm(labelText);
    const labels = Array.from(root.querySelectorAll("label,div,span,p")).filter(
      (node) => norm(node.textContent || "") === target
    );

    for (const label of labels) {
      const box = label.closest("div");
      if (!box) continue;
      const scopes = [box, box.parentElement, box.parentElement?.parentElement];
      for (const scope of scopes) {
        if (!scope) continue;
        const button = scope.querySelector('button[type="button"]');
        if (button && isVisible(button)) return button;
      }
    }
    return null;
  }

  function findOtherProductTypeOption(root) {
    const listContainer = findVisionAiOptionListContainer(root);
    if (listContainer) {
      const rowByData = Array.from(listContainer.querySelectorAll("li[data-value]")).find((row) =>
        norm(row.textContent || "") === VISION_AI_OTHER_LABEL
      );
      if (rowByData) return rowByData;
    }

    const searchInput = findVisionAiProductTypeSearchInput(root);
    const searchScope = searchInput?.closest("div")?.parentElement;
    const scope = searchScope && root?.contains?.(searchScope) ? searchScope : root || document;

    const exactTextNodes = Array.from(scope.querySelectorAll("span,div,label,p")).filter((node) => {
      if (!isVisible(node)) return false;
      return norm(node.textContent || "") === VISION_AI_OTHER_LABEL;
    });

    for (const node of exactTextNodes) {
      let current = node;
      for (let depth = 0; current && depth < 5; depth += 1) {
        if (
          current.getAttribute?.("role") === "option" ||
          current.tagName === "BUTTON" ||
          current.classList?.contains("cursor-pointer") ||
          current.hasAttribute?.("tabindex")
        ) {
          return current;
        }
        current = current.parentElement;
      }
      if (node.parentElement) {
        return node.parentElement;
      }
    }

    const candidates = Array.from(scope.querySelectorAll("label,li,button,[role='option'],div")).filter((node) => {
      if (!isVisible(node)) return false;
      const text = norm(node.textContent || "");
      if (!text.includes(VISION_AI_OTHER_LABEL)) return false;
      const hasCheckbox = Boolean(node.querySelector('input[type="checkbox"],[role="checkbox"]'));
      const looksInteractive =
        node.getAttribute("role") === "option" ||
        node.tagName === "BUTTON" ||
        node.classList?.contains("cursor-pointer") ||
        node.hasAttribute("tabindex");
      return hasCheckbox || looksInteractive;
    });

    candidates.sort((a, b) => (a.textContent || "").length - (b.textContent || "").length);
    return candidates[0] || null;
  }

  function findVisionAiProductTypeSearchInput(root = document) {
    const scope = root || document;
    return (
      Array.from(scope.querySelectorAll("input")).find((input) => {
        if (!isVisible(input)) return false;
        const placeholder = norm(input.getAttribute("placeholder") || "");
        return placeholder.includes("search option");
      }) || null
    );
  }

  function findVisionAiOptionRows(root) {
    const listContainer = findVisionAiOptionListContainer(root);
    if (!listContainer) return [];
    const rows = Array.from(listContainer.querySelectorAll("li")).filter((node) => {
      if (!isVisible(node)) return false;
      if (node.id === VISION_AI_PRESET_BLOCK_ID) return false;
      const text = norm(node.textContent || "");
      if (!text) return false;
      const isProductRow = node.hasAttribute("data-value") || node.hasAttribute("tabindex");
      return isProductRow;
    });

    rows.sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top);
    return rows;
  }

  function findVisionAiOptionListContainer(root) {
    const searchInput = findVisionAiProductTypeSearchInput(root);
    if (!searchInput) return null;
    const panel = searchInput.closest("div.relative.rounded-md")?.parentElement || searchInput.closest("div")?.parentElement;
    const localLists = panel
      ? Array.from(panel.querySelectorAll("ul")).filter((list) => {
          if (!isVisible(list)) return false;
          return Boolean(list.querySelector("li[data-value],li[tabindex]"));
        })
      : [];
    if (localLists.length) {
      localLists.sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top);
      return localLists[0];
    }

    const globalLists = Array.from(document.querySelectorAll("ul")).filter((list) => {
      if (!isVisible(list)) return false;
      if (!list.querySelector("li[data-value],li[tabindex]")) return false;
      const text = norm(list.textContent || "");
      return text.includes(VISION_AI_OTHER_LABEL);
    });
    if (!globalLists.length) return null;

    globalLists.sort((a, b) => {
      const scoreA = (a.querySelectorAll("li[data-value],li[tabindex]").length || 0) + (norm(a.textContent || "").includes("t-shirt") ? 5 : 0);
      const scoreB = (b.querySelectorAll("li[data-value],li[tabindex]").length || 0) + (norm(b.textContent || "").includes("t-shirt") ? 5 : 0);
      return scoreB - scoreA;
    });
    return globalLists[0];
  }

  function isOtherOptionSelected(root) {
    const option = findOtherProductTypeOption(root);
    if (!option) return false;
    const row = option.closest("li") || option.closest("div") || option;
    return Boolean(row.querySelector('[class*="bg-brand-primary"] svg, [class*="bg-brand-primary"]'));
  }

  async function ensureVisionAiOtherType(root) {
    const productTypeButton = findButtonByLabel(root, "Select product type");
    if (productTypeButton && norm(productTypeButton.textContent || "").includes(VISION_AI_OTHER_LABEL)) {
      return true;
    }

    if (productTypeButton) {
      hardClick(productTypeButton);
      await sleep(120);
    }

    let option = await waitFor(() => findOtherProductTypeOption(root), 1200, 100);
    if (!option) {
      const searchInput = findVisionAiProductTypeSearchInput(root);
      if (!searchInput) return false;
      setInputValue(searchInput, "other");
      option = await waitFor(() => findOtherProductTypeOption(root), 1600, 100);
      if (!option) return false;
    }

    const bestTarget = option.matches?.("[tabindex]") ? option : option.querySelector?.("[tabindex]") || option;
    hardClick(bestTarget);
    await sleep(120);
    const selected = await waitFor(() => {
      if (productTypeButton && norm(productTypeButton.textContent || "").includes(VISION_AI_OTHER_LABEL)) {
        return true;
      }
      return Boolean(findVisionAiCustomTypeInput(root)) || isOtherOptionSelected(root);
    }, 2000, 120);
    return Boolean(selected);
  }

  function findVisionAiCustomTypeInput(root) {
    const scope = root || document;
    const exactContainer = Array.from(scope.querySelectorAll("div[maxlength]")).find((container) => {
      if (!isVisible(container)) return false;
      const maxLength = Number.parseInt(container.getAttribute("maxlength") || "0", 10);
      if (maxLength !== 150) return false;
      return norm(container.textContent || "").includes("please specify other type");
    });
    if (exactContainer) {
      const exactInput = exactContainer.querySelector('input[maxlength="150"]');
      if (exactInput && isVisible(exactInput)) return exactInput;
    }

    const byLabelContainer = Array.from(scope.querySelectorAll("div")).find((container) => {
      if (!isVisible(container)) return false;
      const text = norm(container.textContent || "");
      if (!text.includes("please specify other type")) return false;
      return Boolean(container.querySelector("input"));
    });
    if (byLabelContainer) {
      const labeledInput = byLabelContainer.querySelector('input[maxlength="150"],input[type="text"],input:not([type])');
      if (labeledInput && isVisible(labeledInput)) return labeledInput;
    }

    const byMaxLength = Array.from(scope.querySelectorAll("input[maxlength]")).find((input) => {
      if (!isVisible(input)) return false;
      const maxLength = Number.parseInt(input.getAttribute("maxlength") || "0", 10);
      return maxLength >= 100;
    });
    if (byMaxLength) return byMaxLength;

    const label = Array.from(scope.querySelectorAll("label,div,span,p")).find(
      (node) => norm(node.textContent || "") === "please specify other type"
    );
    if (!label) return null;

    const box = label.closest("div");
    if (!box) return null;
    const input = box.parentElement?.querySelector('input[type="text"],input:not([type])');
    return input && isVisible(input) ? input : null;
  }

  function parseVisionAiTypeList(value) {
    return new Set(
      String(value || "")
        .split(",")
        .map((entry) => norm(entry))
        .filter(Boolean)
    );
  }

  function syncVisionAiPresetChecks(root, block) {
    const customInput = findVisionAiCustomTypeInput(root);
    if (!customInput) return;

    const selected = parseVisionAiTypeList(customInput.value);
    block.querySelectorAll('input[type="checkbox"][data-type]').forEach((checkbox) => {
      checkbox.checked = selected.has(norm(checkbox.dataset.type || ""));
    });
  }

  function buildVisionAiPresetBlock(root) {
    const block = document.createElement("div");
    block.id = VISION_AI_PRESET_BLOCK_ID;
    block.className = "ldd-vision-ai-preset-block";
    block.addEventListener("click", (event) => {
      event.stopPropagation();
    });
    block.addEventListener("mousedown", (event) => {
      event.stopPropagation();
    });

    const heading = document.createElement("div");
    heading.className = "ldd-vision-ai-preset-head";
    const headingLogo = document.createElement("img");
    headingLogo.className = "ldd-vision-ai-preset-logo";
    headingLogo.src = LDD_LOGO_URL;
    headingLogo.alt = "";
    headingLogo.setAttribute("aria-hidden", "true");
    const headingText = document.createElement("span");
    headingText.textContent = "LDD quick custom types";
    heading.appendChild(headingLogo);
    heading.appendChild(headingText);
    block.appendChild(heading);

    VISION_AI_PRESET_TYPES.forEach((typeValue) => {
      const row = document.createElement("label");
      row.className = "ldd-vision-ai-preset-row";

      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.dataset.type = typeValue;

      const logo = document.createElement("img");
      logo.className = "ldd-vision-ai-preset-logo";
      logo.src = LDD_LOGO_URL;
      logo.alt = "";
      logo.setAttribute("aria-hidden", "true");

      const text = document.createElement("span");
      text.className = "ldd-vision-ai-preset-text";
      text.textContent = typeValue;

      row.addEventListener("click", (event) => {
        event.stopPropagation();
      });

      checkbox.addEventListener("change", () => {
        void applyVisionAiPresetSelection(root, block);
      });

      row.appendChild(checkbox);
      row.appendChild(logo);
      row.appendChild(text);
      block.appendChild(row);
    });

    return block;
  }

  function getVisionAiPresetBlock(root) {
    return document.getElementById(VISION_AI_PRESET_BLOCK_ID) || buildVisionAiPresetBlock(root);
  }

  function mountVisionAiPresetBlockInList(listContainer, block) {
    if (!listContainer || !block) return false;

    let wrapper = document.getElementById(VISION_AI_PRESET_LIST_ITEM_ID);
    if (!wrapper) {
      wrapper = document.createElement("li");
      wrapper.id = VISION_AI_PRESET_LIST_ITEM_ID;
      wrapper.className = "ldd-vision-ai-preset-list-item";
      wrapper.setAttribute("tabindex", "-1");
    }

    if (block.parentElement !== wrapper) {
      wrapper.appendChild(block);
    }

    const firstRow = Array.from(listContainer.querySelectorAll("li")).find(
      (row) => row.id !== VISION_AI_PRESET_LIST_ITEM_ID
    );
    if (firstRow) {
      listContainer.insertBefore(wrapper, firstRow);
    } else {
      listContainer.prepend(wrapper);
    }

    return true;
  }

  function mountVisionAiPresetBlockInline(root, searchInput, block) {
    if (!block) return false;

    const wrapper = document.getElementById(VISION_AI_PRESET_LIST_ITEM_ID);
    if (wrapper?.contains(block)) {
      wrapper.remove();
    }

    const searchContainer = searchInput?.closest("div.relative.rounded-md") || searchInput?.closest("div");
    const panel = searchContainer?.parentElement;
    if (panel && searchContainer) {
      if (searchContainer.nextElementSibling !== block) {
        searchContainer.insertAdjacentElement("afterend", block);
      }
      return true;
    }

    const productTypeButton = findButtonByLabel(root, "Select product type");
    const productTypeWrap = productTypeButton?.parentElement;
    if (productTypeWrap?.parentElement) {
      productTypeWrap.insertAdjacentElement("afterend", block);
      return true;
    }

    return false;
  }

  async function applyVisionAiPresetSelection(root, block) {
    if (visionAiPresetSyncInProgress) return;
    visionAiPresetSyncInProgress = true;
    try {
      const selectedTypes = Array.from(block.querySelectorAll('input[type="checkbox"][data-type]'))
        .filter((checkbox) => checkbox.checked)
        .map((checkbox) => checkbox.dataset.type || "")
        .filter(Boolean);

      if (!selectedTypes.length) {
        const customInput = findVisionAiCustomTypeInput(root);
        if (customInput) {
          setInputValue(customInput, "");
        }
        return;
      }

      const hasOtherType = await ensureVisionAiOtherType(root);
      if (!hasOtherType) return;

      const customInput = await waitFor(() => findVisionAiCustomTypeInput(root), 2600, 120);
      if (!customInput) return;

      setInputValue(customInput, selectedTypes.join(", "));
    } finally {
      visionAiPresetSyncInProgress = false;
    }
  }

  async function maybeInjectVisionAiPresetOptions() {
    // Vision AI preset injection is handled by content-script.js only.
    return;
  }

  function createController() {
    let observer = null;
    let intervalId = null;
    let movedActionState = null;

    function clearToolbarMod() {
      document.getElementById(CENTER_ID)?.remove();
      removeStyle();
      resetPublishActionsLocation();
    }

    function movePublishActionsToHeader() {
      if (movedActionState) return;

      const actionGroup = findPublishActionGroup();
      const rightArea = findHeaderRightArea();
      if (!actionGroup || !rightArea) return;

      movedActionState = {
        group: actionGroup,
        parent: actionGroup.parentElement,
        nextSibling: actionGroup.nextElementSibling
      };

      actionGroup.classList.add("ldd-moved-publish-actions");
      rightArea.prepend(actionGroup);
    }

    function resetPublishActionsLocation() {
      if (!movedActionState) return;
      const { group, parent, nextSibling } = movedActionState;
      if (group && parent) {
        if (nextSibling && nextSibling.parentElement === parent) {
          parent.insertBefore(group, nextSibling);
        } else {
          parent.appendChild(group);
        }
      }
      group?.classList?.remove("ldd-moved-publish-actions");
      movedActionState = null;
    }

    function runToolbarMod() {
      if (!isListingsPage()) {
        clearToolbarMod();
        return;
      }

      injectStyle();
      const toolbar = findListingsToolbar();
      if (!toolbar) return;

      hideHorizontalScrollbar(toolbar);
      hideHorizontalScrollbar(toolbar.parentElement);
      toolbar.style.flexWrap = "wrap";
      toolbar.style.rowGap = "2px";

      const chooseBlock = findDirectToolbarChild(toolbar, (text) => text.includes("choose action"));
      if (!chooseBlock) return;

      const centerGroup = buildCenterGroup();
      const searchBlock = findSearchBlock(toolbar);
      const searchInput = searchBlock?.querySelector?.('input[placeholder*="Search through collection"]');

      if (searchBlock) {
        searchBlock.classList.add("ldd-search-compact-wrap");
        searchInput?.classList?.add("ldd-search-compact-input");
        searchBlock.style.marginLeft = "0px";
        searchBlock.style.alignSelf = "flex-start";
        if (centerGroup.parentElement !== toolbar || centerGroup.previousElementSibling !== searchBlock) {
          searchBlock.insertAdjacentElement("afterend", centerGroup);
        }
      } else if (centerGroup.parentElement !== toolbar || centerGroup.previousElementSibling !== chooseBlock) {
        chooseBlock.insertAdjacentElement("afterend", centerGroup);
      }

      centerGroup.style.paddingLeft = "0px";
      centerGroup.style.maxWidth = "100%";
      movePublishActionsToHeader();
    }

    function run() {
      runToolbarMod();
    }

    function start() {
      run();
      if (intervalId === null) {
        intervalId = window.setInterval(run, 900);
      }

      if (observer === null && document.body) {
        observer = new MutationObserver(run);
        observer.observe(document.body, { childList: true, subtree: true });
      }
    }

    function stop() {
      if (intervalId !== null) {
        window.clearInterval(intervalId);
        intervalId = null;
      }
      observer?.disconnect();
      observer = null;
      clearToolbarMod();
    }

    return { start, stop };
  }

  const state = {
    controller: null,
    enabled: false
  };
  const visionState = {
    intervalId: null,
    observer: null,
    enabled: false
  };

  function enable() {
    if (state.enabled) return;
    state.enabled = true;
    state.controller = createController();
    state.controller.start();
  }

  function disable() {
    if (!state.enabled) return;
    state.enabled = false;
    state.controller?.stop();
    state.controller = null;
  }

  function runVisionPreset() {
    // Disabled in this file to prevent duplicate observers and freeze loops.
  }

  function enableVisionPreset() {
    if (visionState.enabled) return;
    visionState.enabled = true;
  }

  function disableVisionPreset() {
    if (!visionState.enabled) return;
    visionState.enabled = false;
    if (visionState.intervalId !== null) {
      window.clearInterval(visionState.intervalId);
      visionState.intervalId = null;
    }
    visionState.observer?.disconnect();
    visionState.observer = null;
    document.getElementById(VISION_AI_PRESET_LIST_ITEM_ID)?.remove();
    document.getElementById(VISION_AI_PRESET_BLOCK_ID)?.remove();
  }

  window.LDDQaBar = {
    enable,
    disable
  };

  window.LDDVisionPreset = {
    enable: enableVisionPreset,
    disable: disableVisionPreset
  };
})();
