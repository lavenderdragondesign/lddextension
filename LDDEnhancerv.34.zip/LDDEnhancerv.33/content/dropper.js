(() => {
  "use strict";

  const DEBUG = true;

  const LDD_LOGO_URL = chrome.runtime.getURL("assets/logo.png");

  const AUTO_CLICK_UPLOAD_ALL = true;
  const AUTO_CONFIRM_UPLOAD_DESIGNS = true;

  const UPLOAD_ALL_TIMEOUT_MS = 20000;
  const CONFIRM_TIMEOUT_MS = 20000;

  const FOLDER_DROP_ENABLED = true;
  const MAX_FILES_PER_DROP = 2000;
  const SORT_FILES = true;

  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const norm = (s) => (s || "").replace(/\s+/g, " ").trim().toLowerCase();
  const log = (...args) => {
    if (DEBUG) console.log("[LDD Drop]", ...args);
  };

  function isListingsPage() {
    return window.location.pathname.includes("/app/listings");
  }

  function createController() {
    const dropQueue = [];
    let processingQueue = false;
    let armed = true;
    let active = false;

    let overlay = null;

    function statusEl() {
      return document.getElementById("lddStatus");
    }

    function setStatus(text) {
      const el = statusEl();
      if (el) el.textContent = text;
    }

    function showOverlay(text) {
      setStatus(text);
      if (overlay) overlay.style.display = "flex";
    }

    function hideOverlay() {
      if (overlay) overlay.style.display = "none";
    }

    function hardClick(el) {
      if (!el) return;
      el.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
      el.dispatchEvent(new MouseEvent("mouseup", { bubbles: true }));
      el.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    }

    function findButtonByText(text) {
      const target = norm(text);
      return Array.from(document.querySelectorAll("button")).find((button) =>
        norm(button.textContent).includes(target)
      );
    }

    function findUploadModal() {
      return Array.from(document.querySelectorAll("div")).find((div) =>
        div.textContent?.includes("Drag and drop files")
      );
    }

    function findDropTarget(modal) {
      return modal?.querySelector('[class*="border-dashed"]') || modal?.querySelector("div");
    }

    function fireDrop(target, files) {
      if (!target || !files.length) return;
      const dataTransfer = new DataTransfer();
      files.forEach((file) => dataTransfer.items.add(file));
      target.dispatchEvent(
        new DragEvent("drop", {
          bubbles: true,
          cancelable: true,
          dataTransfer
        })
      );
    }

    async function expandDrop(event) {
      const files = Array.from(event.dataTransfer?.files || []);
      if (!FOLDER_DROP_ENABLED) return files;

      const items = Array.from(event.dataTransfer?.items || []);
      const out = [];

      async function walk(entry, path = "") {
        if (!entry || out.length >= MAX_FILES_PER_DROP) return;

        if (entry.isFile) {
          await new Promise((resolve) => {
            entry.file(
              (file) => {
                try {
                  out.push(
                    new File([file], path + file.name, {
                      type: file.type,
                      lastModified: file.lastModified
                    })
                  );
                } catch (_error) {
                  out.push(file);
                }
                resolve();
              },
              () => resolve()
            );
          });
          return;
        }

        if (entry.isDirectory) {
          const reader = entry.createReader();
          while (out.length < MAX_FILES_PER_DROP) {
            const entries = await new Promise((resolve) => {
              reader.readEntries(resolve, () => resolve([]));
            });
            if (!entries.length) break;
            for (const child of entries) {
              await walk(child, `${path}${entry.name}/`);
              if (out.length >= MAX_FILES_PER_DROP) break;
            }
          }
        }
      }

      for (const item of items) {
        const entry = item.webkitGetAsEntry?.();
        if (entry) await walk(entry);
        if (out.length >= MAX_FILES_PER_DROP) break;
      }

      if (SORT_FILES) {
        out.sort((a, b) => a.name.localeCompare(b.name));
      }

      await sleep(300);
      return out.length ? out : files;
    }

    async function processQueue() {
      if (processingQueue || !active) return;
      processingQueue = true;
      armed = false;

      while (active && dropQueue.length) {
        const files = dropQueue.shift();
        showOverlay(`Uploading ${files.length} files - ${dropQueue.length} queued`);

        const uploadBtn = findButtonByText("Upload");
        if (uploadBtn) hardClick(uploadBtn);
        await sleep(300);

        const uploadFilesBtn = findButtonByText("Upload Files");
        if (uploadFilesBtn) hardClick(uploadFilesBtn);

        let modal;
        for (let i = 0; i < 50; i += 1) {
          modal = findUploadModal();
          if (modal) break;
          await sleep(100);
        }
        if (!modal) continue;

        const target = findDropTarget(modal);
        fireDrop(target, files);

        if (AUTO_CLICK_UPLOAD_ALL) {
          const startedAt = Date.now();
          while (Date.now() - startedAt < UPLOAD_ALL_TIMEOUT_MS) {
            const btn = findButtonByText("Upload All");
            if (btn && !btn.disabled) {
              hardClick(btn);
              break;
            }
            await sleep(100);
          }
        }

        if (AUTO_CONFIRM_UPLOAD_DESIGNS) {
          const startedAt = Date.now();
          while (Date.now() - startedAt < CONFIRM_TIMEOUT_MS) {
            const btn = findButtonByText("Upload designs");
            if (btn && !btn.disabled) {
              hardClick(btn);
              break;
            }
            await sleep(100);
          }
        }

        await sleep(1000);
      }

      hideOverlay();
      processingQueue = false;
      armed = true;
    }

    function onDragOver(event) {
      if (!active || !armed || !isListingsPage()) return;
      if (event.dataTransfer?.types?.includes("Files")) {
        event.preventDefault();
        showOverlay("Drop files or folders");
      }
    }

    async function onDrop(event) {
      if (!active || !armed || !isListingsPage()) return;
      if (!event.dataTransfer?.types?.includes("Files")) return;

      event.preventDefault();
      event.stopPropagation();

      const files = await expandDrop(event);
      if (!files.length) return;

      dropQueue.push(files);
      log("Queued batch:", files.length);
      processQueue();
    }

    function createOverlay() {
      overlay?.remove();
      overlay = document.createElement("div");
      overlay.style.cssText = `
        position: fixed; inset: 0; z-index: 999999;
        display: none; align-items: center; justify-content: center;
        background: transparent;
        font-family: system-ui;
        color: #1e2a40;
        padding: 16px;
        box-sizing: border-box;
        pointer-events: none;
      `;

      overlay.innerHTML = `
        <div id="lddCard" style="
          width: min(440px, 90vw);
          border-radius: 18px;
          padding: 14px;
          background: #f8faff;
          border: 1px solid #cad4ea;
          box-shadow: 0 14px 32px rgba(26, 38, 67, 0.2);
        ">
          <div style="display:flex; gap:14px; align-items:center;">
            <img src="${LDD_LOGO_URL}" style="width:48px;height:48px;border-radius:12px" />
            <div>
              <div style="font-weight:800;font-size:18px">LavenderDragonDesign Upload Assist</div>
              <div id="lddStatus" style="font-size:13px;color:#6f7c97">Drop files or folders</div>
            </div>
          </div>
          <div style="margin-top:12px;font-size:12px;color:#6f7c97">Made with love by LavenderDragonDesign</div>
        </div>
      `;
      document.documentElement.appendChild(overlay);
    }

    function start() {
      if (active) return;
      active = true;
      armed = true;
      createOverlay();
      window.addEventListener("dragover", onDragOver, true);
      window.addEventListener("drop", onDrop, true);
      log("LDD Multi-Drop uploader active");
    }

    function stop() {
      if (!active) return;
      active = false;
      armed = true;
      dropQueue.length = 0;
      processingQueue = false;
      window.removeEventListener("dragover", onDragOver, true);
      window.removeEventListener("drop", onDrop, true);
      hideOverlay();
      overlay?.remove();
      overlay = null;
    }

    return { start, stop };
  }

  const state = {
    enabled: false,
    controller: null
  };

  function enable() {
    if (state.enabled) return;
    state.enabled = true;
    state.controller = createController();
    state.controller.start();
  }

  function disable() {
    if (!state.enabled) return;
    state.enabled = false;
    state.controller?.stop();
    state.controller = null;
  }

  window.LDDDropper = { enable, disable };
})();
